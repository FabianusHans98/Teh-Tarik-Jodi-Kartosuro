import { Transaction, ShopInfo } from '../types';
import { formatRupiah, formatDateTimeIndo } from './formatters';

// Common Bluetooth Serial Port / Thermal Printer UUIDs
const PRINTER_SERVICES = [
  '000018f0-0000-1000-8000-00805f9b34fb', // Standard POS printer service
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455',
  0xffe0,
  0xfff0,
];

export interface BluetoothPrintResult {
  success: boolean;
  message: string;
}

export const isWebBluetoothSupported = (): boolean => {
  return typeof navigator !== 'undefined' && 'bluetooth' in navigator;
};

// Generate ESC/POS Byte Array for 58mm / 80mm thermal receipt
export const buildEscPosReceipt = (
  transaction: Transaction,
  shopInfo: ShopInfo,
  paperWidth: '58mm' | '80mm' = '58mm'
): Uint8Array => {
  const encoder = new TextEncoder();
  const maxCols = paperWidth === '58mm' ? 32 : 48;

  const padLine = (left: string, right: string, width = maxCols) => {
    const spaceCount = Math.max(1, width - left.length - right.length);
    return left + ' '.repeat(spaceCount) + right;
  };

  const divider = '-'.repeat(maxCols);
  const doubleDivider = '='.repeat(maxCols);

  const buffer: number[] = [];

  const write = (str: string) => {
    const bytes = encoder.encode(str);
    for (let i = 0; i < bytes.length; i++) buffer.push(bytes[i]);
  };

  const writeBytes = (...bytes: number[]) => {
    buffer.push(...bytes);
  };

  // ESC/POS Commands
  const ESC_INIT = [0x1b, 0x40];
  const ESC_ALIGN_CENTER = [0x1b, 0x61, 0x01];
  const ESC_ALIGN_LEFT = [0x1b, 0x61, 0x00];
  const ESC_ALIGN_RIGHT = [0x1b, 0x61, 0x02];
  const ESC_BOLD_ON = [0x1b, 0x45, 0x01];
  const ESC_BOLD_OFF = [0x1b, 0x45, 0x00];
  const ESC_DOUBLE_HEIGHT_ON = [0x1b, 0x21, 0x10];
  const ESC_DOUBLE_HEIGHT_OFF = [0x1b, 0x21, 0x00];
  const ESC_FEED_CUT = [0x1b, 0x64, 0x04, 0x1d, 0x56, 0x00]; // Feed 4 lines and partial cut

  // 1. Initialize printer
  writeBytes(...ESC_INIT);

  // 2. Header
  writeBytes(...ESC_ALIGN_CENTER);
  writeBytes(...ESC_BOLD_ON, ...ESC_DOUBLE_HEIGHT_ON);
  write(`${shopInfo.name}\n`);
  writeBytes(...ESC_DOUBLE_HEIGHT_OFF, ...ESC_BOLD_OFF);
  write(`KARTOSURO - JAWA TENGAH\n`);
  write(`${shopInfo.tagline}\n`);
  write(`Owner: ${shopInfo.ownerName}\n`);
  if (shopInfo.address) write(`${shopInfo.address}\n`);
  if (shopInfo.phone) write(`Telp/WA: ${shopInfo.phone}\n`);
  write(`${doubleDivider}\n`);

  // 3. Transaction Meta
  writeBytes(...ESC_ALIGN_LEFT);
  write(padLine(`No: ${transaction.receiptNumber}`, transaction.orderType === 'DINE_IN' ? '[DINE-IN]' : '[TAKE-AWAY]') + '\n');
  write(`Waktu: ${formatDateTimeIndo(transaction.timestamp)}\n`);
  write(`Kasir: ${transaction.cashierName}\n`);
  if (transaction.tableNumber) write(`Meja: ${transaction.tableNumber}\n`);
  if (transaction.customerName) write(`Pelanggan: ${transaction.customerName}\n`);
  write(`${divider}\n`);

  // 4. Items
  transaction.items.forEach((item) => {
    writeBytes(...ESC_BOLD_ON);
    write(`${item.name}\n`);
    writeBytes(...ESC_BOLD_OFF);

    // Customization details
    const customTags = [
      item.iceLevel,
      item.sugarLevel,
      item.notes,
    ].filter(Boolean);
    if (customTags.length > 0) {
      write(`  * ${customTags.join(' • ')}\n`);
    }

    const itemCalc = `  ${item.quantity}x @${formatRupiah(item.price)}`;
    const itemSubtotal = formatRupiah(item.subtotal);
    write(padLine(itemCalc, itemSubtotal) + '\n');
  });

  write(`${divider}\n`);

  // 5. Totals
  write(padLine('Subtotal:', formatRupiah(transaction.subtotal)) + '\n');
  if (transaction.discountAmount > 0) {
    write(padLine('Diskon:', `-${formatRupiah(transaction.discountAmount)}`) + '\n');
  }
  if (transaction.taxAmount > 0) {
    write(padLine('Pajak PB1:', formatRupiah(transaction.taxAmount)) + '\n');
  }

  writeBytes(...ESC_BOLD_ON);
  write(padLine('TOTAL:', formatRupiah(transaction.grandTotal)) + '\n');
  writeBytes(...ESC_BOLD_OFF);
  write(`${divider}\n`);

  // 6. Payment info
  const payLabel =
    transaction.paymentMethod === 'CASH'
      ? 'Tunai (Cash)'
      : transaction.paymentMethod === 'QRIS'
      ? 'QRIS'
      : 'Transfer Bank';
  write(padLine('Metode Bayar:', payLabel) + '\n');
  write(padLine('Bayar:', formatRupiah(transaction.amountPaid)) + '\n');
  write(padLine('Kembalian:', formatRupiah(transaction.change)) + '\n');
  write(`${doubleDivider}\n`);

  // 7. Footer
  writeBytes(...ESC_ALIGN_CENTER);
  write('Terima Kasih atas Kunjungan Anda!\n');
  write('Nikmatnya Teh Tarik Tradisional Kartosuro\n');
  write('*** Struk Sah Pembayaran ***\n\n');

  // 8. Feed and cut
  writeBytes(...ESC_FEED_CUT);

  return new Uint8Array(buffer);
};

// Connect to Bluetooth device & send ESC/POS payload
export const printViaBluetooth = async (
  transaction: Transaction,
  shopInfo: ShopInfo,
  paperWidth: '58mm' | '80mm' = '58mm'
): Promise<BluetoothPrintResult> => {
  if (!isWebBluetoothSupported()) {
    return {
      success: false,
      message: 'Browser Anda belum mendukung Web Bluetooth API. Silakan gunakan tombol Cetak Standar atau gunakan browser Google Chrome / Edge.',
    };
  }

  try {
    // Request device with printer services or accept all Bluetooth devices
    // @ts-expect-error - navigator.bluetooth standard web API
    const device = await navigator.bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: [
        '000018f0-0000-1000-8000-00805f9b34fb',
        'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
        '49535343-fe7d-4ae5-8fa9-9fafd205e455',
        0xffe0,
        0xfff0,
      ],
    });

    if (!device || !device.gatt) {
      return { success: false, message: 'Tidak dapat menemukan perangkat Bluetooth.' };
    }

    const server = await device.gatt.connect();
    const services = await server.getPrimaryServices();

    let writeCharacteristic: any = null;

    for (const service of services) {
      try {
        const characteristics = await service.getCharacteristics();
        for (const char of characteristics) {
          if (char.properties.write || char.properties.writeWithoutResponse) {
            writeCharacteristic = char;
            break;
          }
        }
      } catch {
        // continue search
      }
      if (writeCharacteristic) break;
    }

    if (!writeCharacteristic) {
      return {
        success: false,
        message: 'Karakteristik printer Bluetooth tidak ditemukan. Pastikan printer dalam mode siap cetak.',
      };
    }

    // Build data and write in chunks (Bluetooth MTU typically 20-512 bytes)
    const rawBytes = buildEscPosReceipt(transaction, shopInfo, paperWidth);
    const CHUNK_SIZE = 64;

    for (let i = 0; i < rawBytes.length; i += CHUNK_SIZE) {
      const chunk = rawBytes.slice(i, i + CHUNK_SIZE);
      if (writeCharacteristic.writeValueWithoutResponse) {
        await writeCharacteristic.writeValueWithoutResponse(chunk);
      } else {
        await writeCharacteristic.writeValue(chunk);
      }
    }

    // Disconnect cleanly
    setTimeout(() => {
      try {
        device.gatt.disconnect();
      } catch {
        // ignore
      }
    }, 1000);

    return {
      success: true,
      message: `Berhasil mencetak struk ke printer Bluetooth (${device.name || 'Thermal POS'})!`,
    };
  } catch (err: any) {
    if (err.name === 'NotFoundError') {
      return { success: false, message: 'Pemilihan printer Bluetooth dibatalkan.' };
    }
    return {
      success: false,
      message: `Gagal mencetak via Bluetooth: ${err.message || 'Kesalahan koneksi'}`,
    };
  }
};

export const printReceiptViaBluetooth = printViaBluetooth;
