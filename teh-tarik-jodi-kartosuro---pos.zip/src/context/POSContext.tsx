import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Product,
  CartItem,
  Transaction,
  OrderType,
  DiscountInfo,
  PaymentMethod,
  ShopInfo,
  IceLevel,
  SugarLevel,
  CashierShift,
} from '../types';
import {
  INITIAL_PRODUCTS,
  INITIAL_CATEGORIES,
  DEFAULT_SHOP_INFO,
} from '../data/initialData';
import {
  generateReceiptNumber,
  playSound,
} from '../utils/formatters';

export interface CartCustomizationOptions {
  iceLevel?: IceLevel;
  sugarLevel?: SugarLevel;
  notes?: string;
}

interface POSContextType {
  products: Product[];
  categories: string[];
  cart: CartItem[];
  orderType: OrderType;
  setOrderType: (type: OrderType) => void;
  customerName: string;
  setCustomerName: (name: string) => void;
  tableNumber: string;
  setTableNumber: (num: string) => void;
  discount: DiscountInfo;
  setDiscount: (discount: DiscountInfo) => void;
  taxEnabled: boolean;
  setTaxEnabled: (enabled: boolean) => void;
  transactions: Transaction[];
  shopInfo: ShopInfo;
  setShopInfo: (info: ShopInfo) => void;
  activeTab: 'pos' | 'menu' | 'inventory' | 'reports' | 'history';
  setActiveTab: (tab: 'pos' | 'menu' | 'inventory' | 'reports' | 'history') => void;
  
  // Shift Management
  currentShift: CashierShift | null;
  shiftHistory: CashierShift[];
  startShift: (startingCash: number, cashierName?: string) => void;
  endShift: (actualCash: number, notes?: string) => CashierShift | null;

  // Cart Actions
  addToCart: (product: Product, customization?: CartCustomizationOptions | string) => void;
  updateQuantity: (cartItemId: string, delta: number) => void;
  updateNotes: (cartItemId: string, notes: string) => void;
  removeFromCart: (cartItemId: string) => void;
  clearCart: () => void;

  // Product / Stock Actions
  addProduct: (newProd: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, updatedData: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  adjustStock: (id: string, delta: number) => void;
  setStock: (id: string, amount: number) => void;
  resetToDefaultMenu: () => void;

  // Checkout Actions
  completePayment: (paymentMethod: PaymentMethod, amountPaid: number) => Transaction;
  currentReceipt: Transaction | null;
  setCurrentReceipt: (tx: Transaction | null) => void;
  clearAllTransactions: () => void;

  // Totals & Computed
  cartSubtotal: number;
  discountAmount: number;
  taxAmount: number;
  serviceFeeAmount: number;
  cartGrandTotal: number;
  totalCartItemsCount: number;
  lowStockProducts: Product[];
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
}

const POSContext = createContext<POSContextType | undefined>(undefined);

const STORAGE_KEYS = {
  PRODUCTS: 'ttj_products_v4',
  TRANSACTIONS: 'ttj_transactions_v2',
  SHOP_INFO: 'ttj_shop_info_v2',
  CATEGORIES: 'ttj_categories_v2',
  TAX_ENABLED: 'ttj_tax_enabled_v2',
  CURRENT_SHIFT: 'ttj_current_shift_v1',
  SHIFT_HISTORY: 'ttj_shift_history_v1',
};

export const POSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load stored products or fallback to default 6 menus
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (saved) {
        const parsed: Product[] = JSON.parse(saved);
        // Hydrate slogans, images, names, and official prices for the 6 core Kopitiam items while preserving user edits
        return parsed.map((p) => {
          const initialMatch = INITIAL_PRODUCTS.find((init) => init.id === p.id);
          if (initialMatch) {
            return {
              ...initialMatch,
              ...p,
              image: p.image || initialMatch.image,
              name: p.name || initialMatch.name,
              price: typeof p.price === 'number' ? p.price : initialMatch.price,
              description: p.description || initialMatch.description,
            };
          }
          return p;
        });
      }
    } catch {
      // ignore
    }
    return INITIAL_PRODUCTS;
  });

  // Load categories
  const [categories, setCategories] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_CATEGORIES;
  });

  // Load shop info
  const [shopInfo, setShopInfo] = useState<ShopInfo>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SHOP_INFO);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return DEFAULT_SHOP_INFO;
  });

  // Transactions: Clean empty by default, as requested by user!
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  const [activeTab, setActiveTab] = useState<'pos' | 'menu' | 'inventory' | 'reports' | 'history'>('pos');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orderType, setOrderType] = useState<OrderType>('DINE_IN');
  const [customerName, setCustomerName] = useState<string>('');
  const [tableNumber, setTableNumber] = useState<string>('');
  const [discount, setDiscount] = useState<DiscountInfo>({ type: 'NOMINAL', value: 0 });
  const [taxEnabled, setTaxEnabled] = useState<boolean>(false);
  const [currentReceipt, setCurrentReceipt] = useState<Transaction | null>(null);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Cashier Shift Management state
  const [currentShift, setCurrentShift] = useState<CashierShift | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CURRENT_SHIFT);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return null;
  });

  const [shiftHistory, setShiftHistory] = useState<CashierShift[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SHIFT_HISTORY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  const startShift = (startingCash: number, cashierName?: string) => {
    const shift: CashierShift = {
      id: `SHIFT-${Date.now()}`,
      cashierName: cashierName || shopInfo.cashierName,
      startTime: new Date().toISOString(),
      startingCash: Math.max(0, startingCash),
      status: 'OPEN',
      expectedCash: Math.max(0, startingCash),
      totalCashSales: 0,
      totalQrisSales: 0,
      totalBankSales: 0,
      totalSales: 0,
      transactionCount: 0,
    };
    setCurrentShift(shift);
    localStorage.setItem(STORAGE_KEYS.CURRENT_SHIFT, JSON.stringify(shift));
    if (soundEnabled) playSound('beep');
  };

  const endShift = (actualCash: number, notes?: string): CashierShift | null => {
    if (!currentShift) return null;
    const diff = actualCash - currentShift.expectedCash;
    const closedShift: CashierShift = {
      ...currentShift,
      endTime: new Date().toISOString(),
      status: 'CLOSED',
      actualCash,
      cashDifference: diff,
      notes: notes?.trim() || undefined,
    };
    setCurrentShift(null);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_SHIFT);
    setShiftHistory(prev => {
      const updated = [closedShift, ...prev];
      localStorage.setItem(STORAGE_KEYS.SHIFT_HISTORY, JSON.stringify(updated));
      return updated;
    });
    if (soundEnabled) playSound('beep');
    return closedShift;
  };

  // Sync products to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  }, [products]);

  // Sync transactions to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  // Sync shop info to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SHOP_INFO, JSON.stringify(shopInfo));
  }, [shopInfo]);

  // Sync categories
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  }, [categories]);

  // Computed Cart values
  const cartSubtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const discountAmount = Math.min(
    cartSubtotal,
    discount.type === 'PERCENTAGE'
      ? Math.round((cartSubtotal * discount.value) / 100)
      : discount.value
  );

  const discountedSubtotal = Math.max(0, cartSubtotal - discountAmount);

  const taxAmount = taxEnabled && shopInfo.taxRatePercent > 0
    ? Math.round((discountedSubtotal * shopInfo.taxRatePercent) / 100)
    : 0;

  const serviceFeeAmount = shopInfo.serviceFeePercent > 0
    ? Math.round((discountedSubtotal * shopInfo.serviceFeePercent) / 100)
    : 0;

  const cartGrandTotal = discountedSubtotal + taxAmount + serviceFeeAmount;
  const totalCartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Low stock products alert list
  const lowStockProducts = products.filter(p => p.stock <= p.minStockAlert);

  // Cart Management
  const addToCart = (
    product: Product,
    customization?: CartCustomizationOptions | string
  ) => {
    if (product.stock <= 0) {
      if (soundEnabled) playSound('alert');
      return;
    }

    let iceLevel: IceLevel | undefined;
    let sugarLevel: SugarLevel | undefined;
    let notes = '';

    if (typeof customization === 'string') {
      notes = customization.trim();
    } else if (customization) {
      iceLevel = customization.iceLevel;
      sugarLevel = customization.sugarLevel;
      notes = customization.notes ? customization.notes.trim() : '';
    }

    const iceKey = iceLevel || 'default-ice';
    const sugarKey = sugarLevel || 'default-sugar';
    const notesKey = notes.toLowerCase();
    const cartItemId = `${product.id}-${iceKey}-${sugarKey}-${notesKey}`;

    const existing = cart.find(item => item.id === cartItemId);

    if (existing) {
      if (existing.quantity >= product.stock) {
        if (soundEnabled) playSound('alert');
        return;
      }
      setCart(prev =>
        prev.map(item =>
          item.id === cartItemId ? { ...item, quantity: item.quantity + 1 } : item
        )
      );
    } else {
      setCart(prev => [
        ...prev,
        {
          id: cartItemId,
          productId: product.id,
          name: product.name,
          price: product.price,
          quantity: 1,
          notes,
          iceLevel,
          sugarLevel,
          maxStock: product.stock,
          category: product.category,
          image: product.image,
        },
      ]);
    }

    if (soundEnabled) playSound('beep');
  };

  const updateQuantity = (cartItemId: string, delta: number) => {
    setCart(prev => {
      return prev
        .map(item => {
          if (item.id === cartItemId) {
            const newQty = item.quantity + delta;
            if (newQty <= 0) return null;
            if (newQty > item.maxStock) {
              if (soundEnabled) playSound('alert');
              return item;
            }
            return { ...item, quantity: newQty };
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
    if (soundEnabled) playSound('beep');
  };

  const updateNotes = (cartItemId: string, notes: string) => {
    setCart(prev =>
      prev.map(item => (item.id === cartItemId ? { ...item, notes } : item))
    );
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => item.id !== cartItemId));
    if (soundEnabled) playSound('trash');
  };

  const clearCart = () => {
    setCart([]);
    setDiscount({ type: 'NOMINAL', value: 0 });
    setCustomerName('');
    setTableNumber('');
    if (soundEnabled) playSound('trash');
  };

  // Product & Inventory actions
  const addProduct = (newProd: Omit<Product, 'id'>) => {
    const id = `prod-${Date.now()}`;
    const product: Product = { ...newProd, id };
    setProducts(prev => [product, ...prev]);

    // Ensure category exists
    if (!categories.includes(newProd.category)) {
      setCategories(prev => [...prev, newProd.category]);
    }
    if (soundEnabled) playSound('success');
  };

  const updateProduct = (id: string, updatedData: Partial<Product>) => {
    setProducts(prev =>
      prev.map(p => (p.id === id ? { ...p, ...updatedData } : p))
    );
    // update in cart if any
    setCart(prev =>
      prev.map(item => {
        if (item.productId === id) {
          return {
            ...item,
            name: updatedData.name ?? item.name,
            price: updatedData.price ?? item.price,
            maxStock: updatedData.stock ?? item.maxStock,
            image: updatedData.image ?? item.image,
          };
        }
        return item;
      })
    );
    if (soundEnabled) playSound('beep');
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    setCart(prev => prev.filter(item => item.productId !== id));
    if (soundEnabled) playSound('trash');
  };

  const adjustStock = (id: string, delta: number) => {
    setProducts(prev =>
      prev.map(p => (p.id === id ? { ...p, stock: Math.max(0, p.stock + delta) } : p))
    );
  };

  const setStock = (id: string, amount: number) => {
    setProducts(prev =>
      prev.map(p => (p.id === id ? { ...p, stock: Math.max(0, amount) } : p))
    );
  };

  const resetToDefaultMenu = () => {
    setProducts(INITIAL_PRODUCTS);
    setCategories(INITIAL_CATEGORIES);
    if (soundEnabled) playSound('beep');
  };

  // Complete Payment & Generate Transaction
  const completePayment = (paymentMethod: PaymentMethod, amountPaid: number): Transaction => {
    const receiptNumber = generateReceiptNumber(transactions.length + 1);
    const now = new Date();

    const change = Math.max(0, amountPaid - cartGrandTotal);

    const transaction: Transaction = {
      id: `TX-${Date.now()}`,
      receiptNumber,
      timestamp: now.toISOString(),
      items: cart.map(item => ({
        productId: item.productId,
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        subtotal: item.price * item.quantity,
        notes: item.notes,
        iceLevel: item.iceLevel,
        sugarLevel: item.sugarLevel,
        category: item.category,
      })),
      subtotal: cartSubtotal,
      discountAmount,
      discountInfo: discount.value > 0 ? discount : undefined,
      taxAmount,
      serviceFee: serviceFeeAmount,
      grandTotal: cartGrandTotal,
      paymentMethod,
      amountPaid,
      change,
      orderType,
      customerName: customerName.trim() || undefined,
      tableNumber: tableNumber.trim() || undefined,
      cashierName: shopInfo.cashierName,
      ownerName: shopInfo.ownerName,
    };

    // Update active cashier shift if open
    if (currentShift && currentShift.status === 'OPEN') {
      const isCash = paymentMethod === 'CASH';
      const isQris = paymentMethod === 'QRIS';
      const isBank = paymentMethod === 'BANK_TRANSFER';
      const cashAmount = isCash ? cartGrandTotal : 0;
      const qrisAmount = isQris ? cartGrandTotal : 0;
      const bankAmount = isBank ? cartGrandTotal : 0;

      const updatedShift: CashierShift = {
        ...currentShift,
        expectedCash: currentShift.expectedCash + cashAmount,
        totalCashSales: currentShift.totalCashSales + cashAmount,
        totalQrisSales: currentShift.totalQrisSales + qrisAmount,
        totalBankSales: currentShift.totalBankSales + bankAmount,
        totalSales: currentShift.totalSales + cartGrandTotal,
        transactionCount: currentShift.transactionCount + 1,
      };
      setCurrentShift(updatedShift);
      localStorage.setItem(STORAGE_KEYS.CURRENT_SHIFT, JSON.stringify(updatedShift));
    }

    // Deduct stock for each purchased item
    setProducts(prev =>
      prev.map(prod => {
        const cartItemsForThisProd = cart.filter(c => c.productId === prod.id);
        const totalQtyDeducted = cartItemsForThisProd.reduce((sum, c) => sum + c.quantity, 0);
        if (totalQtyDeducted > 0) {
          return {
            ...prod,
            stock: Math.max(0, prod.stock - totalQtyDeducted),
          };
        }
        return prod;
      })
    );

    // Save transaction to history
    setTransactions(prev => [transaction, ...prev]);

    // Set current receipt for immediate thermal preview
    setCurrentReceipt(transaction);

    // Clear the cart
    setCart([]);
    setDiscount({ type: 'NOMINAL', value: 0 });
    setCustomerName('');
    setTableNumber('');

    // Audio & Visual celebratory feedback
    if (soundEnabled) playSound('success');
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.8 },
      colors: ['#D4A373', '#CCD5AE', '#FAEDCD', '#A3B18A'],
    });

    return transaction;
  };

  const clearAllTransactions = () => {
    setTransactions([]);
    localStorage.removeItem(STORAGE_KEYS.TRANSACTIONS);
    if (soundEnabled) playSound('trash');
  };

  return (
    <POSContext.Provider
      value={{
        products,
        categories,
        cart,
        orderType,
        setOrderType,
        customerName,
        setCustomerName,
        tableNumber,
        setTableNumber,
        discount,
        setDiscount,
        taxEnabled,
        setTaxEnabled,
        transactions,
        shopInfo,
        setShopInfo,
        activeTab,
        setActiveTab,
        currentShift,
        shiftHistory,
        startShift,
        endShift,
        addToCart,
        updateQuantity,
        updateNotes,
        removeFromCart,
        clearCart,
        addProduct,
        updateProduct,
        deleteProduct,
        adjustStock,
        setStock,
        resetToDefaultMenu,
        completePayment,
        currentReceipt,
        setCurrentReceipt,
        clearAllTransactions,
        cartSubtotal,
        discountAmount,
        taxAmount,
        serviceFeeAmount,
        cartGrandTotal,
        totalCartItemsCount,
        lowStockProducts,
        soundEnabled,
        setSoundEnabled,
      }}
    >
      {children}
    </POSContext.Provider>
  );
};

export const usePOS = () => {
  const context = useContext(POSContext);
  if (!context) {
    throw new Error('usePOS must be used within a POSProvider');
  }
  return context;
};
