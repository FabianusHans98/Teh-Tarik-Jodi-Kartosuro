import React, { useState } from 'react';
import {
  PackageCheck,
  AlertTriangle,
  Plus,
  Minus,
  CheckCircle2,
  RefreshCw,
  Search,
  ArrowUpDown,
  Boxes,
  Coffee,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { formatRupiah } from '../utils/formatters';

export const InventoryManagement: React.FC = () => {
  const {
    products,
    adjustStock,
    setStock,
    lowStockProducts,
    shopInfo,
  } = usePOS();

  const [search, setSearch] = useState('');
  const [filterMode, setFilterMode] = useState<'ALL' | 'LOW' | 'OUT'>('ALL');

  const totalUnits = products.reduce((sum, p) => sum + p.stock, 0);
  const outOfStockCount = products.filter(p => p.stock === 0).length;

  const filtered = products.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.category.toLowerCase().includes(search.toLowerCase());

    if (!matchSearch) return false;
    if (filterMode === 'LOW') return p.stock <= p.minStockAlert && p.stock > 0;
    if (filterMode === 'OUT') return p.stock === 0;
    return true;
  });

  return (
    <div className="flex-1 p-4 sm:p-6 bg-[#FDFBF7] overflow-y-auto space-y-5">
      {/* Top Banner & Stats */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E8DFD8] shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-[#2D1B14] flex items-center gap-2">
              <PackageCheck className="w-5 h-5 text-[#58311F]" />
              <span>Manajemen Stok Real-Time (Inventory Control)</span>
            </h2>
            <p className="text-xs text-[#8C7A70] mt-0.5">
              Stok berkurang otomatis setiap ada pesanan kasir yang diselesaikan. Owner {shopInfo.ownerName} dapat menambah stok cup / racikan di sini.
            </p>
          </div>
        </div>

        {/* 3 Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8]">
            <span className="text-xs text-[#8C7A70] font-medium block">Total Seluruh Menu</span>
            <span className="text-xl font-extrabold text-[#58311F] mt-1 block">
              {products.length} Menu
            </span>
            <span className="text-[11px] text-[#A89F91]">Total {totalUnits} porsi/cup tersedia</span>
          </div>

          <div
            onClick={() => setFilterMode(filterMode === 'LOW' ? 'ALL' : 'LOW')}
            className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
              lowStockProducts.length > 0
                ? 'bg-amber-50/70 border-amber-300 hover:bg-amber-50'
                : 'bg-[#FAF8F5] border-[#E8DFD8]'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs text-amber-800 font-medium">Stok Menipis (Alert)</span>
              {lowStockProducts.length > 0 && (
                <AlertTriangle className="w-4 h-4 text-amber-600 animate-pulse" />
              )}
            </div>
            <span className="text-xl font-extrabold text-amber-700 mt-1 block">
              {lowStockProducts.length} Menu
            </span>
            <span className="text-[11px] text-amber-600">
              {lowStockProducts.length > 0 ? 'Klik untuk filter stok menipis' : 'Semua stok dalam batas aman'}
            </span>
          </div>

          <div
            onClick={() => setFilterMode(filterMode === 'OUT' ? 'ALL' : 'OUT')}
            className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
              outOfStockCount > 0
                ? 'bg-red-50/70 border-red-300 hover:bg-red-50'
                : 'bg-[#FAF8F5] border-[#E8DFD8]'
            }`}
          >
            <span className="text-xs text-red-800 font-medium block">Stok Habis (0 Unit)</span>
            <span className="text-xl font-extrabold text-red-700 mt-1 block">
              {outOfStockCount} Menu
            </span>
            <span className="text-[11px] text-red-600">
              {outOfStockCount > 0 ? 'Perlu restock segera!' : 'Tidak ada menu yang habis'}
            </span>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-[#E8DFD8]">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-[#8C7A70] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari menu untuk disesuaikan stoknya..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
          />
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setFilterMode('ALL')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold ${
              filterMode === 'ALL'
                ? 'bg-[#58311F] text-white'
                : 'bg-[#FAF8F5] text-[#6B4F3E] hover:bg-[#EFE9E2]'
            }`}
          >
            Semua ({products.length})
          </button>
          <button
            onClick={() => setFilterMode('LOW')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold ${
              filterMode === 'LOW'
                ? 'bg-amber-600 text-white'
                : 'bg-[#FAF8F5] text-amber-800 hover:bg-amber-50'
            }`}
          >
            Menipis ({lowStockProducts.length})
          </button>
          <button
            onClick={() => setFilterMode('OUT')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold ${
              filterMode === 'OUT'
                ? 'bg-red-600 text-white'
                : 'bg-[#FAF8F5] text-red-800 hover:bg-red-50'
            }`}
          >
            Habis ({outOfStockCount})
          </button>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-2xl border border-[#E8DFD8] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#FAF8F5] text-[#58311F] border-b border-[#E8DFD8] uppercase tracking-wider font-bold">
              <tr>
                <th className="py-3 px-4">Menu & Kategori</th>
                <th className="py-3 px-4">Harga</th>
                <th className="py-3 px-4 text-center">Status Stok</th>
                <th className="py-3 px-4 text-center">Jumlah Stok Saat Ini</th>
                <th className="py-3 px-4 text-right">Penyesuaian Cepat (Restock)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F2ECE4]">
              {filtered.map((item) => {
                const isOut = item.stock === 0;
                const isLow = !isOut && item.stock <= item.minStockAlert;

                return (
                  <tr key={item.id} className="hover:bg-[#FAF8F5]/80 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl overflow-hidden bg-[#F4EBE1] border border-[#E8DFD8] shrink-0 shadow-2xs">
                          {item.image ? (
                            <img
                              src={item.image}
                              alt={item.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                e.currentTarget.style.display = 'none';
                              }}
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-[#7A4B2A]">
                              <Coffee className="w-4 h-4 opacity-70" />
                            </div>
                          )}
                        </div>
                        <div>
                          <div className="font-bold text-sm text-[#2D1B14]">{item.name}</div>
                          <span className="text-[10px] text-[#7A4B2A] bg-[#F4EBE1] px-1.5 py-0.5 rounded font-medium">
                            {item.category}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-semibold text-[#58311F]">
                      {formatRupiah(item.price)}
                    </td>

                    <td className="py-3 px-4 text-center">
                      {isOut ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold bg-red-100 text-red-700">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-600"></span>
                          HABIS
                        </span>
                      ) : isLow ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
                          <AlertTriangle className="w-3 h-3 text-amber-600" />
                          MENIPIS (&le;{item.minStockAlert})
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          AMAN
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1 bg-[#FAF8F5] px-2.5 py-1 rounded-xl border border-[#D7CCC8]">
                        <input
                          type="number"
                          min="0"
                          value={item.stock}
                          onChange={(e) => setStock(item.id, parseInt(e.target.value, 10) || 0)}
                          className="w-16 text-center font-extrabold text-sm text-[#2D1B14] bg-transparent focus:outline-none"
                        />
                        <span className="text-[11px] text-[#8C7A70]">cup</span>
                      </div>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => adjustStock(item.id, -5)}
                          disabled={item.stock < 5}
                          className="px-2 py-1 rounded-lg border border-[#D7CCC8] hover:bg-neutral-100 text-xs font-semibold text-[#58311F] disabled:opacity-40"
                          title="Kurangi 5 unit"
                        >
                          -5
                        </button>
                        <button
                          type="button"
                          onClick={() => adjustStock(item.id, -1)}
                          disabled={item.stock <= 0}
                          className="px-2 py-1 rounded-lg border border-[#D7CCC8] hover:bg-neutral-100 text-xs font-semibold text-[#58311F] disabled:opacity-40"
                          title="Kurangi 1 unit"
                        >
                          -1
                        </button>
                        <button
                          type="button"
                          onClick={() => adjustStock(item.id, 5)}
                          className="px-2 py-1 rounded-lg bg-[#FAF8F5] border border-[#BC6C25]/40 hover:bg-[#F4EBE1] text-xs font-bold text-[#58311F]"
                          title="Tambah 5 unit"
                        >
                          +5
                        </button>
                        <button
                          type="button"
                          onClick={() => adjustStock(item.id, 10)}
                          className="px-2.5 py-1 rounded-lg bg-[#58311F] hover:bg-[#432314] text-white text-xs font-bold shadow-xs"
                          title="Tambah 10 unit (Restock cepat)"
                        >
                          +10
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
