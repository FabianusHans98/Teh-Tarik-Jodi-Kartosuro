import React, { useState, useMemo } from 'react';
import {
  Search,
  X,
  Plus,
  Edit3,
  Coffee,
  Check,
  Flame,
  AlertTriangle,
  AlertCircle,
  PackagePlus,
  Boxes,
  Pencil,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { Product } from '../types';
import { formatRupiah } from '../utils/formatters';
import { EditProductModal } from './EditProductModal';
import { CustomDrinkModal } from './CustomDrinkModal';

export const POSTerminal: React.FC = () => {
  const {
    products,
    addToCart,
    cart,
    setStock,
  } = usePOS();

  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Customization note modal
  const [customizingProduct, setCustomizingProduct] = useState<Product | null>(null);
  const [customNote, setCustomNote] = useState<string>('');

  // Quick Restock modal directly from POS
  const [restockingProduct, setRestockingProduct] = useState<Product | null>(null);
  const [restockAmount, setRestockAmount] = useState<string>('50');

  // Edit Menu & Upload Gambar Modal
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const handleOpenEditProduct = (product: Product, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setEditingProduct(product);
  };

  const PRESET_NOTES = [
    'Less Ice',
    'No Ice (Hangat)',
    'Less Sugar',
    'Extra Manis',
    'Tarik Busa Tebal',
    'Gelas Plastik',
  ];

  // Critical stock products (< 5 cups or out of stock)
  const criticalProducts = useMemo(() => {
    return products.filter((p) => p.stock <= 5);
  }, [products]);

  // All products directly displayed, filtered by search query when typing
  const filteredProducts = useMemo(() => {
    if (!searchQuery.trim()) return products;
    const q = searchQuery.toLowerCase();
    return products.filter((item) => {
      return (
        item.name.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        (item.description && item.description.toLowerCase().includes(q))
      );
    });
  }, [products, searchQuery]);

  const handleQuickAdd = (product: Product, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (product.stock <= 0) return;
    addToCart(product);
  };

  const handleOpenCustomize = (product: Product, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (product.stock <= 0) return;
    setCustomizingProduct(product);
    setCustomNote('');
  };

  const handleConfirmCustomAdd = () => {
    if (!customizingProduct) return;
    addToCart(customizingProduct, customNote);
    setCustomizingProduct(null);
    setCustomNote('');
  };

  const handleOpenRestock = (product: Product, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setRestockingProduct(product);
    setRestockAmount('50');
  };

  const handleConfirmRestock = () => {
    if (!restockingProduct) return;
    const qty = parseInt(restockAmount, 10);
    if (!isNaN(qty) && qty >= 0) {
      setStock(restockingProduct.id, qty);
    }
    setRestockingProduct(null);
  };

  const handleAddStockDelta = (delta: number) => {
    if (!restockingProduct) return;
    const current = parseInt(restockAmount, 10) || restockingProduct.stock;
    const nextVal = Math.max(0, current + delta);
    setRestockAmount(nextVal.toString());
  };

  // Check how many of this product are currently in cart
  const getProductCartCount = (productId: string) => {
    return cart
      .filter((item) => item.productId === productId)
      .reduce((sum, item) => sum + item.quantity, 0);
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#FDFBF7]">
      {/* Critical Stock Notification Banner for Rayvando */}
      {criticalProducts.length > 0 && (
        <div className="bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-white px-4 py-2 flex items-center justify-between text-xs font-semibold shadow-inner">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-yellow-300"></span>
            </span>
            <AlertTriangle className="w-4 h-4 text-yellow-300 shrink-0" />
            <span>
              <strong>Peringatan Stok Kritis ({criticalProducts.length} Menu &lt; 5 Cup):</strong>{' '}
              {criticalProducts.map((p) => `${p.name} (${p.stock} cup)`).join(', ')}
            </span>
          </div>
          <span className="text-[11px] bg-white/20 px-2 py-0.5 rounded backdrop-blur-xs hidden sm:inline-block">
            Gunakan tombol "Restock Cup" pada kartu menu untuk isi ulang
          </span>
        </div>
      )}

      {/* Search & All-Menu Header Bar (Direct access to all products without category filters) */}
      <div className="p-4 bg-white/80 backdrop-blur-sm border-b border-[#E8DFD8]">
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8C7A70]" />
          <input
            type="text"
            placeholder="Cari menu dengan cepat (Teh - O, Teh Tarik, Kopi - O, Kopitiam Susu, Coklat, Matcha)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-sm text-[#2D1B14] placeholder-[#A89F91] focus:outline-none focus:ring-2 focus:ring-[#D4A373] focus:border-transparent transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-[#8C7A70] hover:text-[#2D1B14]"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Menu Cards Grid */}
      <div className="flex-1 overflow-y-auto p-4">
        {filteredProducts.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-[#8C7A70]">
            <Coffee className="w-12 h-12 text-[#D7CCC8] mb-2" />
            <p className="font-semibold text-base text-[#58311F]">Menu tidak ditemukan</p>
            <p className="text-xs text-[#8C7A70] mt-1 max-w-xs">
              Tidak ada produk yang cocok dengan pencarian "{searchQuery}". Coba kata kunci lain atau periksa kategori.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-3.5">
            {filteredProducts.map((product) => {
              const inCartCount = getProductCartCount(product.id);
              const isOutOfStock = product.stock <= 0;
              const isCriticalStock = !isOutOfStock && product.stock <= 5;
              const isLowStock = !isOutOfStock && !isCriticalStock && product.stock <= product.minStockAlert;
              const remainingAllowed = product.stock - inCartCount;

              return (
                <div
                  key={product.id}
                  onClick={() => !isOutOfStock && handleOpenCustomize(product)}
                  className={`group relative rounded-2xl border transition-all duration-200 overflow-hidden flex flex-col justify-between bg-white text-left ${
                    isOutOfStock
                      ? 'border-red-300 opacity-75 bg-red-50/20'
                      : isCriticalStock
                      ? 'border-red-500 ring-2 ring-red-500/40 shadow-md hover:shadow-xl cursor-pointer active:scale-[0.98]'
                      : isLowStock
                      ? 'border-amber-300 hover:border-amber-400 hover:shadow-md cursor-pointer active:scale-[0.98]'
                      : 'border-[#E8DFD8] hover:border-[#D4A373] hover:shadow-lg cursor-pointer active:scale-[0.98]'
                  }`}
                >
                  {/* Top: High Resolution Product Visual Image */}
                  <div className="relative w-full h-40 sm:h-44 overflow-hidden bg-[#F4EBE1] flex-shrink-0">
                    {product.image ? (
                      <img
                        src={product.image}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                        loading="lazy"
                        onError={(e) => {
                          // fallback if image cannot load
                          const target = e.currentTarget;
                          target.style.display = 'none';
                          const parent = target.parentElement;
                          if (parent) {
                            const fallback = parent.querySelector('.img-fallback') as HTMLElement;
                            if (fallback) fallback.style.display = 'flex';
                          }
                        }}
                      />
                    ) : null}

                    {/* Gradient & Pattern Fallback if no image or error */}
                    <div
                      className={`img-fallback ${
                        product.image ? 'hidden' : 'flex'
                      } absolute inset-0 bg-gradient-to-br ${
                        product.colorScheme || 'from-[#7A4B2A] to-[#3E2419]'
                      } items-center justify-center text-white`}
                    >
                      <Coffee className="w-10 h-10 opacity-70" />
                    </div>

                    {/* Subtle Gradient Overlay for badge contrast */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/30 pointer-events-none" />

                    {/* Category Pill Floating Top-Left */}
                    <span className="absolute top-2.5 left-2.5 text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#2D1B14]/85 text-[#FAF7F2] backdrop-blur-xs border border-white/20 shadow-xs">
                      {product.category}
                    </span>

                    {/* In-Cart Counter Badge Floating Top-Right */}
                    {inCartCount > 0 && (
                      <span className="absolute top-2.5 right-2.5 inline-flex items-center justify-center px-2 py-0.5 text-xs font-black rounded-full bg-[#D4A373] text-[#2D1B14] shadow-md ring-2 ring-white">
                        {inCartCount}x di Keranjang
                      </span>
                    )}

                    {/* AUTOMATIC VISUAL ALERT: Critical, Out of Stock, or Low Stock */}
                    {isOutOfStock ? (
                      <span className="absolute bottom-2 left-2 text-[10px] font-black px-2.5 py-1 rounded-lg bg-red-600 text-white shadow-md flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        STOK HABIS (0 Cup)
                      </span>
                    ) : isCriticalStock ? (
                      <span className="absolute bottom-2 left-2 text-[10px] font-black px-2.5 py-1 rounded-lg bg-red-600 text-white shadow-md flex items-center gap-1.5 animate-pulse ring-2 ring-white">
                        <AlertTriangle className="w-3.5 h-3.5 stroke-[2.5]" />
                        KRITIS: Sisa {product.stock} Cup!
                      </span>
                    ) : isLowStock ? (
                      <span className="absolute bottom-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded-lg bg-amber-500 text-[#2D1B14] shadow-xs">
                        Sisa {product.stock} cup (Menipis)
                      </span>
                    ) : null}

                    {/* Floating Edit Foto Button on Image */}
                    <button
                      type="button"
                      onClick={(e) => handleOpenEditProduct(product, e)}
                      className="absolute bottom-2 right-2 z-10 px-2 py-1 rounded-lg bg-black/65 hover:bg-[#58311F] text-white flex items-center gap-1 backdrop-blur-xs transition-all opacity-85 hover:opacity-100 hover:scale-105 shadow-md text-[10px] font-bold border border-white/20"
                      title="Edit & Ganti Foto Menu"
                    >
                      <Pencil className="w-3 h-3 text-[#D4A373]" />
                      <span className="hidden sm:inline">Foto</span>
                    </button>
                  </div>

                  {/* Critical Stock Warning Bar on Card */}
                  {isCriticalStock && (
                    <div className="bg-red-50 border-y border-red-200 px-3 py-1 text-[10px] text-red-700 font-bold flex items-center justify-between">
                      <span className="flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 text-red-600" />
                        Sisa &lt; 5 cup! Segera restock
                      </span>
                      <button
                        type="button"
                        onClick={(e) => handleOpenRestock(product, e)}
                        className="text-red-800 underline hover:text-red-950 font-black cursor-pointer"
                      >
                        +Isi
                      </button>
                    </div>
                  )}

                  {/* Card Body: Title & Slogan/Description */}
                  <div className="p-3.5 pb-2 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-bold text-sm sm:text-base text-[#2D1B14] group-hover:text-[#8B4513] transition-colors line-clamp-1">
                        {product.name}
                      </h3>

                      {product.description && (
                        <p className="text-[11px] sm:text-xs text-[#6B574B] mt-1.5 line-clamp-2 leading-relaxed font-medium bg-[#FAF6F0] px-2 py-1.5 rounded-lg border border-[#EDE4DB] min-h-[2.5rem] flex items-center">
                          "{product.description}"
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Bottom Bar: Price, Stock Counter & Quick Add */}
                  <div className="p-3 pt-2 border-t border-[#F2ECE4] bg-[#FAF8F5]/90 space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-[10px] text-[#8C7A70] uppercase font-bold tracking-wider">Harga</div>
                        <div className="font-extrabold text-base sm:text-lg text-[#58311F] font-mono">
                          {formatRupiah(product.price)}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-[10px] text-[#8C7A70] uppercase font-bold tracking-wider">Tersedia</div>
                        <div className="flex items-center gap-1 justify-end">
                          <span
                            className={`text-xs font-black ${
                              isOutOfStock
                                ? 'text-red-600'
                                : isCriticalStock
                                ? 'text-red-600 font-extrabold'
                                : isLowStock
                                ? 'text-amber-700 font-bold'
                                : 'text-[#2D1B14]'
                            }`}
                          >
                            {product.stock} cup
                          </span>
                          {/* Quick Restock Shortcut Icon */}
                          <button
                            type="button"
                            onClick={(e) => handleOpenRestock(product, e)}
                            className="p-1 rounded text-[#8C7A70] hover:text-[#58311F] hover:bg-[#EFE9E2] transition-colors"
                            title="Edit / Restock Stok Cup langsung"
                          >
                            <PackagePlus className="w-3.5 h-3.5 text-[#7A4B2A]" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-1.5 pt-0.5">
                      <button
                        type="button"
                        disabled={isOutOfStock || remainingAllowed <= 0}
                        onClick={(e) => handleOpenCustomize(product, e)}
                        className={`flex-1 py-2 px-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 ${
                          isOutOfStock || remainingAllowed <= 0
                            ? 'bg-neutral-200 text-neutral-400 cursor-not-allowed'
                            : 'bg-[#58311F] hover:bg-[#432314] text-white shadow-xs'
                        }`}
                      >
                        <Plus className="w-3.5 h-3.5 stroke-[2.5] text-[#D4A373]" />
                        <span>
                          {isOutOfStock
                            ? 'Habis'
                            : remainingAllowed <= 0
                            ? 'Maks Stok'
                            : '+ Keranjang'}
                        </span>
                      </button>

                      <button
                        type="button"
                        disabled={isOutOfStock || remainingAllowed <= 0}
                        onClick={(e) => handleQuickAdd(product, e)}
                        className="p-2 rounded-xl border border-[#D7CCC8] hover:bg-[#EFE9E2] text-[#6B4F3E] transition-colors"
                        title="Tambah Cepat 1 Cup (Normal Ice & Normal Sugar)"
                      >
                        <span className="text-[11px] font-extrabold text-[#58311F]">⚡</span>
                      </button>

                      {/* Direct Restock Button if Out of Stock or Critical */}
                      {(isOutOfStock || isCriticalStock) && (
                        <button
                          type="button"
                          onClick={(e) => handleOpenRestock(product, e)}
                          className="px-2 py-2 rounded-xl bg-amber-100 hover:bg-amber-200 border border-amber-300 text-amber-900 font-bold text-xs transition-colors flex items-center gap-1"
                          title="Restock Cepat Stok Cup"
                        >
                          <Boxes className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Restock</span>
                        </button>
                      )}

                      {/* Tombol Ikon Pensil ✏️ di Pojok Kanan Bawah Kartu untuk Edit & Upload Foto */}
                      <button
                        type="button"
                        onClick={(e) => handleOpenEditProduct(product, e)}
                        className="p-2 rounded-xl border border-[#D4A373] bg-[#FAF6F0] hover:bg-[#D4A373]/25 text-[#58311F] hover:text-[#3E2419] transition-all hover:scale-105 active:scale-95 shadow-xs"
                        title="Edit Menu & Upload Foto (Ubah Foto, Nama, Slogan, Harga, Stok)"
                        aria-label={`Edit ${product.name}`}
                      >
                        <Pencil className="w-3.5 h-3.5 text-[#58311F]" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Fast Custom Drink Modal (Ice & Sugar Level, Notes) */}
      <CustomDrinkModal
        isOpen={!!customizingProduct}
        onClose={() => setCustomizingProduct(null)}
        product={customizingProduct}
      />
      {/* QUICK RESTOCK STOK CUP MODAL (FITUR KHUSUS OWNER RAYVANDO) */}
      {restockingProduct && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-[#E8DFD8] text-[#2D1B14] space-y-4">
            <div className="flex items-center justify-between border-b border-[#E8DFD8] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-100 text-[#7A4B2A] flex items-center justify-center">
                  <Boxes className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-[#2D1B14]">
                    Edit & Restock Stok Cup
                  </h3>
                  <p className="text-xs text-[#8C7A70]">
                    Menu: <strong className="text-[#58311F]">{restockingProduct.name}</strong>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setRestockingProduct(null)}
                className="p-1.5 rounded-lg text-[#8C7A70] hover:bg-neutral-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Current Stock Banner */}
            <div
              className={`p-3 rounded-xl border flex items-center justify-between ${
                restockingProduct.stock <= 0
                  ? 'bg-red-50 border-red-200 text-red-800'
                  : restockingProduct.stock <= 5
                  ? 'bg-amber-50 border-amber-200 text-amber-900'
                  : 'bg-[#FAF8F5] border-[#E8DFD8] text-[#58311F]'
              }`}
            >
              <div>
                <div className="text-[10px] uppercase font-bold tracking-wider opacity-80">Stok Saat Ini</div>
                <div className="text-lg font-black">{restockingProduct.stock} Cup</div>
              </div>
              {restockingProduct.stock <= 5 && (
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-red-600 text-white flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Kritis
                </span>
              )}
            </div>

            {/* Input New Stock Value */}
            <div>
              <label className="block text-xs font-semibold text-[#58311F] mb-1.5">
                Jumlah Total Stok Cup Baru:
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  value={restockAmount}
                  onChange={(e) => setRestockAmount(e.target.value)}
                  className="w-full p-2.5 pr-14 rounded-xl border border-[#D7CCC8] text-base font-bold text-[#2D1B14] focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-[#8C7A70]">
                  Cup
                </span>
              </div>
            </div>

            {/* Quick Add Presets (+10, +20, +50, Set 50) */}
            <div>
              <label className="block text-xs font-semibold text-[#58311F] mb-1.5">
                Pintasan Tambah Cepat:
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                <button
                  type="button"
                  onClick={() => handleAddStockDelta(10)}
                  className="py-2 rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] hover:bg-[#EFE9E2] text-xs font-bold text-[#58311F]"
                >
                  +10 Cup
                </button>
                <button
                  type="button"
                  onClick={() => handleAddStockDelta(20)}
                  className="py-2 rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] hover:bg-[#EFE9E2] text-xs font-bold text-[#58311F]"
                >
                  +20 Cup
                </button>
                <button
                  type="button"
                  onClick={() => handleAddStockDelta(50)}
                  className="py-2 rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] hover:bg-[#EFE9E2] text-xs font-bold text-[#58311F]"
                >
                  +50 Cup
                </button>
                <button
                  type="button"
                  onClick={() => setRestockAmount('50')}
                  className="py-2 rounded-lg bg-[#D4A373]/20 border border-[#D4A373] text-xs font-bold text-[#58311F]"
                >
                  Isi 50 Cup
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setRestockingProduct(null)}
                className="flex-1 py-2.5 rounded-xl border border-[#D7CCC8] text-xs font-semibold text-[#58311F] hover:bg-[#FAF8F5]"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmRestock}
                className="flex-1 py-2.5 rounded-xl bg-[#58311F] hover:bg-[#432314] text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all"
              >
                <Check className="w-4 h-4" />
                <span>Simpan Perubahan Stok</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Edit Produk & Upload Gambar (Owner Rayvando) */}
      <EditProductModal
        isOpen={!!editingProduct}
        onClose={() => setEditingProduct(null)}
        product={editingProduct}
      />
    </div>
  );
};
