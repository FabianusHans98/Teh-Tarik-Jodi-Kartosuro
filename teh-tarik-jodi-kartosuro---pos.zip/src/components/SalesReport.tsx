import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  DollarSign,
  Receipt,
  Award,
  CreditCard,
  Calendar,
  Coffee,
  ShoppingBag,
  ArrowUpRight,
  PieChart as PieIcon,
  BarChart3,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { formatRupiah, formatNumber } from '../utils/formatters';

export const SalesReport: React.FC = () => {
  const { transactions, shopInfo } = usePOS();
  const [timeFilter, setTimeFilter] = useState<'ALL' | 'TODAY' | '7DAYS'>('TODAY');

  // Filter transactions according to selected range
  const filteredTransactions = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const sevenDaysAgo = todayStart - 7 * 24 * 60 * 60 * 1000;

    return transactions.filter((t) => {
      const txTime = new Date(t.timestamp).getTime();
      if (timeFilter === 'TODAY') {
        return txTime >= todayStart;
      }
      if (timeFilter === '7DAYS') {
        return txTime >= sevenDaysAgo;
      }
      return true;
    });
  }, [transactions, timeFilter]);

  // Aggregate stats
  const totalRevenue = filteredTransactions.reduce((sum, t) => sum + t.grandTotal, 0);
  const totalTransactionsCount = filteredTransactions.length;
  const averageOrderValue = totalTransactionsCount > 0 ? Math.round(totalRevenue / totalTransactionsCount) : 0;

  // Best selling products
  const productSalesMap = useMemo(() => {
    const map: Record<string, { name: string; category: string; qty: number; revenue: number }> = {};

    filteredTransactions.forEach((t) => {
      t.items.forEach((item) => {
        if (!map[item.productId]) {
          map[item.productId] = {
            name: item.name,
            category: item.category || 'Menu Kedai',
            qty: 0,
            revenue: 0,
          };
        }
        map[item.productId].qty += item.quantity;
        map[item.productId].revenue += item.subtotal;
      });
    });

    return Object.values(map).sort((a, b) => b.qty - a.qty);
  }, [filteredTransactions]);

  const bestSeller = productSalesMap.length > 0 ? productSalesMap[0] : null;

  // Payment method breakdown
  const paymentBreakdown = useMemo(() => {
    const counts = { CASH: 0, QRIS: 0, BANK_TRANSFER: 0 };
    const amounts = { CASH: 0, QRIS: 0, BANK_TRANSFER: 0 };

    filteredTransactions.forEach((t) => {
      if (t.paymentMethod in counts) {
        counts[t.paymentMethod]++;
        amounts[t.paymentMethod] += t.grandTotal;
      }
    });

    return { counts, amounts };
  }, [filteredTransactions]);

  // Chart data: 7 days or hourly
  const chartBars = useMemo(() => {
    if (timeFilter === 'TODAY') {
      // Group by 4-hour slots
      const slots = [
        { label: '06-10', amount: 0, count: 0 },
        { label: '10-14', amount: 0, count: 0 },
        { label: '14-18', amount: 0, count: 0 },
        { label: '18-22', amount: 0, count: 0 },
        { label: '22-02', amount: 0, count: 0 },
      ];

      filteredTransactions.forEach((t) => {
        const hour = new Date(t.timestamp).getHours();
        if (hour >= 6 && hour < 10) slots[0].amount += t.grandTotal;
        else if (hour >= 10 && hour < 14) slots[1].amount += t.grandTotal;
        else if (hour >= 14 && hour < 18) slots[2].amount += t.grandTotal;
        else if (hour >= 18 && hour < 22) slots[3].amount += t.grandTotal;
        else slots[4].amount += t.grandTotal;
      });

      return slots;
    } else {
      // Group by last 7 days
      const days = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const dayLabel = d.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric' });
        const dateStr = d.toISOString().slice(0, 10);

        const dayTotal = filteredTransactions
          .filter(t => t.timestamp.startsWith(dateStr))
          .reduce((sum, t) => sum + t.grandTotal, 0);

        days.push({ label: dayLabel, amount: dayTotal, count: 0 });
      }
      return days;
    }
  }, [filteredTransactions, timeFilter]);

  const maxChartVal = Math.max(...chartBars.map(b => b.amount), 50000);

  return (
    <div className="flex-1 p-4 sm:p-6 bg-[#FDFBF7] overflow-y-auto space-y-5">
      {/* Top Banner & Range Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-[#E8DFD8] shadow-xs">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-[#2D1B14] flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#58311F]" />
            <span>Laporan & Analytics Penjualan Real-Time</span>
          </h2>
          <p className="text-xs text-[#8C7A70] mt-0.5">
            Kedai {shopInfo.name} • Owner: {shopInfo.ownerName}. Data dihitung langsung dari log transaksi aktif.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center gap-1.5 bg-[#FAF8F5] p-1 rounded-xl border border-[#D7CCC8]">
          <button
            onClick={() => setTimeFilter('TODAY')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              timeFilter === 'TODAY'
                ? 'bg-[#58311F] text-white shadow-xs'
                : 'text-[#6B4F3E] hover:text-[#2D1B14]'
            }`}
          >
            Hari Ini
          </button>
          <button
            onClick={() => setTimeFilter('7DAYS')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              timeFilter === '7DAYS'
                ? 'bg-[#58311F] text-white shadow-xs'
                : 'text-[#6B4F3E] hover:text-[#2D1B14]'
            }`}
          >
            7 Hari Terakhir
          </button>
          <button
            onClick={() => setTimeFilter('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              timeFilter === 'ALL'
                ? 'bg-[#58311F] text-white shadow-xs'
                : 'text-[#6B4F3E] hover:text-[#2D1B14]'
            }`}
          >
            Semua Riwayat
          </button>
        </div>
      </div>

      {/* 4 Summary Cards (Starts at 0 as requested) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Total Pendapatan */}
        <div className="bg-white p-4 rounded-2xl border border-[#E8DFD8] shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-[#8C7A70]">
            <span>Total Omzet Penjualan</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              Rp
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-[#58311F]">
            {formatRupiah(totalRevenue)}
          </div>
          <p className="text-[11px] text-[#A89F91]">
            {totalTransactionsCount > 0 ? `${totalTransactionsCount} struk terbit` : 'Belum ada transaksi'}
          </p>
        </div>

        {/* Total Transaksi */}
        <div className="bg-white p-4 rounded-2xl border border-[#E8DFD8] shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-[#8C7A70]">
            <span>Jumlah Transaksi</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-[#2D1B14]">
            {totalTransactionsCount} Transaksi
          </div>
          <p className="text-[11px] text-[#A89F91]">
            {totalTransactionsCount === 0 ? 'Siap melayani pesanan' : 'Transaksi sukses'}
          </p>
        </div>

        {/* Average Order Value (AOV) */}
        <div className="bg-white p-4 rounded-2xl border border-[#E8DFD8] shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-[#8C7A70]">
            <span>Rata-Rata Belanja (AOV)</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-[#2D1B14]">
            {formatRupiah(averageOrderValue)}
          </div>
          <p className="text-[11px] text-[#A89F91]">Per transaksi pelanggan</p>
        </div>

        {/* Best Seller Menu */}
        <div className="bg-white p-4 rounded-2xl border border-[#E8DFD8] shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-[#8C7A70]">
            <span>Menu Terlaris (Best Seller)</span>
            <div className="w-8 h-8 rounded-lg bg-yellow-50 text-yellow-600 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="text-base sm:text-lg font-bold text-[#58311F] truncate">
            {bestSeller ? bestSeller.name : '-'}
          </div>
          <p className="text-[11px] text-[#A89F91]">
            {bestSeller ? `${bestSeller.qty} cup terjual (${formatRupiah(bestSeller.revenue)})` : 'Belum ada data penjualan'}
          </p>
        </div>
      </div>

      {/* Visual Chart & Breakdown Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Sales Chart (Bar Graph) */}
        <div className="lg:col-span-2 bg-white p-4 sm:p-5 rounded-2xl border border-[#E8DFD8] shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-[#2D1B14] flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-[#58311F]" />
                <span>Grafik Perkembangan Penjualan</span>
              </h3>
              <p className="text-xs text-[#8C7A70]">
                {timeFilter === 'TODAY' ? 'Aktivitas penjualan per jam (Hari Ini)' : 'Tren penjualan 7 hari terakhir'}
              </p>
            </div>
            <span className="text-xs font-bold text-[#58311F]">
              Puncak: {formatRupiah(maxChartVal)}
            </span>
          </div>

          {/* Render Visual Bar Chart */}
          <div className="h-48 pt-6 flex items-end justify-between gap-3 border-b border-[#E8DFD8] px-2">
            {chartBars.map((bar, idx) => {
              const heightPercent = maxChartVal > 0 ? Math.round((bar.amount / maxChartVal) * 100) : 0;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group">
                  {/* Tooltip on hover */}
                  <span className="opacity-0 group-hover:opacity-100 transition-opacity text-[10px] font-bold text-[#58311F] bg-[#FAF8F5] px-1 py-0.5 rounded border shadow-xs whitespace-nowrap">
                    {formatRupiah(bar.amount)}
                  </span>
                  
                  {/* Bar */}
                  <div className="w-full max-w-[42px] bg-[#FAF8F5] rounded-t-lg overflow-hidden h-full flex items-end">
                    <div
                      style={{ height: `${Math.max(4, heightPercent)}%` }}
                      className={`w-full rounded-t-lg transition-all duration-300 ${
                        bar.amount > 0
                          ? 'bg-gradient-to-t from-[#58311F] to-[#D4A373]'
                          : 'bg-[#E8DFD8]'
                      }`}
                    />
                  </div>

                  {/* Label */}
                  <span className="text-[10px] text-[#8C7A70] font-medium text-center">
                    {bar.label}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-xs text-[#8C7A70] pt-1">
            <span>* Data grafik terupdate otomatis setiap transaksi baru terselesaikan di kasir.</span>
          </div>
        </div>

        {/* Payment Methods Breakdown */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E8DFD8] shadow-xs space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-sm text-[#2D1B14] flex items-center gap-1.5">
              <PieIcon className="w-4 h-4 text-[#58311F]" />
              <span>Metode Pembayaran</span>
            </h3>
            <p className="text-xs text-[#8C7A70]">Distribusi pembayaran yang diterima</p>
          </div>

          <div className="space-y-3 my-auto">
            {/* Cash */}
            <div className="p-2.5 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8] space-y-1">
              <div className="flex justify-between text-xs font-bold text-[#2D1B14]">
                <span>Tunai (Cash)</span>
                <span>{formatRupiah(paymentBreakdown.amounts.CASH)}</span>
              </div>
              <div className="flex justify-between text-[11px] text-[#8C7A70]">
                <span>{paymentBreakdown.counts.CASH} transaksi</span>
                <span>
                  {totalRevenue > 0
                    ? `${Math.round((paymentBreakdown.amounts.CASH / totalRevenue) * 100)}%`
                    : '0%'}
                </span>
              </div>
            </div>

            {/* QRIS */}
            <div className="p-2.5 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8] space-y-1">
              <div className="flex justify-between text-xs font-bold text-[#2D1B14]">
                <span>QRIS Instant</span>
                <span>{formatRupiah(paymentBreakdown.amounts.QRIS)}</span>
              </div>
              <div className="flex justify-between text-[11px] text-[#8C7A70]">
                <span>{paymentBreakdown.counts.QRIS} transaksi</span>
                <span>
                  {totalRevenue > 0
                    ? `${Math.round((paymentBreakdown.amounts.QRIS / totalRevenue) * 100)}%`
                    : '0%'}
                </span>
              </div>
            </div>

            {/* Bank Transfer */}
            <div className="p-2.5 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8] space-y-1">
              <div className="flex justify-between text-xs font-bold text-[#2D1B14]">
                <span>Transfer Bank</span>
                <span>{formatRupiah(paymentBreakdown.amounts.BANK_TRANSFER)}</span>
              </div>
              <div className="flex justify-between text-[11px] text-[#8C7A70]">
                <span>{paymentBreakdown.counts.BANK_TRANSFER} transaksi</span>
                <span>
                  {totalRevenue > 0
                    ? `${Math.round((paymentBreakdown.amounts.BANK_TRANSFER / totalRevenue) * 100)}%`
                    : '0%'}
                </span>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-[#E8DFD8] text-[11px] text-[#8C7A70] text-center">
            Pencatatan real-time untuk pembukuan kasir
          </div>
        </div>
      </div>

      {/* Top Sold Items Ranking */}
      <div className="bg-white rounded-2xl border border-[#E8DFD8] shadow-xs p-4 sm:p-5 space-y-3">
        <h3 className="font-bold text-sm text-[#2D1B14] flex items-center gap-2">
          <Coffee className="w-4 h-4 text-[#58311F]" />
          <span>Daftar Menu Terjual ({productSalesMap.length} Menu)</span>
        </h3>

        {productSalesMap.length === 0 ? (
          <div className="text-center py-8 text-xs text-[#8C7A70]">
            Belum ada menu yang terjual. Lakukan transaksi di terminal kasir untuk melihat statistik menu terlaris.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAF8F5] text-[#58311F] border-b border-[#E8DFD8] uppercase tracking-wider font-bold">
                <tr>
                  <th className="py-2.5 px-3">Peringkat</th>
                  <th className="py-2.5 px-3">Nama Menu</th>
                  <th className="py-2.5 px-3">Kategori</th>
                  <th className="py-2.5 px-3 text-center">Qty Terjual</th>
                  <th className="py-2.5 px-3 text-right">Total Pendapatan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F2ECE4]">
                {productSalesMap.map((prod, idx) => (
                  <tr key={prod.name} className="hover:bg-[#FAF8F5]/80">
                    <td className="py-2.5 px-3 font-bold text-[#58311F]">
                      #{idx + 1}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-[#2D1B14]">
                      {prod.name}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-[#F4EBE1] text-[#7A4B2A] text-[11px] font-medium">
                        {prod.category}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold text-[#58311F]">
                      {prod.qty} cup
                    </td>
                    <td className="py-2.5 px-3 text-right font-extrabold text-[#2D1B14]">
                      {formatRupiah(prod.revenue)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
