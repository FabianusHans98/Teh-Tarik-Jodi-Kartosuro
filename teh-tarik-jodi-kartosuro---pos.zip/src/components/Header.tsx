import React, { useState, useEffect } from 'react';
import {
  Coffee,
  Store,
  Clock,
  UserCheck,
  AlertTriangle,
  Volume2,
  VolumeX,
  LayoutGrid,
  UtensilsCrossed,
  PackageCheck,
  TrendingUp,
  ReceiptText,
  QrCode,
  Settings,
  DollarSign,
  CircleDot,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { ShiftModal } from './ShiftModal';

interface HeaderProps {
  onOpenQRISSettings?: () => void;
  onOpenPaymentSettings?: (tab?: 'qris' | 'bank' | 'profile') => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenQRISSettings, onOpenPaymentSettings }) => {
  const {
    shopInfo,
    activeTab,
    setActiveTab,
    lowStockProducts,
    totalCartItemsCount,
    soundEnabled,
    setSoundEnabled,
    currentShift,
  } = usePOS();

  const [currentTime, setCurrentTime] = useState(new Date());
  const [isShiftModalOpen, setIsShiftModalOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formattedDate = new Intl.DateTimeFormat('id-ID', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(currentTime);

  const formattedTime = new Intl.DateTimeFormat('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).format(currentTime);

  interface NavItem {
    id: 'pos' | 'menu' | 'inventory' | 'reports' | 'history';
    label: string;
    icon: React.ElementType;
    count?: number;
    alertCount?: number;
  }

  const navItems: NavItem[] = [
    { id: 'pos', label: 'Terminal Kasir', icon: LayoutGrid, count: totalCartItemsCount > 0 ? totalCartItemsCount : undefined },
    { id: 'menu', label: 'Kelola Menu', icon: UtensilsCrossed },
    { id: 'inventory', label: 'Kontrol Stok', icon: PackageCheck, alertCount: lowStockProducts.length > 0 ? lowStockProducts.length : undefined },
    { id: 'reports', label: 'Laporan Penjualan', icon: TrendingUp },
    { id: 'history', label: 'Riwayat Transaksi', icon: ReceiptText },
  ];

  return (
    <header className="bg-[#2D1B14] text-[#FAF7F2] border-b border-[#4A2E22] sticky top-0 z-40 shadow-md">
      {/* Top Banner: Brand, Greeting, Time & Cashier Status */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Left: Brand & Owner Greeting */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4A373] to-[#BC6C25] flex items-center justify-center shadow-inner text-[#2D1B14]">
            <Coffee className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-lg leading-tight tracking-tight text-[#FAF7F2] flex items-center gap-1.5">
                {shopInfo.name}
              </h1>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#BC6C25]/40 text-[#FAEDCD] border border-[#D4A373]/30">
                Kartosuro
              </span>
            </div>
            <p className="text-xs text-[#D4A373] flex items-center gap-1">
              <span>Selamat Datang,</span>
              <strong className="text-white font-semibold">{shopInfo.ownerName}</strong>
              <span className="text-xs text-[#FAF7F2]/60 hidden md:inline">| {shopInfo.tagline}</span>
            </p>
          </div>
        </div>

        {/* Right: Real-time Date/Clock, Cashier Status, Alerts, Sound */}
        <div className="flex items-center gap-2 sm:gap-4 text-xs">
          {/* Low Stock Warning Pill if any */}
          {lowStockProducts.length > 0 && (
            <button
              onClick={() => setActiveTab('inventory')}
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-colors"
              title="Periksa inventaris yang menipis"
            >
              <AlertTriangle className="w-3.5 h-3.5 animate-pulse text-amber-400" />
              <span className="font-medium">{lowStockProducts.length} Menu Stok Menipis</span>
            </button>
          )}

          {/* Real-time Clock */}
          <div className="flex items-center gap-1.5 bg-[#1F130D] px-3 py-1.5 rounded-lg border border-[#3E2419] font-receipt text-[#FAEDCD]">
            <Clock className="w-3.5 h-3.5 text-[#D4A373]" />
            <span className="font-medium tracking-wide">
              {formattedDate} • <span className="font-bold text-amber-400">{formattedTime}</span>
            </span>
          </div>

          {/* Active Cashier & Shift Status (Clickable to Open ShiftModal) */}
          <button
            type="button"
            onClick={() => setIsShiftModalOpen(true)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all shadow-2xs ${
              currentShift
                ? 'bg-[#1F130D] hover:bg-[#341B10] border-emerald-500/50 text-[#FAF7F2]'
                : 'bg-amber-500/20 hover:bg-amber-500/30 border-amber-500/50 text-amber-200'
            }`}
            title={
              currentShift
                ? `Shift Aktif: ${currentShift.cashierName} (Mulai: ${new Date(currentShift.startTime).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}). Klik untuk Tutup Shift & Rekonsiliasi Kas.`
                : 'Belum Ada Shift Aktif. Klik untuk Membuka Shift Kasir Baru.'
            }
          >
            {currentShift ? (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="text-[#FAF7F2]/90 flex items-center gap-1.5 text-xs">
                  <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-semibold text-white">{currentShift.cashierName}</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/25 text-emerald-300 font-bold border border-emerald-500/40 hidden sm:inline">
                    Shift Aktif
                  </span>
                </span>
              </>
            ) : (
              <>
                <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                <span className="font-bold text-xs text-amber-300">Buka Shift Kasir</span>
              </>
            )}
          </button>

          {/* Quick Payment Settings Button for Owner Rayvando */}
          {(onOpenPaymentSettings || onOpenQRISSettings) && (
            <button
              onClick={() => {
                if (onOpenPaymentSettings) onOpenPaymentSettings('qris');
                else if (onOpenQRISSettings) onOpenQRISSettings();
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#58311F] hover:bg-[#703D27] text-[#FAEDCD] hover:text-white border border-[#D4A373]/40 font-bold transition-all shadow-xs active:scale-95"
              title="Atur QRIS, Transfer Bank & Profil Toko (Owner: Rayvando)"
            >
              <QrCode className="w-3.5 h-3.5 text-[#D4A373]" />
              <span className="hidden sm:inline text-xs">Atur QRIS & Bank</span>
            </button>
          )}

          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-1.5 rounded-lg bg-[#1F130D] text-[#D4A373] hover:text-white hover:bg-[#3E2419] border border-[#3E2419] transition-colors"
            title={soundEnabled ? 'Matikan Suara Beep' : 'Nyalakan Suara Beep'}
            aria-label="Sound Toggle"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-red-400" />}
          </button>
        </div>
      </div>

      {/* Navigation Sub-bar */}
      <div className="bg-[#24150F] border-t border-[#3D2319] px-4 overflow-x-auto">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-1 sm:gap-2 py-1">
          <div className="flex items-center gap-1 sm:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all duration-150 ${
                    isActive
                      ? 'bg-[#D4A373] text-[#24150F] shadow-sm font-bold'
                      : 'text-[#E6CCB2] hover:bg-[#382117] hover:text-white'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#24150F]' : 'text-[#D4A373]'}`} />
                  <span>{item.label}</span>

                  {/* Cart badge count */}
                  {item.count !== undefined && (
                    <span
                      className={`ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                        isActive ? 'bg-[#24150F] text-[#D4A373]' : 'bg-[#D4A373] text-[#24150F]'
                      }`}
                    >
                      {item.count}
                    </span>
                  )}

                  {/* Inventory alert count */}
                  {item.alertCount !== undefined && (
                    <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500 text-[#24150F]">
                      {item.alertCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Direct Payment & QRIS Setting Link on Right of Nav */}
          {(onOpenPaymentSettings || onOpenQRISSettings) && (
            <button
              type="button"
              onClick={() => {
                if (onOpenPaymentSettings) onOpenPaymentSettings('qris');
                else if (onOpenQRISSettings) onOpenQRISSettings();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-[#D4A373] hover:text-white hover:bg-[#382117] transition-colors border border-[#4A2E22] shrink-0"
            >
              <Settings className="w-3.5 h-3.5 text-[#D4A373]" />
              <span className="hidden md:inline">Pengaturan Pembayaran & QRIS</span>
            </button>
          )}
        </div>
      </div>

      {/* Shift Management Modal (Buka / Tutup Shift & Rekonsiliasi Kas Laci) */}
      <ShiftModal
        isOpen={isShiftModalOpen}
        onClose={() => setIsShiftModalOpen(false)}
      />
    </header>
  );
};
