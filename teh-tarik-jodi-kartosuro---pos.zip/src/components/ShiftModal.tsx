import React, { useState } from 'react';
import {
  X,
  Clock,
  Coins,
  DollarSign,
  TrendingUp,
  Receipt,
  UserCheck,
  AlertTriangle,
  CheckCircle2,
  Lock,
  Unlock,
  History,
  Info,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { formatRupiah, formatDateTimeIndo } from '../utils/formatters';

interface ShiftModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShiftModal: React.FC<ShiftModalProps> = ({ isOpen, onClose }) => {
  const {
    currentShift,
    shiftHistory,
    startShift,
    endShift,
    shopInfo,
  } = usePOS();

  const [activeView, setActiveView] = useState<'current' | 'history'>('current');
  const [startingCashInput, setStartingCashInput] = useState<string>('100000');
  const [cashierNameInput, setCashierNameInput] = useState<string>(shopInfo.cashierName || 'Rayvando');
  const [actualCashInput, setActualCashInput] = useState<string>('');
  const [closingNotes, setClosingNotes] = useState<string>('');
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isOpen) return null;

  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    const cash = parseInt(startingCashInput, 10);
    if (isNaN(cash) || cash < 0) {
      setNotification({ type: 'error', message: 'Masukkan nominal modal uang awal yang valid.' });
      return;
    }
    startShift(cash, cashierNameInput.trim() || shopInfo.cashierName);
    setNotification({ type: 'success', message: 'Shift kasir berhasil dibuka!' });
    setTimeout(() => setNotification(null), 2500);
  };

  const handleEnd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShift) return;
    const actual = parseInt(actualCashInput, 10);
    if (isNaN(actual) || actual < 0) {
      setNotification({ type: 'error', message: 'Harap hitung dan masukkan uang fisik aktual di laci kasir.' });
      return;
    }

    const closed = endShift(actual, closingNotes);
    if (closed) {
      setNotification({ type: 'success', message: 'Shift berhasil ditutup dan direkapitulasi!' });
      setActualCashInput('');
      setClosingNotes('');
      setTimeout(() => setNotification(null), 3000);
    }
  };

  const actualNum = parseInt(actualCashInput, 10);
  const diff = !isNaN(actualNum) && currentShift ? actualNum - currentShift.expectedCash : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="bg-[#FAF7F2] rounded-3xl w-full max-w-xl shadow-2xl border border-[#D7CCC8] overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Modal */}
        <div className="px-5 py-4 bg-[#58311F] text-white flex items-center justify-between border-b border-[#432314]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#D4A373]/20 flex items-center justify-center border border-[#D4A373]/30">
              <Coins className="w-5 h-5 text-[#D4A373]" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight">
                Manajemen Shift &amp; Cash Drawer
              </h2>
              <p className="text-xs text-[#E8DFD8]">
                Buka/tutup shift, modal awal &amp; rekonsiliasi uang fisik di laci
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#E8DFD8] hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* View Tabs */}
        <div className="px-5 pt-3 pb-1 bg-white border-b border-[#E8DFD8] flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveView('current')}
            className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeView === 'current'
                ? 'bg-[#58311F] text-white shadow-xs'
                : 'text-[#6B4F3E] hover:bg-[#FAF8F5]'
            }`}
          >
            {currentShift ? (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Shift Aktif Sekarang
              </>
            ) : (
              <>
                <Unlock className="w-3.5 h-3.5" />
                Buka Shift Baru
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveView('history')}
            className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeView === 'history'
                ? 'bg-[#58311F] text-white shadow-xs'
                : 'text-[#6B4F3E] hover:bg-[#FAF8F5]'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            Riwayat Shift ({shiftHistory.length})
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {notification && (
            <div
              className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 border ${
                notification.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : 'bg-red-50 text-red-800 border-red-200'
              }`}
            >
              {notification.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
              )}
              <span>{notification.message}</span>
            </div>
          )}

          {activeView === 'history' ? (
            /* Tab Riwayat Shift */
            <div className="space-y-3">
              {shiftHistory.length === 0 ? (
                <div className="text-center py-10 text-[#8C7A70]">
                  <History className="w-10 h-10 mx-auto mb-2 opacity-40 text-[#58311F]" />
                  <p className="font-bold text-sm text-[#2D1B14]">Belum Ada Riwayat Shift</p>
                  <p className="text-xs">
                    Catatan shift yang telah ditutup akan terdaftar secara otomatis di sini.
                  </p>
                </div>
              ) : (
                shiftHistory.map((s) => (
                  <div
                    key={s.id}
                    className="p-3.5 rounded-2xl bg-white border border-[#E8DFD8] shadow-xs space-y-2.5"
                  >
                    <div className="flex items-center justify-between border-b border-[#F4EBE1] pb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-neutral-400" />
                        <span className="font-bold text-xs text-[#2D1B14]">
                          {s.cashierName}
                        </span>
                        <span className="text-[10px] text-[#8C7A70]">
                          ({s.transactionCount} transaksi)
                        </span>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-600">
                        Shift Selesai
                      </span>
                    </div>

                    <div className="text-[11px] text-[#8C7A70] flex flex-wrap justify-between gap-1">
                      <span>Mulai: {formatDateTimeIndo(s.startTime)}</span>
                      {s.endTime && <span>Selesai: {formatDateTimeIndo(s.endTime)}</span>}
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                      <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8]">
                        <span className="text-[10px] text-[#8C7A70] block">Modal Awal:</span>
                        <strong className="text-xs text-[#58311F]">
                          {formatRupiah(s.startingCash)}
                        </strong>
                      </div>
                      <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8]">
                        <span className="text-[10px] text-[#8C7A70] block">Total Penjualan:</span>
                        <strong className="text-xs text-emerald-700">
                          {formatRupiah(s.totalSales)}
                        </strong>
                      </div>
                      <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8]">
                        <span className="text-[10px] text-[#8C7A70] block">Uang Fisik Aktual:</span>
                        <strong className="text-xs text-[#2D1B14]">
                          {formatRupiah(s.actualCash || 0)}
                        </strong>
                      </div>
                      <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8]">
                        <span className="text-[10px] text-[#8C7A70] block">Selisih Fisik:</span>
                        <strong
                          className={`text-xs ${
                            (s.cashDifference || 0) === 0
                              ? 'text-emerald-600'
                              : (s.cashDifference || 0) > 0
                              ? 'text-blue-600'
                              : 'text-red-600'
                          }`}
                        >
                          {(s.cashDifference || 0) > 0 ? '+' : ''}
                          {formatRupiah(s.cashDifference || 0)}
                        </strong>
                      </div>
                    </div>

                    {s.notes && (
                      <p className="text-[11px] text-[#8C7A70] bg-[#FAF8F5] p-2 rounded-lg italic">
                        Catatan: "{s.notes}"
                      </p>
                    )}
                  </div>
                ))
              )}
            </div>
          ) : currentShift ? (
            /* Shift Aktif: Detail & Form Tutup Shift */
            <div className="space-y-4">
              {/* Active Status Card */}
              <div className="p-4 rounded-2xl bg-[#58311F] text-white space-y-3 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
                    </span>
                    <span className="text-xs font-black tracking-wider uppercase text-[#D4A373]">
                      Shift Kasir Sedang Aktif
                    </span>
                  </div>
                  <span className="text-xs text-[#E8DFD8] flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    Mulai: {formatDateTimeIndo(currentShift.startTime)}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-1">
                  <div className="p-2.5 rounded-xl bg-black/25 border border-white/10">
                    <span className="text-[11px] text-[#D4A373] block">Kasir Bertugas:</span>
                    <strong className="text-sm text-white font-bold">
                      {currentShift.cashierName}
                    </strong>
                  </div>

                  <div className="p-2.5 rounded-xl bg-black/25 border border-white/10">
                    <span className="text-[11px] text-[#D4A373] block">Modal Awal Laci:</span>
                    <strong className="text-sm text-white font-bold">
                      {formatRupiah(currentShift.startingCash)}
                    </strong>
                  </div>

                  <div className="p-2.5 rounded-xl bg-black/25 border border-white/10 col-span-2 sm:col-span-1">
                    <span className="text-[11px] text-[#D4A373] block">Total Transaksi:</span>
                    <strong className="text-sm text-white font-bold">
                      {currentShift.transactionCount} Pesanan
                    </strong>
                  </div>
                </div>
              </div>

              {/* Rincian Penjualan Shift */}
              <div className="bg-white rounded-2xl p-4 border border-[#E8DFD8] space-y-3 shadow-xs">
                <h3 className="text-xs font-extrabold text-[#58311F] uppercase tracking-wider">
                  Rincian Penjualan Pada Shift Ini
                </h3>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="p-2.5 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8]">
                    <span className="text-[10px] font-bold text-[#8C7A70] block">💵 Tunai (Cash)</span>
                    <strong className="text-xs sm:text-sm font-extrabold text-[#58311F]">
                      {formatRupiah(currentShift.totalCashSales)}
                    </strong>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8]">
                    <span className="text-[10px] font-bold text-[#8C7A70] block">📱 QRIS</span>
                    <strong className="text-xs sm:text-sm font-extrabold text-blue-800">
                      {formatRupiah(currentShift.totalQrisSales)}
                    </strong>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[#FAF8F5] border border-[#E8DFD8]">
                    <span className="text-[10px] font-bold text-[#8C7A70] block">🏦 Transfer Bank</span>
                    <strong className="text-xs sm:text-sm font-extrabold text-purple-800">
                      {formatRupiah(currentShift.totalBankSales)}
                    </strong>
                  </div>
                </div>

                {/* Highlight Uang Fisik Yang Seharusnya di Laci */}
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Coins className="w-5 h-5 text-amber-700 shrink-0" />
                    <div>
                      <span className="text-xs font-black text-amber-900 block">
                        Uang Tunai Fisik Seharusnya di Laci:
                      </span>
                      <span className="text-[10px] text-amber-800">
                        Modal Awal ({formatRupiah(currentShift.startingCash)}) + Penjualan Tunai ({formatRupiah(currentShift.totalCashSales)})
                      </span>
                    </div>
                  </div>
                  <strong className="text-base sm:text-lg font-black text-amber-900 font-mono">
                    {formatRupiah(currentShift.expectedCash)}
                  </strong>
                </div>
              </div>

              {/* Form Tutup Shift & Rekonsiliasi */}
              <form onSubmit={handleEnd} className="bg-white rounded-2xl p-4 border border-[#E8DFD8] space-y-3.5 shadow-xs">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#8B4513]" />
                  <h3 className="text-xs font-extrabold text-[#58311F] uppercase tracking-wider">
                    Rekapitulasi Akhir &amp; Tutup Shift
                  </h3>
                </div>

                <div>
                  <label className="text-xs font-bold text-[#2D1B14] block mb-1">
                    Hitung &amp; Masukkan Uang Fisik Aktual di Laci (Rp) <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-[#8C7A70]">
                      Rp
                    </span>
                    <input
                      type="number"
                      required
                      min="0"
                      value={actualCashInput}
                      onChange={(e) => setActualCashInput(e.target.value)}
                      placeholder="Contoh: 350000"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-base font-extrabold font-mono text-[#58311F] focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                    />
                  </div>

                  {/* Real-time Difference Feedback */}
                  {actualCashInput && !isNaN(actualNum) && (
                    <div
                      className={`mt-2 p-2.5 rounded-xl border text-xs font-bold flex items-center justify-between ${
                        diff === 0
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : diff > 0
                          ? 'bg-blue-50 text-blue-800 border-blue-200'
                          : 'bg-red-50 text-red-800 border-red-200'
                      }`}
                    >
                      <span className="flex items-center gap-1.5">
                        {diff === 0 ? (
                          <>
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            Uang Fisik Pas &amp; Sesuai Sistem
                          </>
                        ) : diff > 0 ? (
                          <>
                            <Info className="w-4 h-4 text-blue-600" />
                            Uang Fisik Lebih (Kelebihan)
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-4 h-4 text-red-600" />
                            Uang Fisik Kurang (Selisih Negatif)
                          </>
                        )}
                      </span>
                      <strong className="font-mono">
                        {diff > 0 ? '+' : ''}
                        {formatRupiah(diff)}
                      </strong>
                    </div>
                  )}
                </div>

                <div>
                  <label className="text-xs font-bold text-[#2D1B14] block mb-1">
                    Catatan Penutupan Shift (Opsional)
                  </label>
                  <input
                    type="text"
                    value={closingNotes}
                    onChange={(e) => setClosingNotes(e.target.value)}
                    placeholder="Contoh: Selisih uang receh kembalian 2rb"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all active:scale-95"
                >
                  <Lock className="w-4 h-4" />
                  <span>Tutup Shift Kasir &amp; Rekap Laci</span>
                </button>
              </form>
            </div>
          ) : (
            /* Form Buka Shift Baru */
            <form onSubmit={handleStart} className="space-y-4">
              <div className="p-4 rounded-2xl bg-white border border-[#E8DFD8] space-y-3.5 shadow-xs">
                <div className="flex items-center gap-2">
                  <Unlock className="w-5 h-5 text-[#8B4513]" />
                  <div>
                    <h3 className="text-xs font-extrabold text-[#58311F] uppercase tracking-wider">
                      Mulai Bertugas (Buka Shift)
                    </h3>
                    <p className="text-[11px] text-[#8C7A70]">
                      Masukkan modal uang awal (*starting cash*) yang disiapkan di laci kasir
                    </p>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-[#2D1B14] block mb-1">
                    Modal Uang Awal di Laci (Rp) <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-[#8C7A70]">
                      Rp
                    </span>
                    <input
                      type="number"
                      required
                      min="0"
                      step="1000"
                      value={startingCashInput}
                      onChange={(e) => setStartingCashInput(e.target.value)}
                      placeholder="100000"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-base font-extrabold font-mono text-[#58311F] focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                    />
                  </div>

                  {/* Preset Buttons */}
                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {[50000, 100000, 200000, 300000, 500000].map((nominal) => (
                      <button
                        key={nominal}
                        type="button"
                        onClick={() => setStartingCashInput(nominal.toString())}
                        className="px-2.5 py-1 rounded-lg text-xs font-bold bg-[#FAF8F5] border border-[#D7CCC8] hover:bg-[#F2ECE4] text-[#58311F] transition-colors"
                      >
                        {formatRupiah(nominal)}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-[#2D1B14] block mb-1">
                    Nama Kasir Bertugas
                  </label>
                  <input
                    type="text"
                    value={cashierNameInput}
                    onChange={(e) => setCashierNameInput(e.target.value)}
                    placeholder="Rayvando"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-[#58311F] hover:bg-[#432314] text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-95"
              >
                <Unlock className="w-4 h-4 text-[#D4A373]" />
                <span>🟢 Buka Shift Kasir Sekarang</span>
              </button>
            </form>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3.5 bg-white border-t border-[#E8DFD8] flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-[#D7CCC8] text-xs font-bold text-[#6B574B] hover:bg-[#FAF8F5]"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
