import React, { useState } from 'react';
import {
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  Tag,
  Percent,
  Coins,
  Utensils,
  Package,
  User,
  Hash,
  Receipt,
  ChevronRight,
  AlertCircle,
  FileText,
  Coffee,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { formatRupiah } from '../utils/formatters';

interface CartSidebarProps {
  onOpenPayment: () => void;
}

export const CartSidebar: React.FC<CartSidebarProps> = ({ onOpenPayment }) => {
  const {
    cart,
    updateQuantity,
    updateNotes,
    removeFromCart,
    clearCart,
    orderType,
    setOrderType,
    customerName,
    setCustomerName,
    tableNumber,
    setTableNumber,
    discount,
    setDiscount,
    taxEnabled,
    setTaxEnabled,
    cartSubtotal,
    discountAmount,
    taxAmount,
    serviceFeeAmount,
    cartGrandTotal,
    totalCartItemsCount,
    shopInfo,
  } = usePOS();

  const [isEditingDiscount, setIsEditingDiscount] = useState(false);
  const [discountValInput, setDiscountValInput] = useState(discount.value.toString());
  const [discountTypeInput, setDiscountTypeInput] = useState<'PERCENTAGE' | 'NOMINAL'>(discount.type);

  const [editingNoteItemId, setEditingNoteItemId] = useState<string | null>(null);
  const [tempNote, setTempNote] = useState('');

  const handleApplyDiscount = () => {
    const num = Math.max(0, parseInt(discountValInput, 10) || 0);
    setDiscount({
      type: discountTypeInput,
      value: num,
    });
    setIsEditingDiscount(false);
  };

  const handleStartEditNote = (itemId: string, currentNote: string) => {
    setEditingNoteItemId(itemId);
    setTempNote(currentNote);
  };

  const handleSaveNote = (itemId: string) => {
    updateNotes(itemId, tempNote);
    setEditingNoteItemId(null);
  };

  return (
    <div className="w-full lg:w-96 flex flex-col h-full bg-white border-l border-[#E8DFD8] shadow-sm">
      {/* Header Cart */}
      <div className="p-3.5 border-b border-[#E8DFD8] bg-[#FAF8F5] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#58311F] text-[#D4A373] flex items-center justify-center">
            <ShoppingBag className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-bold text-sm text-[#2D1B14] flex items-center gap-1.5">
              <span>Keranjang Pesanan</span>
              <span className="text-xs px-2 py-0.2 rounded-full bg-[#D4A373] text-[#2D1B14] font-bold">
                {totalCartItemsCount}
              </span>
            </h2>
            <p className="text-[11px] text-[#8C7A70]">Pesanan aktif kasir</p>
          </div>
        </div>

        {cart.length > 0 && (
          <button
            onClick={clearCart}
            className="text-xs text-red-600 hover:text-red-700 hover:bg-red-50 px-2 py-1 rounded-lg flex items-center gap-1 transition-colors"
            title="Kosongkan seluruh keranjang"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Kosongkan</span>
          </button>
        )}
      </div>

      {/* Dine In vs Take Away & Customer Details */}
      <div className="p-3 border-b border-[#E8DFD8] bg-white space-y-2.5">
        {/* Order Type Buttons */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#F4EBE1] rounded-xl">
          <button
            type="button"
            onClick={() => setOrderType('DINE_IN')}
            className={`py-1.5 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              orderType === 'DINE_IN'
                ? 'bg-[#58311F] text-white shadow-sm'
                : 'text-[#6B4F3E] hover:text-[#2D1B14]'
            }`}
          >
            <Utensils className="w-3.5 h-3.5" />
            <span>Dine In (Kedai)</span>
          </button>

          <button
            type="button"
            onClick={() => setOrderType('TAKE_AWAY')}
            className={`py-1.5 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              orderType === 'TAKE_AWAY'
                ? 'bg-[#58311F] text-white shadow-sm'
                : 'text-[#6B4F3E] hover:text-[#2D1B14]'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Take Away (Bungkus)</span>
          </button>
        </div>

        {/* Customer Name & Table Number Inputs */}
        <div className="space-y-1.5">
          <div className="grid grid-cols-2 gap-2">
            <div className="relative">
              <User className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#A89F91]" />
              <input
                type="text"
                placeholder="Nama Pelanggan"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full pl-8 pr-2 py-1.5 text-xs rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] focus:outline-none focus:ring-1 focus:ring-[#D4A373] text-[#2D1B14] font-medium"
              />
            </div>

            <div className="relative">
              <Hash className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#A89F91]" />
              <input
                type="text"
                placeholder={orderType === 'DINE_IN' ? 'No. Meja (cth: 04)' : 'Antrean/Catatan'}
                value={tableNumber}
                onChange={(e) => setTableNumber(e.target.value)}
                className="w-full pl-8 pr-2 py-1.5 text-xs rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] focus:outline-none focus:ring-1 focus:ring-[#D4A373] text-[#2D1B14] font-medium"
              />
            </div>
          </div>

          {/* Quick Table Selector Chips for Dine In */}
          {orderType === 'DINE_IN' && (
            <div className="flex items-center gap-1 overflow-x-auto pb-0.5 scrollbar-none">
              <span className="text-[10px] text-[#8C7A70] shrink-0 font-medium">Meja:</span>
              {['01', '02', '03', '04', '05', '06', 'Bar'].map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTableNumber(`Meja ${t}`)}
                  className={`text-[10px] px-1.5 py-0.5 rounded font-bold shrink-0 transition-colors ${
                    tableNumber.includes(t)
                      ? 'bg-[#58311F] text-white'
                      : 'bg-[#F4EBE1] text-[#6B4F3E] hover:bg-[#EAE0D5]'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Cart Items List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {cart.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-[#8C7A70]">
            <div className="w-14 h-14 rounded-2xl bg-[#F4EBE1] flex items-center justify-center mb-3">
              <ShoppingBag className="w-7 h-7 text-[#A89F91]" />
            </div>
            <p className="font-bold text-sm text-[#58311F]">Keranjang Masih Kosong</p>
            <p className="text-xs text-[#8C7A70] mt-1 max-w-[220px]">
              Klik pada menu di katalog untuk menambahkan pesanan ke daftar ini.
            </p>
          </div>
        ) : (
          cart.map((item) => {
            const itemTotal = item.price * item.quantity;
            const isEditingNote = editingNoteItemId === item.id;

            return (
              <div
                key={item.id}
                className="p-2.5 rounded-xl border border-[#E8DFD8] bg-[#FAF8F5] hover:border-[#D4A373]/50 transition-colors"
              >
                {/* Item Thumbnail, Name & Delete Button */}
                <div className="flex items-start gap-2.5">
                  {/* Mini Product Thumbnail */}
                  <div className="w-12 h-12 rounded-xl overflow-hidden bg-[#F4EBE1] border border-[#D7CCC8] shrink-0 shadow-2xs">
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[#7A4B2A]">
                        <Coffee className="w-5 h-5 opacity-70" />
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-1">
                      <h4 className="font-bold text-xs sm:text-sm text-[#2D1B14] leading-snug truncate">
                        {item.name}
                      </h4>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-neutral-400 hover:text-red-600 p-0.5 transition-colors shrink-0"
                        title="Hapus item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <span className="text-[11px] text-[#8C7A70] block">
                      {formatRupiah(item.price)} / cup
                    </span>

                    {/* Ice Level & Sugar Level Tags */}
                    <div className="flex flex-wrap items-center gap-1 mt-1">
                      {item.iceLevel && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200/60">
                          🧊 {item.iceLevel}
                        </span>
                      )}
                      {item.sugarLevel && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-900 border border-amber-200/60">
                          🍯 {item.sugarLevel}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Notes Display / Edit */}
                <div className="mt-1.5">
                  {isEditingNote ? (
                    <div className="flex items-center gap-1">
                      <input
                        type="text"
                        value={tempNote}
                        onChange={(e) => setTempNote(e.target.value)}
                        placeholder="Catatan racikan..."
                        className="flex-1 text-xs px-2 py-1 rounded border border-[#D7CCC8] bg-white focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                        autoFocus
                        onKeyDown={(e) => e.key === 'Enter' && handleSaveNote(item.id)}
                      />
                      <button
                        onClick={() => handleSaveNote(item.id)}
                        className="px-2 py-1 text-xs bg-[#58311F] text-white rounded font-medium"
                      >
                        OK
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleStartEditNote(item.id, item.notes)}
                      className="text-[11px] text-[#8B5E3C] hover:text-[#58311F] flex items-center gap-1 italic text-left"
                      title="Klik untuk ubah catatan"
                    >
                      <FileText className="w-3 h-3 text-[#A89F91]" />
                      <span>{item.notes ? `"${item.notes}"` : '+ Catatan khusus (less ice, dll)'}</span>
                    </button>
                  )}
                </div>

                {/* Quantity Controls & Subtotal */}
                <div className="mt-2 pt-2 border-t border-[#EFE9E2] flex items-center justify-between">
                  <div className="flex items-center gap-1.5 bg-white rounded-lg border border-[#D7CCC8] p-0.5">
                    <button
                      onClick={() => updateQuantity(item.id, -1)}
                      className="w-6 h-6 flex items-center justify-center rounded hover:bg-neutral-100 text-[#58311F] active:scale-95"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-6 text-center font-bold text-xs text-[#2D1B14]">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.id, 1)}
                      disabled={item.quantity >= item.maxStock}
                      className={`w-6 h-6 flex items-center justify-center rounded text-[#58311F] ${
                        item.quantity >= item.maxStock
                          ? 'opacity-40 cursor-not-allowed'
                          : 'hover:bg-neutral-100 active:scale-95'
                      }`}
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <span className="font-extrabold text-xs sm:text-sm text-[#58311F]">
                    {formatRupiah(itemTotal)}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Bill Calculations & Footer Actions */}
      <div className="p-3.5 border-t border-[#E8DFD8] bg-[#FAF8F5] space-y-2.5">
        {/* Discount & Tax Options */}
        <div className="flex items-center justify-between gap-2 text-xs">
          {/* Discount Trigger */}
          <button
            onClick={() => setIsEditingDiscount(!isEditingDiscount)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-xs font-semibold transition-colors ${
              discount.value > 0
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                : 'bg-white text-[#6B4F3E] border-[#D7CCC8] hover:bg-[#F2ECE4]'
            }`}
          >
            <Tag className="w-3 h-3 text-emerald-600" />
            <span>
              {discount.value > 0
                ? `Diskon: ${discount.type === 'PERCENTAGE' ? `${discount.value}%` : formatRupiah(discount.value)}`
                : '+ Diskon / Promo'}
            </span>
          </button>

          {/* Tax PB1 Toggle */}
          <label className="flex items-center gap-1.5 cursor-pointer text-xs text-[#6B4F3E]">
            <input
              type="checkbox"
              checked={taxEnabled}
              onChange={(e) => setTaxEnabled(e.target.checked)}
              className="rounded border-[#D7CCC8] text-[#58311F] focus:ring-[#D4A373]"
            />
            <span>PB1 Resto (10%)</span>
          </label>
        </div>

        {/* Discount Edit Form Dropdown */}
        {isEditingDiscount && (
          <div className="p-2.5 bg-white rounded-xl border border-[#D7CCC8] shadow-sm space-y-2 animate-in fade-in duration-100">
            <div className="flex items-center justify-between text-xs font-semibold text-[#58311F]">
              <span>Atur Diskon Pesanan:</span>
              <button
                onClick={() => {
                  setDiscount({ type: 'NOMINAL', value: 0 });
                  setDiscountValInput('0');
                  setIsEditingDiscount(false);
                }}
                className="text-[11px] text-red-600 hover:underline"
              >
                Hapus Diskon
              </button>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setDiscountTypeInput('NOMINAL')}
                className={`flex-1 py-1 text-xs font-bold rounded-lg border ${
                  discountTypeInput === 'NOMINAL'
                    ? 'bg-[#58311F] text-white border-[#58311F]'
                    : 'bg-[#FAF8F5] text-[#58311F] border-[#D7CCC8]'
                }`}
              >
                Nominal (Rp)
              </button>
              <button
                type="button"
                onClick={() => setDiscountTypeInput('PERCENTAGE')}
                className={`flex-1 py-1 text-xs font-bold rounded-lg border ${
                  discountTypeInput === 'PERCENTAGE'
                    ? 'bg-[#58311F] text-white border-[#58311F]'
                    : 'bg-[#FAF8F5] text-[#58311F] border-[#D7CCC8]'
                }`}
              >
                Persentase (%)
              </button>
            </div>

            <div className="flex items-center gap-1.5">
              <input
                type="number"
                min="0"
                value={discountValInput}
                onChange={(e) => setDiscountValInput(e.target.value)}
                placeholder={discountTypeInput === 'PERCENTAGE' ? 'Cth: 10' : 'Cth: 5000'}
                className="flex-1 px-2.5 py-1 text-xs rounded-lg border border-[#D7CCC8] bg-[#FAF8F5]"
              />
              <button
                type="button"
                onClick={handleApplyDiscount}
                className="px-3 py-1 bg-[#58311F] text-white text-xs font-bold rounded-lg"
              >
                Pasang
              </button>
            </div>
          </div>
        )}

        {/* Calculation Rows */}
        <div className="space-y-1 text-xs pt-1 border-t border-[#EFE9E2]">
          <div className="flex justify-between text-[#6B4F3E]">
            <span>Subtotal</span>
            <span className="font-semibold text-[#2D1B14]">{formatRupiah(cartSubtotal)}</span>
          </div>

          {discountAmount > 0 && (
            <div className="flex justify-between text-emerald-700 font-medium">
              <span>Diskon</span>
              <span>- {formatRupiah(discountAmount)}</span>
            </div>
          )}

          {taxAmount > 0 && (
            <div className="flex justify-between text-[#6B4F3E]">
              <span>PB1 (10%)</span>
              <span>+ {formatRupiah(taxAmount)}</span>
            </div>
          )}

          <div className="flex justify-between items-baseline pt-1.5 border-t border-[#E8DFD8]">
            <span className="font-bold text-sm text-[#2D1B14]">Total Tagihan</span>
            <span className="font-extrabold text-lg text-[#58311F]">
              {formatRupiah(cartGrandTotal)}
            </span>
          </div>
        </div>

        {/* Checkout Button */}
        <button
          type="button"
          disabled={cart.length === 0}
          onClick={onOpenPayment}
          className={`w-full py-3 px-4 rounded-xl font-bold text-sm flex items-center justify-between transition-all shadow-md active:scale-[0.99] ${
            cart.length === 0
              ? 'bg-neutral-200 text-neutral-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-[#58311F] to-[#7A4B2A] hover:from-[#432314] hover:to-[#58311F] text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-[#D4A373]" />
            <span>Bayar Sekarang</span>
          </div>
          <div className="flex items-center gap-1 font-extrabold text-[#FAEDCD]">
            <span>{formatRupiah(cartGrandTotal)}</span>
            <ChevronRight className="w-4 h-4 text-[#D4A373]" />
          </div>
        </button>
      </div>
    </div>
  );
};
