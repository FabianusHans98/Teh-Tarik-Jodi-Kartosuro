import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Upload,
  QrCode,
  CreditCard,
  Store,
  Check,
  RotateCcw,
  Image as ImageIcon,
  Trash2,
  AlertCircle,
  Eye,
  ShieldCheck,
  Plus,
  Edit2,
  Building2,
  User,
  Phone,
  Copy,
  Sparkles,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { ShopInfo, BankAccount } from '../types';

interface PaymentSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'qris' | 'bank' | 'profile';
}

const COMMON_BANKS = ['BCA', 'Mandiri', 'BRI', 'BNI', 'BSI', 'CIMB Niaga', 'Bank Jago', 'Permata'];

export const PaymentSettingsModal: React.FC<PaymentSettingsModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'qris',
}) => {
  const { shopInfo, setShopInfo } = usePOS();

  const [activeTab, setActiveTab] = useState<'qris' | 'bank' | 'profile'>(initialTab);
  const [formData, setFormData] = useState<ShopInfo>(() => ({ ...shopInfo }));
  const [dragActive, setDragActive] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Bank edit state
  const [editingBankIndex, setEditingBankIndex] = useState<number | null>(null);
  const [bankForm, setBankForm] = useState<BankAccount>({
    bankName: 'BCA',
    accountNumber: '',
    holderName: shopInfo.ownerName || 'RAYVANDO',
  });
  const [isAddingBank, setIsAddingBank] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setFormData({
        ...shopInfo,
        bankAccounts: shopInfo.bankAccounts ? [...shopInfo.bankAccounts] : [],
      });
      setActiveTab(initialTab);
      setSaveSuccess(false);
      setErrorMsg(null);
      setIsAddingBank(false);
      setEditingBankIndex(null);
    }
  }, [isOpen, shopInfo, initialTab]);

  if (!isOpen) return null;

  // Handle image upload & convert to base64
  const handleFileProcess = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Harap pilih file gambar (JPG, PNG, WEBP).');
      return;
    }

    if (file.size > 4 * 1024 * 1024) {
      setErrorMsg('Ukuran file gambar maksimal 4MB agar performa tetap cepat.');
      return;
    }

    setErrorMsg(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setFormData((prev) => ({
          ...prev,
          qrisImageUrl: result,
        }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  const handleRemoveImage = () => {
    setFormData((prev) => ({
      ...prev,
      qrisImageUrl: undefined,
    }));
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Bank management helpers
  const handleStartAddBank = () => {
    setBankForm({
      bankName: 'BCA',
      accountNumber: '',
      holderName: formData.ownerName || 'RAYVANDO',
    });
    setEditingBankIndex(null);
    setIsAddingBank(true);
  };

  const handleStartEditBank = (index: number) => {
    setBankForm({ ...formData.bankAccounts[index] });
    setEditingBankIndex(index);
    setIsAddingBank(true);
  };

  const handleSaveBankForm = () => {
    if (!bankForm.bankName.trim()) {
      setErrorMsg('Nama bank wajib diisi.');
      return;
    }
    if (!bankForm.accountNumber.trim()) {
      setErrorMsg('Nomor rekening bank wajib diisi.');
      return;
    }
    if (!bankForm.holderName.trim()) {
      setErrorMsg('Nama pemilik rekening (atas nama) wajib diisi.');
      return;
    }

    setErrorMsg(null);
    const currentBanks = [...formData.bankAccounts];

    if (editingBankIndex !== null) {
      currentBanks[editingBankIndex] = { ...bankForm };
    } else {
      currentBanks.push({ ...bankForm });
    }

    setFormData((prev) => ({
      ...prev,
      bankAccounts: currentBanks,
    }));
    setIsAddingBank(false);
    setEditingBankIndex(null);
  };

  const handleDeleteBank = (index: number) => {
    if (formData.bankAccounts.length <= 1) {
      if (!confirm('Ini adalah satu-satunya rekening bank. Yakin ingin menghapusnya?')) {
        return;
      }
    }
    const updated = formData.bankAccounts.filter((_, i) => i !== index);
    setFormData((prev) => ({
      ...prev,
      bankAccounts: updated,
    }));
    if (editingBankIndex === index) {
      setIsAddingBank(false);
      setEditingBankIndex(null);
    }
  };

  // Save changes to global state
  const handleSaveAll = () => {
    setShopInfo(formData);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 1000);
  };

  const handleResetToDefault = () => {
    if (confirm('Kembalikan konfigurasi pembayaran dan kedai ke format standar sistem?')) {
      setFormData((prev) => ({
        ...prev,
        qrisName: 'TEH TARIK JODI KARTOSURO',
        qrisNmid: 'ID1020083920192',
        qrisNotes: 'Mendukung pembayaran scan QRIS: BCA, Livin, BRImo, GoPay, OVO, DANA, ShopeePay & LinkAja',
        qrisImageUrl: undefined,
        bankAccounts: [
          {
            bankName: 'BCA',
            accountNumber: '0158-9283-11',
            holderName: 'RAYVANDO',
          },
          {
            bankName: 'MANDIRI',
            accountNumber: '138-00-1928471-2',
            holderName: 'RAYVANDO',
          },
        ],
      }));
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-[#E8DFD8] overflow-hidden my-auto flex flex-col max-h-[95vh]">
        {/* Header Bar */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#2D1B14] via-[#4A2E22] to-[#58311F] text-[#FAF7F2] flex items-center justify-between border-b border-[#4A2E22]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#D4A373] text-[#2D1B14] flex items-center justify-center shadow-inner font-extrabold">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base sm:text-lg text-white">
                  Panel Pengaturan Pembayaran Kedai
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#D4A373] text-[#2D1B14]">
                  Owner: Rayvando
                </span>
              </div>
              <p className="text-xs text-[#D4A373]">
                Kelola QRIS, rekening Transfer Bank dinamis, dan identitas nota Teh Tarik Jodi Kartosuro.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#FAF7F2]/70 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#E8DFD8] bg-[#FAF8F5] px-4 pt-2 gap-2 overflow-x-auto">
          <button
            type="button"
            onClick={() => {
              setActiveTab('qris');
              setIsAddingBank(false);
            }}
            className={`px-4 py-2.5 rounded-t-xl text-xs font-bold flex items-center gap-2 transition-all border-b-2 ${
              activeTab === 'qris'
                ? 'bg-white text-[#58311F] border-[#58311F] shadow-xs'
                : 'text-[#8C7A70] hover:text-[#58311F] border-transparent'
            }`}
          >
            <QrCode className="w-4 h-4 text-[#D4A373]" />
            <span>1. QRIS Toko & Merchant</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('bank')}
            className={`px-4 py-2.5 rounded-t-xl text-xs font-bold flex items-center gap-2 transition-all border-b-2 ${
              activeTab === 'bank'
                ? 'bg-white text-[#58311F] border-[#58311F] shadow-xs'
                : 'text-[#8C7A70] hover:text-[#58311F] border-transparent'
            }`}
          >
            <CreditCard className="w-4 h-4 text-[#D4A373]" />
            <span>2. Transfer Bank Dinamis ({formData.bankAccounts.length})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('profile');
              setIsAddingBank(false);
            }}
            className={`px-4 py-2.5 rounded-t-xl text-xs font-bold flex items-center gap-2 transition-all border-b-2 ${
              activeTab === 'profile'
                ? 'bg-white text-[#58311F] border-[#58311F] shadow-xs'
                : 'text-[#8C7A70] hover:text-[#58311F] border-transparent'
            }`}
          >
            <Store className="w-4 h-4 text-[#D4A373]" />
            <span>3. Identitas Kedai & Struk</span>
          </button>
        </div>

        {/* Body Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 bg-[#FDFBF7]">
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 flex items-center gap-2 text-xs animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {saveSuccess && (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-2 text-xs font-bold animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Perubahan data pembayaran kedai berhasil disimpan ke sistem kasir!</span>
            </div>
          )}

          {/* TAB 1: QRIS TOKO */}
          {activeTab === 'qris' && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              {/* Form Side (7 cols) */}
              <div className="md:col-span-7 space-y-5">
                {/* Upload Box */}
                <div className="bg-white p-4 rounded-2xl border border-[#E8DFD8] shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-[#58311F] uppercase tracking-wider flex items-center gap-1.5">
                      <Upload className="w-4 h-4 text-[#8C7A70]" />
                      <span>Upload Foto / Barcode QRIS</span>
                    </label>
                    {formData.qrisImageUrl && (
                      <button
                        type="button"
                        onClick={handleRemoveImage}
                        className="text-xs text-red-600 hover:text-red-700 font-semibold flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Hapus Foto</span>
                      </button>
                    )}
                  </div>

                  <div
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`relative cursor-pointer border-2 border-dashed rounded-2xl p-4 text-center transition-all ${
                      dragActive
                        ? 'border-[#58311F] bg-[#FAF8F5]'
                        : formData.qrisImageUrl
                        ? 'border-emerald-300 bg-emerald-50/20'
                        : 'border-[#D7CCC8] hover:border-[#D4A373] bg-[#FAF8F5]'
                    }`}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          handleFileProcess(e.target.files[0]);
                        }
                      }}
                    />

                    {formData.qrisImageUrl ? (
                      <div className="flex items-center gap-4">
                        <img
                          src={formData.qrisImageUrl}
                          alt="QRIS Toko"
                          className="w-20 h-20 object-contain rounded-xl border border-emerald-200 bg-white shadow-xs p-1"
                        />
                        <div className="text-left flex-1 space-y-1">
                          <div className="flex items-center gap-1 text-emerald-700 text-xs font-bold">
                            <Check className="w-3.5 h-3.5" />
                            <span>Foto QRIS Aktif Terpasang</span>
                          </div>
                          <p className="text-[11px] text-[#8C7A70]">
                            Klik di sini atau seret foto baru untuk memperbarui barcode QRIS pelanggan.
                          </p>
                        </div>
                      </div>
                    ) : (
                      <div className="py-4 space-y-2">
                        <div className="w-12 h-12 rounded-2xl bg-[#EFE9E2] text-[#58311F] flex items-center justify-center mx-auto shadow-xs">
                          <ImageIcon className="w-6 h-6 text-[#7A4B2A]" />
                        </div>
                        <div>
                          <span className="text-xs font-bold text-[#58311F] block">
                            Klik untuk Unggah atau Drag & Drop Foto QRIS
                          </span>
                          <span className="text-[11px] text-[#8C7A70] block mt-0.5">
                            Format JPG, PNG, WEBP (Maksimal 4MB)
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* QRIS Text Fields */}
                <div className="bg-white p-4 rounded-2xl border border-[#E8DFD8] shadow-xs space-y-3.5">
                  <h4 className="text-xs font-bold text-[#58311F] uppercase tracking-wider">
                    Informasi Teks QRIS
                  </h4>

                  <div>
                    <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                      Nama Merchant QRIS
                    </label>
                    <input
                      type="text"
                      value={formData.qrisName}
                      onChange={(e) => setFormData({ ...formData, qrisName: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] font-semibold text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                      placeholder="Contoh: TEH TARIK JODI KARTOSURO"
                    />
                    <p className="text-[10px] text-[#8C7A70] mt-0.5">
                      Nama resmi yang akan terlihat oleh pelanggan saat memindai kode QR.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                      Nomor NMID / ID Merchant
                    </label>
                    <input
                      type="text"
                      value={formData.qrisNmid}
                      onChange={(e) => setFormData({ ...formData, qrisNmid: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] font-mono text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                      placeholder="Contoh: ID1020083920192"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                      Catatan Kasir / Instruksi Scan QRIS
                    </label>
                    <textarea
                      rows={2}
                      value={formData.qrisNotes || ''}
                      onChange={(e) => setFormData({ ...formData, qrisNotes: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                      placeholder="Contoh: Mendukung BCA, Livin, BRImo, GoPay, OVO, DANA, ShopeePay"
                    />
                  </div>
                </div>
              </div>

              {/* Preview Side (5 cols) */}
              <div className="md:col-span-5 space-y-4">
                <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E8DFD8] shadow-xs space-y-3 sticky top-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#58311F] uppercase tracking-wider flex items-center gap-1.5">
                      <Eye className="w-4 h-4 text-[#8C7A70]" />
                      <span>Tampilan Kasir Pelanggan</span>
                    </span>
                    <span className="text-[10px] bg-[#FAF8F5] text-[#8C7A70] px-2 py-0.5 rounded border border-[#E8DFD8]">
                      Pratinjau
                    </span>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E8DFD8] flex flex-col items-center text-center space-y-3">
                    <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600 text-white font-bold text-[10px] tracking-wider uppercase">
                      <span>QRIS RESMI</span>
                      <span>•</span>
                      <span>{formData.qrisName || 'TEH TARIK JODI'}</span>
                    </div>

                    <div className="p-3 bg-white rounded-2xl shadow-sm border border-[#D7CCC8] flex flex-col items-center max-w-[240px] w-full">
                      {formData.qrisImageUrl ? (
                        <div className="relative group">
                          <img
                            src={formData.qrisImageUrl}
                            alt="QRIS Merchant"
                            className="w-44 h-44 object-contain rounded-lg"
                          />
                          <span className="absolute bottom-1 right-1 bg-black/60 text-white text-[9px] px-1.5 py-0.5 rounded font-mono">
                            Foto Barcode Toko
                          </span>
                        </div>
                      ) : (
                        <svg viewBox="0 0 160 160" className="w-44 h-44 text-[#2D1B14]">
                          <rect x="0" y="0" width="160" height="160" fill="#ffffff" rx="12" />
                          <rect x="14" y="14" width="36" height="36" rx="4" fill="#2D1B14" />
                          <rect x="20" y="20" width="24" height="24" rx="2" fill="#ffffff" />
                          <rect x="26" y="26" width="12" height="12" rx="1" fill="#2D1B14" />
                          <rect x="110" y="14" width="36" height="36" rx="4" fill="#2D1B14" />
                          <rect x="116" y="20" width="24" height="24" rx="2" fill="#ffffff" />
                          <rect x="122" y="26" width="12" height="12" rx="1" fill="#2D1B14" />
                          <rect x="14" y="110" width="36" height="36" rx="4" fill="#2D1B14" />
                          <rect x="20" y="116" width="24" height="24" rx="2" fill="#ffffff" />
                          <rect x="26" y="122" width="12" height="12" rx="1" fill="#2D1B14" />
                          <rect x="58" y="58" width="44" height="44" rx="8" fill="#58311F" />
                          <circle cx="80" cy="80" r="14" fill="#D4A373" />
                          <text x="80" y="85" textAnchor="middle" fill="#2D1B14" fontSize="12" fontWeight="bold">TTJ</text>
                          <rect x="58" y="14" width="10" height="10" fill="#2D1B14" />
                          <rect x="76" y="14" width="8" height="8" fill="#2D1B14" />
                          <rect x="92" y="14" width="10" height="10" fill="#2D1B14" />
                          <rect x="110" y="58" width="12" height="12" fill="#2D1B14" />
                          <rect x="130" y="58" width="16" height="12" fill="#2D1B14" />
                          <rect x="58" y="110" width="20" height="14" fill="#2D1B14" />
                          <rect x="86" y="110" width="14" height="20" fill="#2D1B14" />
                          <rect x="110" y="110" width="18" height="14" fill="#2D1B14" />
                        </svg>
                      )}

                      <p className="font-bold text-xs text-[#2D1B14] mt-2 uppercase">
                        {formData.qrisName || 'TEH TARIK JODI KARTOSURO'}
                      </p>
                      <p className="text-[10px] text-[#8C7A70] font-mono">
                        NMID: {formData.qrisNmid || 'ID1020083920192'}
                      </p>
                    </div>

                    <p className="text-[11px] text-[#6B4F3E] leading-relaxed">
                      {formData.qrisNotes || 'Mendukung semua dompet digital dan mobile banking.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TRANSFER BANK DINAMIS */}
          {activeTab === 'bank' && (
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-[#E8DFD8] shadow-xs">
                <div>
                  <h4 className="font-bold text-sm text-[#2D1B14] flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-[#58311F]" />
                    <span>Daftar Akun Transfer Bank Kedai</span>
                  </h4>
                  <p className="text-xs text-[#8C7A70] mt-0.5">
                    Data rekening ini akan tampil otomatis saat kasir/pelanggan memilih metode "Transfer Bank".
                  </p>
                </div>

                {!isAddingBank && (
                  <button
                    type="button"
                    onClick={handleStartAddBank}
                    className="px-3.5 py-2 rounded-xl bg-[#58311F] hover:bg-[#432314] text-white text-xs font-bold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
                  >
                    <Plus className="w-4 h-4 text-[#D4A373]" />
                    <span>Tambah Rekening Bank</span>
                  </button>
                )}
              </div>

              {/* Add / Edit Bank Inline Subform */}
              {isAddingBank && (
                <div className="bg-amber-50/40 p-4 sm:p-5 rounded-2xl border border-amber-200/80 shadow-xs space-y-4 animate-in slide-in-from-top-2 duration-150">
                  <div className="flex items-center justify-between border-b border-amber-200 pb-2">
                    <h5 className="font-bold text-xs text-[#58311F] uppercase tracking-wider flex items-center gap-1.5">
                      <Building2 className="w-4 h-4 text-[#8C7A70]" />
                      <span>{editingBankIndex !== null ? 'Edit Rekening Bank' : 'Tambah Rekening Bank Baru'}</span>
                    </h5>
                    <button
                      type="button"
                      onClick={() => setIsAddingBank(false)}
                      className="text-xs text-[#8C7A70] hover:text-[#2D1B14]"
                    >
                      Batal
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {/* Bank Name */}
                    <div>
                      <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                        Nama Bank
                      </label>
                      <input
                        type="text"
                        value={bankForm.bankName}
                        onChange={(e) => setBankForm({ ...bankForm, bankName: e.target.value.toUpperCase() })}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-white font-bold text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                        placeholder="BCA / MANDIRI / BRI dll."
                      />
                      {/* Common Bank Pills */}
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {COMMON_BANKS.map((b) => (
                          <button
                            key={b}
                            type="button"
                            onClick={() => setBankForm({ ...bankForm, bankName: b })}
                            className={`px-1.5 py-0.5 rounded text-[10px] font-semibold border transition-colors ${
                              bankForm.bankName === b
                                ? 'bg-[#58311F] text-white border-[#58311F]'
                                : 'bg-white text-[#58311F] border-[#D7CCC8] hover:bg-[#FAF8F5]'
                            }`}
                          >
                            {b}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Account Number */}
                    <div>
                      <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                        Nomor Rekening
                      </label>
                      <input
                        type="text"
                        value={bankForm.accountNumber}
                        onChange={(e) => setBankForm({ ...bankForm, accountNumber: e.target.value })}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-white font-mono font-bold text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                        placeholder="Contoh: 0158-9283-11"
                      />
                      <p className="text-[10px] text-[#8C7A70] mt-1">
                        Nomor rekening yang dapat disalin kasir / pembeli.
                      </p>
                    </div>

                    {/* Holder Name */}
                    <div>
                      <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                        Nama Pemilik (Atas Nama)
                      </label>
                      <input
                        type="text"
                        value={bankForm.holderName}
                        onChange={(e) => setBankForm({ ...bankForm, holderName: e.target.value.toUpperCase() })}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-white font-semibold text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                        placeholder="Contoh: RAYVANDO"
                      />
                      <p className="text-[10px] text-[#8C7A70] mt-1">
                        Nama pemilik rekening di buku tabungan.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsAddingBank(false)}
                      className="px-3.5 py-1.5 rounded-xl border border-[#D7CCC8] text-xs font-semibold text-[#58311F] hover:bg-white"
                    >
                      Batal
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveBankForm}
                      className="px-4 py-1.5 rounded-xl bg-[#58311F] text-white text-xs font-bold hover:bg-[#432314] shadow-2xs flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5 text-[#D4A373]" />
                      <span>{editingBankIndex !== null ? 'Perbarui Rekening' : 'Tambahkan ke Daftar'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Bank Accounts List Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {formData.bankAccounts.map((acc, index) => (
                  <div
                    key={`${acc.bankName}-${index}`}
                    className="bg-white p-4 rounded-2xl border border-[#E8DFD8] shadow-xs flex items-start justify-between gap-3 hover:border-[#D4A373] transition-colors"
                  >
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-md bg-[#58311F] text-white font-bold text-xs">
                          {acc.bankName}
                        </span>
                        <span className="text-[11px] text-[#8C7A70]">Rekening #{index + 1}</span>
                      </div>

                      <div className="font-mono font-extrabold text-base text-[#2D1B14]">
                        {acc.accountNumber}
                      </div>

                      <div className="text-xs text-[#6B4F3E] flex items-center gap-1">
                        <User className="w-3.5 h-3.5 text-[#8C7A70]" />
                        <span>a.n <strong>{acc.holderName}</strong></span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleStartEditBank(index)}
                        className="p-1.5 rounded-lg text-[#58311F] hover:bg-[#FAF8F5] border border-[#E8DFD8]"
                        title="Edit data rekening"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteBank(index)}
                        className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 border border-red-200"
                        title="Hapus rekening"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  Perubahan nomor rekening dan nama bank akan langsung terlihat di kalkulator kasir saat pelanggan memilih metode Transfer Bank.
                </span>
              </div>
            </div>
          )}

          {/* TAB 3: PROFIL KEDAI & STRUK */}
          {activeTab === 'profile' && (
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E8DFD8] shadow-xs space-y-4 max-w-2xl">
              <h4 className="text-xs font-bold text-[#58311F] uppercase tracking-wider flex items-center gap-1.5">
                <Store className="w-4 h-4 text-[#8C7A70]" />
                <span>Identitas Kedai & Nota Pembayaran</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                    Nama Kedai
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-[#2D1B14] font-bold focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                    Slogan / Tagline
                  </label>
                  <input
                    type="text"
                    value={formData.tagline}
                    onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                    Nama Owner (Pemilik)
                  </label>
                  <input
                    type="text"
                    value={formData.ownerName}
                    onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-[#2D1B14] font-semibold focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                    Nama Kasir Default
                  </label>
                  <input
                    type="text"
                    value={formData.cashierName}
                    onChange={(e) => setFormData({ ...formData, cashierName: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                    Alamat Lengkap Kedai
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                    Kota / Wilayah
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#2D1B14] mb-1">
                    No. WhatsApp / Telepon Kedai
                  </label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] text-[#2D1B14] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Footer */}
        <div className="p-4 bg-white border-t border-[#E8DFD8] flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleResetToDefault}
            className="px-3.5 py-2 rounded-xl border border-[#D7CCC8] hover:bg-[#FAF8F5] text-xs font-semibold text-[#8C7A70] flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Standar Kedai</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-[#D7CCC8] text-xs font-semibold text-[#58311F] hover:bg-[#FAF8F5]"
            >
              Tutup
            </button>
            <button
              type="button"
              onClick={handleSaveAll}
              className="px-5 py-2.5 rounded-xl bg-[#58311F] hover:bg-[#432314] text-white text-xs font-bold flex items-center gap-2 shadow-sm active:scale-95 transition-all"
            >
              <Check className="w-4 h-4 text-[#D4A373]" />
              <span>Simpan Pengaturan Pembayaran</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Also export alias QRISSettingsModal for backwards compatibility
export const QRISSettingsModal = PaymentSettingsModal;
