import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Upload,
  Link as LinkIcon,
  Image as ImageIcon,
  Save,
  Trash2,
  AlertCircle,
  CheckCircle2,
  RotateCcw,
  Sparkles,
  Camera,
} from 'lucide-react';
import { Product } from '../types';
import { usePOS } from '../context/POSContext';
import { formatRupiah } from '../utils/formatters';
import { PRESET_DRINK_IMAGES } from '../data/initialData';

interface EditProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
}

export const EditProductModal: React.FC<EditProductModalProps> = ({
  isOpen,
  onClose,
  product,
}) => {
  const { updateProduct, categories } = usePOS();

  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [stock, setStock] = useState('50');
  const [minStockAlert, setMinStockAlert] = useState('10');
  const [image, setImage] = useState('');
  const [imageTab, setImageTab] = useState<'upload' | 'url' | 'presets'>('upload');
  const [urlInput, setUrlInput] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isProcessingImage, setIsProcessingImage] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync state when product changes or modal opens
  useEffect(() => {
    if (product) {
      setName(product.name || '');
      setPrice(product.price ? product.price.toString() : '');
      setDescription(product.description || '');
      setCategory(product.category || 'Teh Spesial');
      setStock(typeof product.stock === 'number' ? product.stock.toString() : '50');
      setMinStockAlert(
        typeof product.minStockAlert === 'number' ? product.minStockAlert.toString() : '10'
      );
      setImage(product.image || '');
      setUrlInput(product.image?.startsWith('http') ? product.image : '');
      setErrorMessage('');
      setSuccessMessage('');
    }
  }, [product, isOpen]);

  if (!isOpen || !product) return null;

  // Compress image to ~800px max dimension and 0.85 JPEG quality for fast local storage
  const processAndSetImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMessage('Harap unggah file foto gambar (JPG, PNG, WEBP).');
      return;
    }

    setIsProcessingImage(true);
    setErrorMessage('');

    const reader = new FileReader();
    reader.onload = (e) => {
      const rawDataUrl = e.target?.result as string;
      if (!rawDataUrl) {
        setIsProcessingImage(false);
        return;
      }

      const img = new Image();
      img.onload = () => {
        try {
          const maxDimension = 900;
          let width = img.width;
          let height = img.height;

          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = Math.round((height * maxDimension) / width);
              width = maxDimension;
            } else {
              width = Math.round((width * maxDimension) / height);
              height = maxDimension;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.86);
            setImage(compressedDataUrl);
            setSuccessMessage('Foto produk berhasil dimuat!');
          } else {
            setImage(rawDataUrl);
          }
        } catch {
          setImage(rawDataUrl);
        } finally {
          setIsProcessingImage(false);
        }
      };
      img.onerror = () => {
        setErrorMessage('Gagal memproses file gambar.');
        setIsProcessingImage(false);
      };
      img.src = rawDataUrl;
    };

    reader.onerror = () => {
      setErrorMessage('Terjadi kesalahan membaca file gambar.');
      setIsProcessingImage(false);
    };

    reader.readAsDataURL(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processAndSetImageFile(file);
    }
  };

  const handleApplyUrl = () => {
    if (!urlInput.trim()) {
      setErrorMessage('Masukkan link URL gambar yang valid.');
      return;
    }
    setImage(urlInput.trim());
    setSuccessMessage('URL gambar berhasil diterapkan!');
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!name.trim()) {
      setErrorMessage('Nama menu wajib diisi.');
      return;
    }

    const parsedPrice = parseInt(price, 10);
    if (isNaN(parsedPrice) || parsedPrice <= 0) {
      setErrorMessage('Harga menu harus berupa angka lebih besar dari 0.');
      return;
    }

    const parsedStock = parseInt(stock, 10);
    if (isNaN(parsedStock) || parsedStock < 0) {
      setErrorMessage('Jumlah stok cup tidak boleh negatif.');
      return;
    }

    const parsedMinStock = parseInt(minStockAlert, 10);

    // Commit changes immediately to POSContext
    updateProduct(product.id, {
      name: name.trim(),
      price: parsedPrice,
      description: description.trim(),
      category: category || product.category,
      stock: parsedStock,
      minStockAlert: isNaN(parsedMinStock) ? 10 : parsedMinStock,
      image: image.trim(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="bg-[#FAF7F2] rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl border border-[#D7CCC8] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Modal */}
        <div className="px-5 py-4 bg-[#58311F] text-white flex items-center justify-between border-b border-[#432314]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#D4A373]/20 flex items-center justify-center border border-[#D4A373]/40">
              <Camera className="w-5 h-5 text-[#D4A373]" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight">
                Edit Menu &amp; Upload Foto
              </h2>
              <p className="text-xs text-[#E8DFD8]">
                Ubah gambar, harga, slogan, atau stok untuk{' '}
                <span className="text-[#D4A373] font-bold">{product.name}</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#E8DFD8] hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-5 space-y-5 text-[#2D1B14]">
          {/* Notification feedback */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center justify-between">
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                {successMessage}
              </span>
              <button
                type="button"
                onClick={() => setSuccessMessage('')}
                className="text-emerald-700 hover:text-emerald-900 text-xs font-bold"
              >
                Tutup
              </button>
            </div>
          )}

          {/* Section 1: Image Upload & Live Preview */}
          <div className="bg-white rounded-xl p-4 border border-[#E8DFD8] space-y-3.5 shadow-xs">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-[#58311F] uppercase tracking-wider flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-[#8B4513]" />
                Foto Produk Menu
              </label>
              {image && (
                <button
                  type="button"
                  onClick={() => {
                    setImage('');
                    setUrlInput('');
                    setSuccessMessage('');
                  }}
                  className="text-xs text-red-600 hover:text-red-800 font-semibold flex items-center gap-1 hover:underline"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Hapus Foto
                </button>
              )}
            </div>

            {/* Live Preview & Uploader Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-start">
              {/* Image Preview Box */}
              <div className="sm:col-span-5 flex flex-col items-center">
                <div className="w-full h-44 rounded-xl overflow-hidden bg-[#F2ECE4] border-2 border-dashed border-[#D7CCC8] relative flex items-center justify-center group shadow-inner">
                  {image ? (
                    <img
                      src={image}
                      alt={name || 'Preview Produk'}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="text-center p-3 text-[#A89F91]">
                      <ImageIcon className="w-10 h-10 mx-auto mb-1 opacity-50" />
                      <p className="text-xs font-medium">Belum ada foto</p>
                      <p className="text-[10px]">Pilih upload atau input link</p>
                    </div>
                  )}

                  {/* Badge Status */}
                  <span className="absolute bottom-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#2D1B14]/80 text-white backdrop-blur-xs">
                    Pratinjau Kartu Kasir
                  </span>
                </div>
              </div>

              {/* Upload Controls & Methods */}
              <div className="sm:col-span-7 space-y-3">
                {/* Mode Selector Tabs */}
                <div className="flex rounded-lg bg-[#F2ECE4] p-1 border border-[#E8DFD8]">
                  <button
                    type="button"
                    onClick={() => setImageTab('upload')}
                    className={`flex-1 py-1.5 px-2 rounded-md text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      imageTab === 'upload'
                        ? 'bg-[#58311F] text-white shadow-xs'
                        : 'text-[#6B4F3E] hover:text-[#2D1B14]'
                    }`}
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Upload File
                  </button>
                  <button
                    type="button"
                    onClick={() => setImageTab('url')}
                    className={`flex-1 py-1.5 px-2 rounded-md text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      imageTab === 'url'
                        ? 'bg-[#58311F] text-white shadow-xs'
                        : 'text-[#6B4F3E] hover:text-[#2D1B14]'
                    }`}
                  >
                    <LinkIcon className="w-3.5 h-3.5" />
                    Link URL
                  </button>
                  <button
                    type="button"
                    onClick={() => setImageTab('presets')}
                    className={`flex-1 py-1.5 px-2 rounded-md text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      imageTab === 'presets'
                        ? 'bg-[#58311F] text-white shadow-xs'
                        : 'text-[#6B4F3E] hover:text-[#2D1B14]'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Koleksi Kedai
                  </button>
                </div>

                {/* Tab 1: Upload File dari HP / Laptop */}
                {imageTab === 'upload' && (
                  <div className="space-y-2">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileInputChange}
                      className="hidden"
                    />

                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-[#D4A373] hover:border-[#8B4513] bg-[#FAF6F0] hover:bg-[#F5ECE0] rounded-xl p-4 text-center cursor-pointer transition-colors space-y-1.5"
                    >
                      <Upload className="w-6 h-6 text-[#8B4513] mx-auto" />
                      <div className="text-xs font-bold text-[#58311F]">
                        {isProcessingImage ? 'Memproses Foto...' : 'Klik untuk Pilih Foto dari HP / Laptop'}
                      </div>
                      <p className="text-[10px] text-[#8C7A70]">
                        Mendukung JPG, PNG, WEBP (otomatis dioptimalkan)
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full py-2 px-3 rounded-lg border border-[#D7CCC8] bg-white text-xs font-semibold text-[#58311F] hover:bg-[#F2ECE4] transition-colors"
                    >
                      Pilih dari File Explorer / Galeri
                    </button>
                  </div>
                )}

                {/* Tab 2: Masukkan Link URL Gambar */}
                {imageTab === 'url' && (
                  <div className="space-y-2">
                    <label className="text-[11px] font-semibold text-[#6B574B]">
                      Tempel URL Gambar Eksternal
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="url"
                        placeholder="https://images.unsplash.com/... atau link foto"
                        value={urlInput}
                        onChange={(e) => setUrlInput(e.target.value)}
                        className="flex-1 px-3 py-2 text-xs rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] focus:ring-2 focus:ring-[#D4A373] focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={handleApplyUrl}
                        className="px-3 py-2 bg-[#8B4513] hover:bg-[#6B340E] text-white rounded-lg text-xs font-bold transition-colors whitespace-nowrap"
                      >
                        Terapkan
                      </button>
                    </div>
                    <p className="text-[10px] text-[#8C7A70]">
                      Gunakan direct link gambar (misal dari Google Drive public, Cloudinary, atau Unsplash).
                    </p>
                  </div>
                )}

                {/* Tab 3: Pilihan Preset Foto Kopitiam */}
                {imageTab === 'presets' && (
                  <div className="space-y-2">
                    <p className="text-[11px] font-semibold text-[#6B574B]">
                      Pilih Foto Kopitiam Siap Pakai:
                    </p>
                    <div className="grid grid-cols-4 gap-2 max-h-36 overflow-y-auto p-1 scrollbar-thin">
                      {PRESET_DRINK_IMAGES.map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setImage(preset.url);
                            setUrlInput(preset.url);
                            setSuccessMessage(`Foto "${preset.label}" dipilih`);
                          }}
                          className={`group relative rounded-lg overflow-hidden border-2 aspect-square transition-all ${
                            image === preset.url
                              ? 'border-[#58311F] ring-2 ring-[#D4A373]'
                              : 'border-transparent hover:border-[#D4A373]'
                          }`}
                          title={preset.label}
                        >
                          <img
                            src={preset.url}
                            alt={preset.label}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-200"
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Section 2: Info Produk (Nama, Slogan, Kategori) */}
          <div className="bg-white rounded-xl p-4 border border-[#E8DFD8] space-y-3.5 shadow-xs">
            <label className="text-xs font-bold text-[#58311F] uppercase tracking-wider block">
              Informasi Menu
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Nama Produk */}
              <div>
                <label className="text-xs font-bold text-[#432314] block mb-1">
                  Nama Menu <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Teh Tarik"
                  className="w-full px-3 py-2 rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] text-xs font-semibold focus:ring-2 focus:ring-[#D4A373] focus:outline-none"
                />
              </div>

              {/* Kategori */}
              <div>
                <label className="text-xs font-bold text-[#432314] block mb-1">Kategori</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] text-xs font-semibold focus:ring-2 focus:ring-[#D4A373] focus:outline-none"
                >
                  {categories
                    .filter((c) => c !== 'Semua')
                    .map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                </select>
              </div>
            </div>

            {/* Slogan / Deskripsi */}
            <div>
              <label className="text-xs font-bold text-[#432314] block mb-1">
                Slogan / Deskripsi Rasa Minuman
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Contoh: Racikan teh murni Nusantara dipadukan dengan susu dan krimer"
                className="w-full px-3 py-2 rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] text-xs focus:ring-2 focus:ring-[#D4A373] focus:outline-none"
              />
              <p className="text-[10px] text-[#8C7A70] mt-0.5">
                Slogan ini akan ditampilkan langsung di bawah nama menu pada kartu kasir.
              </p>
            </div>
          </div>

          {/* Section 3: Harga & Stok Cup */}
          <div className="bg-white rounded-xl p-4 border border-[#E8DFD8] space-y-3.5 shadow-xs">
            <label className="text-xs font-bold text-[#58311F] uppercase tracking-wider block">
              Harga &amp; Ketersediaan Cup
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Harga Jual */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#432314] block">
                  Harga Jual (Rp) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-[#8C7A70]">
                    Rp
                  </span>
                  <input
                    type="number"
                    min="0"
                    step="500"
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] text-sm font-bold font-mono text-[#58311F] focus:ring-2 focus:ring-[#D4A373] focus:outline-none"
                  />
                </div>
                {/* Quick Price Buttons */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {[6000, 10000, 12000, 15000].map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setPrice(p.toString())}
                      className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#F2ECE4] hover:bg-[#E8DFD8] text-[#58311F] transition-colors"
                    >
                      {formatRupiah(p)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Stok Cup */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#432314] block">
                  Jumlah Stok Cup Tersedia <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={stock}
                  onChange={(e) => setStock(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] text-sm font-bold font-mono text-[#2D1B14] focus:ring-2 focus:ring-[#D4A373] focus:outline-none"
                />
                {/* Quick Restock Adjusters */}
                <div className="flex items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-[#8C7A70] font-semibold">Tambah:</span>
                  {[10, 20, 50].map((inc) => (
                    <button
                      key={inc}
                      type="button"
                      onClick={() => {
                        const cur = parseInt(stock, 10) || 0;
                        setStock((cur + inc).toString());
                      }}
                      className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#EFE9E2] hover:bg-[#D4A373]/30 text-[#6B4F3E] transition-colors"
                    >
                      +{inc}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setStock('50')}
                    className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#58311F]/10 hover:bg-[#58311F]/20 text-[#58311F] transition-colors"
                  >
                    Set 50
                  </button>
                </div>
              </div>
            </div>
          </div>
        </form>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-white border-t border-[#E8DFD8] flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-[#D7CCC8] text-xs font-bold text-[#6B574B] hover:bg-[#F2ECE4] transition-colors"
          >
            Batal
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 rounded-xl bg-[#58311F] hover:bg-[#432314] text-white text-xs font-bold flex items-center gap-2 shadow-md transition-all active:scale-95"
          >
            <Save className="w-4 h-4 text-[#D4A373]" />
            Simpan Perubahan
          </button>
        </div>
      </div>
    </div>
  );
};
