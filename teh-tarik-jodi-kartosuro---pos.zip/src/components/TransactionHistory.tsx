import React, { useState, useMemo } from 'react';
import {
  ReceiptText,
  Download,
  Search,
  Filter,
  Eye,
  Printer,
  Trash2,
  Calendar,
  CreditCard,
  Banknote,
  QrCode,
  FileSpreadsheet,
  AlertCircle,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { Transaction } from '../types';
import {
  formatRupiah,
  formatDateTimeIndo,
  exportTransactionsToCSV,
} from '../utils/formatters';

interface TransactionHistoryProps {
  onViewReceipt: (tx: Transaction) => void;
}

export const TransactionHistory: React.FC<TransactionHistoryProps> = ({
  onViewReceipt,
}) => {
  const { transactions, clearAllTransactions, shopInfo } = usePOS();

  const [search, setSearch] = useState('');
  const [methodFilter, setMethodFilter] = useState('ALL');
  const [dateFilter, setDateFilter] = useState<'ALL' | 'TODAY' | '7DAYS'>('ALL');
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);

  // Filter transactions
  const filtered = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const sevenDaysAgo = todayStart - 7 * 24 * 60 * 60 * 1000;

    return transactions.filter((t) => {
      // Date filter
      const txTime = new Date(t.timestamp).getTime();
      if (dateFilter === 'TODAY' && txTime < todayStart) return false;
      if (dateFilter === '7DAYS' && txTime < sevenDaysAgo) return false;

      // Method filter
      if (methodFilter !== 'ALL' && t.paymentMethod !== methodFilter) return false;

      // Search
      if (search.trim()) {
        const q = search.toLowerCase();
        const matchReceipt = t.receiptNumber.toLowerCase().includes(q);
        const matchCustomer = t.customerName && t.customerName.toLowerCase().includes(q);
        const matchItem = t.items.some(i => i.name.toLowerCase().includes(q));
        if (!matchReceipt && !matchCustomer && !matchItem) return false;
      }

      return true;
    });
  }, [transactions, dateFilter, methodFilter, search]);

  const totalFilteredRevenue = filtered.reduce((sum, t) => sum + t.grandTotal, 0);

  const handleExport = () => {
    exportTransactionsToCSV(
      filtered.length > 0 ? filtered : transactions,
      `Laporan_Transaksi_${shopInfo.name.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`
    );
  };

  return (
    <div className="flex-1 p-4 sm:p-6 bg-[#FDFBF7] overflow-y-auto space-y-5">
      {/* Top Banner & Export Action */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-[#E8DFD8] shadow-xs">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-[#2D1B14] flex items-center gap-2">
            <ReceiptText className="w-5 h-5 text-[#58311F]" />
            <span>Riwayat Transaksi & Pembukuan Kasir</span>
          </h2>
          <p className="text-xs text-[#8C7A70] mt-0.5">
            Log riwayat seluruh struk belanja kedai {shopInfo.name}. Awalnya bersih tanpa data dummy, siap untuk transaksi nyata.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExport}
            disabled={transactions.length === 0}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-sm ${
              transactions.length === 0
                ? 'bg-neutral-200 text-neutral-400 cursor-not-allowed'
                : 'bg-emerald-700 hover:bg-emerald-800 text-white active:scale-95'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
            <span>Ekspor ke Excel / CSV</span>
          </button>

          {transactions.length > 0 && (
            <button
              type="button"
              onClick={() => setConfirmClearOpen(true)}
              className="p-2 rounded-xl border border-red-200 text-red-600 hover:bg-red-50 text-xs transition-colors"
              title="Bersihkan seluruh riwayat transaksi"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-[#E8DFD8]">
        {/* Search */}
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-[#8C7A70] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari no. struk, nama menu, nama pelanggan..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
          />
        </div>

        {/* Date Filter */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setDateFilter('ALL')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold ${
              dateFilter === 'ALL'
                ? 'bg-[#58311F] text-white'
                : 'bg-[#FAF8F5] text-[#6B4F3E] hover:bg-[#EFE9E2]'
            }`}
          >
            Semua
          </button>
          <button
            onClick={() => setDateFilter('TODAY')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold ${
              dateFilter === 'TODAY'
                ? 'bg-[#58311F] text-white'
                : 'bg-[#FAF8F5] text-[#6B4F3E] hover:bg-[#EFE9E2]'
            }`}
          >
            Hari Ini
          </button>
          <button
            onClick={() => setDateFilter('7DAYS')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold ${
              dateFilter === '7DAYS'
                ? 'bg-[#58311F] text-white'
                : 'bg-[#FAF8F5] text-[#6B4F3E] hover:bg-[#EFE9E2]'
            }`}
          >
            7 Hari
          </button>
        </div>

        {/* Payment Method Filter */}
        <select
          value={methodFilter}
          onChange={(e) => setMethodFilter(e.target.value)}
          className="py-1.5 px-2.5 rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] text-xs text-[#58311F] font-semibold focus:outline-none"
        >
          <option value="ALL">Semua Pembayaran</option>
          <option value="CASH">Tunai (Cash)</option>
          <option value="QRIS">QRIS</option>
          <option value="BANK_TRANSFER">Transfer Bank</option>
        </select>
      </div>

      {/* Summary of Filtered Items */}
      <div className="flex items-center justify-between text-xs px-1 text-[#8C7A70]">
        <span>Menampilkan {filtered.length} dari total {transactions.length} transaksi</span>
        <span>
          Total Nilai: <strong className="text-[#58311F]">{formatRupiah(totalFilteredRevenue)}</strong>
        </span>
      </div>

      {/* Transactions Table / List */}
      <div className="bg-white rounded-2xl border border-[#E8DFD8] shadow-xs overflow-hidden">
        {filtered.length === 0 ? (
          <div className="text-center py-16 px-4 space-y-3">
            <div className="w-16 h-16 rounded-2xl bg-[#F4EBE1] text-[#7A4B2A] flex items-center justify-center mx-auto">
              <ReceiptText className="w-8 h-8 text-[#A89F91]" />
            </div>
            <h3 className="font-bold text-base text-[#58311F]">
              {transactions.length === 0 ? 'Belum Ada Transaksi' : 'Tidak Ada Transaksi Sesuai Filter'}
            </h3>
            <p className="text-xs text-[#8C7A70] max-w-sm mx-auto">
              {transactions.length === 0
                ? 'Sistem kasir siap dipakai! Silakan pilih menu di Terminal Kasir dan selesaikan pembayaran untuk merekam transaksi operasional pertama.'
                : 'Coba ubah kata kunci pencarian atau sesuaikan filter tanggal & pembayaran.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAF8F5] text-[#58311F] border-b border-[#E8DFD8] uppercase tracking-wider font-bold">
                <tr>
                  <th className="py-3 px-4">No. Struk</th>
                  <th className="py-3 px-4">Waktu</th>
                  <th className="py-3 px-4">Tipe & Pelanggan</th>
                  <th className="py-3 px-4">Rincian Menu</th>
                  <th className="py-3 px-4">Metode Bayar</th>
                  <th className="py-3 px-4 text-right">Total Bayar</th>
                  <th className="py-3 px-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F2ECE4]">
                {filtered.map((tx) => (
                  <tr key={tx.id} className="hover:bg-[#FAF8F5]/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-[#58311F]">
                      {tx.receiptNumber}
                    </td>

                    <td className="py-3 px-4 text-[#8C7A70]">
                      {formatDateTimeIndo(tx.timestamp)}
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-semibold text-[#2D1B14]">
                        {tx.orderType === 'DINE_IN' ? 'Dine In' : 'Take Away'}
                        {tx.tableNumber && ` (Meja ${tx.tableNumber})`}
                      </div>
                      <div className="text-[11px] text-[#8C7A70]">
                        {tx.customerName || 'Pelanggan Umum'}
                      </div>
                    </td>

                    <td className="py-3 px-4 max-w-xs">
                      <div className="line-clamp-2 text-[#2D1B14]">
                        {tx.items.map((i) => `${i.name} (${i.quantity}x)`).join(', ')}
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-[#F4EBE1] text-[#7A4B2A]">
                        {tx.paymentMethod === 'CASH' && <Banknote className="w-3 h-3" />}
                        {tx.paymentMethod === 'QRIS' && <QrCode className="w-3 h-3" />}
                        {tx.paymentMethod === 'BANK_TRANSFER' && <CreditCard className="w-3 h-3" />}
                        <span>{tx.paymentMethod}</span>
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right font-extrabold text-sm text-[#58311F]">
                      {formatRupiah(tx.grandTotal)}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <button
                        type="button"
                        onClick={() => onViewReceipt(tx)}
                        className="px-2.5 py-1.5 rounded-lg border border-[#D7CCC8] hover:bg-[#F4EBE1] text-[#58311F] font-semibold text-xs flex items-center gap-1 mx-auto transition-colors"
                        title="Lihat & Cetak Ulang Struk"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Struk</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Confirmation Modal to Clear All Transactions */}
      {confirmClearOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-red-200 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-base text-[#2D1B14]">
                Hapus Seluruh Riwayat Transaksi?
              </h4>
              <p className="text-xs text-[#8C7A70] mt-1">
                Tindakan ini akan mengosongkan seluruh log transaksi penjualan dan mereset laporan ke Rp 0. Data yang dihapus tidak dapat dipulihkan.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmClearOpen(false)}
                className="flex-1 py-2 text-xs font-semibold rounded-xl border border-[#D7CCC8] text-[#58311F]"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  clearAllTransactions();
                  setConfirmClearOpen(false);
                }}
                className="flex-1 py-2 text-xs font-bold rounded-xl bg-red-600 hover:bg-red-700 text-white shadow-xs"
              >
                Ya, Bersihkan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
