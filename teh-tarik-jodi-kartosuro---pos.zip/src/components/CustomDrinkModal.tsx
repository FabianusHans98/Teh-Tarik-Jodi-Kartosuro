import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Minus,
  Sparkles,
  ShoppingBag,
  Coffee,
  Check,
} from 'lucide-react';
import { Product, IceLevel, SugarLevel } from '../types';
import { usePOS } from '../context/POSContext';
import { formatRupiah } from '../utils/formatters';

interface CustomDrinkModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
}

export const CustomDrinkModal: React.FC<CustomDrinkModalProps> = ({
  isOpen,
  onClose,
  product,
}) => {
  const { addToCart, cart } = usePOS();

  const [iceLevel, setIceLevel] = useState<IceLevel>('Normal Ice');
  const [sugarLevel, setSugarLevel] = useState<SugarLevel>('Normal Sugar');
  const [notes, setNotes] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);

  useEffect(() => {
    if (product) {
      setIceLevel('Normal Ice');
      setSugarLevel('Normal Sugar');
      setNotes('');
      setQuantity(1);
    }
  }, [product, isOpen]);

  if (!isOpen || !product) return null;

  const inCartQty = cart
    .filter((item) => item.productId === product.id)
    .reduce((sum, item) => sum + item.quantity, 0);
  const remainingStock = Math.max(0, product.stock - inCartQty);

  const ICE_OPTIONS: { value: IceLevel; label: string; desc: string; icon: string }[] = [
    { value: 'Normal Ice', label: 'Normal Ice', desc: 'Es Segar Pas', icon: '🧊' },
    { value: 'Less Ice', label: 'Less Ice', desc: 'Es Sedikit', icon: '🧊' },
    { value: 'No Ice', label: 'No Ice', desc: 'Dingin Tanpa Es', icon: '🚫' },
    { value: 'Hangat (Panas)', label: 'Hangat', desc: 'Sajian Panas Kedai', icon: '☕' },
  ];

  const SUGAR_OPTIONS: { value: SugarLevel; label: string; desc: string; icon: string }[] = [
    { value: 'Normal Sugar', label: 'Normal Sugar', desc: 'Manis Standar', icon: '🍯' },
    { value: 'Less Sugar', label: 'Less Sugar', desc: 'Sedikit Manis (50%)', icon: '📉' },
    { value: 'No Sugar', label: 'No Sugar', desc: 'Tawar (0% Gula)', icon: '🚫' },
    { value: 'Extra Sweet', label: 'Extra Sweet', desc: 'Lebih Manis', icon: '✨' },
  ];

  const QUICK_NOTES = [
    'Tarik Busa Tebal',
    'Gelas Plastik',
    'Pisah Es',
    'Kental Manis Tambah',
    'Bungkus Rapi',
  ];

  const handleConfirm = () => {
    if (remainingStock <= 0) return;
    const addCount = Math.min(quantity, remainingStock);
    for (let i = 0; i < addCount; i++) {
      addToCart(product, {
        iceLevel,
        sugarLevel,
        notes: notes.trim(),
      });
    }
    onClose();
  };

  const handleQuickAddDefault = () => {
    if (remainingStock <= 0) return;
    addToCart(product, {
      iceLevel: 'Normal Ice',
      sugarLevel: 'Normal Sugar',
      notes: '',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="bg-[#FAF7F2] rounded-3xl w-full max-w-lg shadow-2xl border border-[#D7CCC8] overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Modal */}
        <div className="px-5 py-3.5 bg-[#58311F] text-white flex items-center justify-between border-b border-[#432314]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#D4A373]/20 flex items-center justify-center border border-[#D4A373]/30">
              <Sparkles className="w-4 h-4 text-[#D4A373]" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Kustomisasi Pesanan (Kilat)
              </h2>
              <p className="text-[11px] text-[#E8DFD8]">
                Atur tingkat es &amp; gula khas racikan Kopitiam
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#E8DFD8] hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Product Info Card */}
          <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-white border border-[#E8DFD8] shadow-xs">
            <div className="w-16 h-16 rounded-xl overflow-hidden bg-[#F4EBE1] shrink-0 border border-[#D7CCC8]">
              {product.image ? (
                <img
                  src={product.image}
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-[#8B4513]">
                  <Coffee className="w-8 h-8" />
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#FAF0E6] text-[#8B4513] border border-[#E8DFD8]">
                {product.category}
              </span>
              <h3 className="font-bold text-sm sm:text-base text-[#2D1B14] truncate mt-0.5">
                {product.name}
              </h3>
              {product.description && (
                <p className="text-xs text-[#8C7A70] line-clamp-1 italic">
                  "{product.description}"
                </p>
              )}
              <div className="flex items-center gap-2 mt-1">
                <span className="text-sm font-extrabold text-[#58311F]">
                  {formatRupiah(product.price)}
                </span>
                <span className="text-[11px] text-[#8C7A70]">
                  • Sisa Stok: <strong className="text-[#2D1B14]">{remainingStock} Cup</strong>
                </span>
              </div>
            </div>
          </div>

          {/* Section 1: Tingkat Es (Ice Level) */}
          <div className="bg-white rounded-2xl p-3.5 border border-[#E8DFD8] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold text-[#58311F] uppercase tracking-wider flex items-center gap-1.5">
                <span>🧊 Tingkat Es (Ice Level)</span>
              </label>
              <span className="text-[11px] font-bold text-[#8B4513] px-2 py-0.5 rounded-full bg-[#FAF0E6]">
                {iceLevel}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {ICE_OPTIONS.map((opt) => {
                const isSelected = iceLevel === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setIceLevel(opt.value)}
                    className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all active:scale-95 ${
                      isSelected
                        ? 'bg-[#58311F] text-white border-[#58311F] shadow-sm ring-2 ring-[#D4A373]'
                        : 'bg-[#FAF8F5] hover:bg-[#F2ECE4] text-[#2D1B14] border-[#E8DFD8]'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-1">
                      <span className="text-base">{opt.icon}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-[#D4A373]" />}
                    </div>
                    <div className="font-bold text-xs truncate">{opt.label}</div>
                    <div
                      className={`text-[10px] truncate ${
                        isSelected ? 'text-[#E8DFD8]' : 'text-[#8C7A70]'
                      }`}
                    >
                      {opt.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2: Tingkat Manis (Sugar Level) */}
          <div className="bg-white rounded-2xl p-3.5 border border-[#E8DFD8] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold text-[#58311F] uppercase tracking-wider flex items-center gap-1.5">
                <span>🍯 Tingkat Manis (Sugar Level)</span>
              </label>
              <span className="text-[11px] font-bold text-[#8B4513] px-2 py-0.5 rounded-full bg-[#FAF0E6]">
                {sugarLevel}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {SUGAR_OPTIONS.map((opt) => {
                const isSelected = sugarLevel === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setSugarLevel(opt.value)}
                    className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all active:scale-95 ${
                      isSelected
                        ? 'bg-[#58311F] text-white border-[#58311F] shadow-sm ring-2 ring-[#D4A373]'
                        : 'bg-[#FAF8F5] hover:bg-[#F2ECE4] text-[#2D1B14] border-[#E8DFD8]'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-1">
                      <span className="text-base">{opt.icon}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-[#D4A373]" />}
                    </div>
                    <div className="font-bold text-xs truncate">{opt.label}</div>
                    <div
                      className={`text-[10px] truncate ${
                        isSelected ? 'text-[#E8DFD8]' : 'text-[#8C7A70]'
                      }`}
                    >
                      {opt.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 3: Catatan Khusus & Quick Tags */}
          <div className="bg-white rounded-2xl p-3.5 border border-[#E8DFD8] space-y-2">
            <label className="text-xs font-bold text-[#58311F] uppercase tracking-wider block">
              Catatan Khusus Racikan (Opsional)
            </label>

            {/* Quick Note Pills */}
            <div className="flex flex-wrap gap-1.5">
              {QUICK_NOTES.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => {
                    if (notes.includes(preset)) {
                      setNotes(notes.replace(preset, '').replace(/,\s*,/g, ',').trim());
                    } else {
                      setNotes(notes ? `${notes}, ${preset}` : preset);
                    }
                  }}
                  className={`text-[11px] font-semibold px-2.5 py-1 rounded-lg border transition-all ${
                    notes.includes(preset)
                      ? 'bg-[#8B4513] text-white border-[#8B4513]'
                      : 'bg-[#FAF8F5] text-[#58311F] border-[#D7CCC8] hover:bg-[#F2ECE4]'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>

            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Contoh: Tarik busa tebal, gelas plastik"
              className="w-full px-3 py-2 text-xs rounded-xl border border-[#D7CCC8] bg-[#FAF8F5] focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
            />
          </div>

          {/* Quantity selector */}
          <div className="flex items-center justify-between p-3.5 bg-white rounded-2xl border border-[#E8DFD8]">
            <div>
              <span className="text-xs font-bold text-[#2D1B14] block">Jumlah Cup</span>
              <span className="text-[11px] text-[#8C7A70]">
                Subtotal: {formatRupiah(product.price * quantity)}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={quantity <= 1}
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-8 h-8 rounded-xl border border-[#D7CCC8] flex items-center justify-center text-[#58311F] hover:bg-[#FAF8F5] disabled:opacity-40"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-8 text-center font-extrabold text-base text-[#2D1B14]">
                {quantity}
              </span>
              <button
                type="button"
                disabled={quantity >= remainingStock}
                onClick={() => setQuantity((q) => Math.min(remainingStock, q + 1))}
                className="w-8 h-8 rounded-xl bg-[#58311F] text-white flex items-center justify-center hover:bg-[#432314] disabled:opacity-40"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 bg-white border-t border-[#E8DFD8] flex items-center justify-between gap-2.5">
          <button
            type="button"
            onClick={handleQuickAddDefault}
            className="px-3.5 py-2.5 rounded-xl border border-[#D7CCC8] text-xs font-bold text-[#58311F] hover:bg-[#FAF8F5] transition-colors"
            title="Tambah langsung dengan Normal Ice & Normal Sugar"
          >
            ⚡ Default Normal
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2.5 rounded-xl border border-[#D7CCC8] text-xs font-bold text-[#6B574B] hover:bg-[#FAF8F5]"
            >
              Batal
            </button>

            <button
              type="button"
              disabled={remainingStock <= 0}
              onClick={handleConfirm}
              className="px-4 sm:px-5 py-2.5 rounded-xl bg-[#58311F] hover:bg-[#432314] text-white text-xs font-bold flex items-center gap-2 shadow-md transition-all active:scale-95 disabled:opacity-50"
            >
              <ShoppingBag className="w-4 h-4 text-[#D4A373]" />
              <span>
                + Masuk Keranjang ({formatRupiah(product.price * quantity)})
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
