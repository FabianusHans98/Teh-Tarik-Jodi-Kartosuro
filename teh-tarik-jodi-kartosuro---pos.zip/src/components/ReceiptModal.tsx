import React, { useState } from 'react';
import {
  Printer,
  X,
  Share2,
  Copy,
  Check,
  PlusCircle,
  Coffee,
  CheckCircle,
  Bluetooth,
  Loader2,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { Transaction } from '../types';
import { formatRupiah, formatDateTimeIndo } from '../utils/formatters';
import { printReceiptViaBluetooth, isWebBluetoothSupported } from '../utils/bluetoothPrinter';

interface ReceiptModalProps {
  transaction: Transaction | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  transaction,
  onClose,
}) => {
  const { shopInfo, setActiveTab } = usePOS();
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>('58mm');
  const [copied, setCopied] = useState(false);
  const [isBluetoothPrinting, setIsBluetoothPrinting] = useState(false);
  const [btStatusMsg, setBtStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleBluetoothPrint = async () => {
    setIsBluetoothPrinting(true);
    setBtStatusMsg(null);
    try {
      const result = await printReceiptViaBluetooth(transaction, shopInfo, paperWidth);
      if (result.success) {
        setBtStatusMsg({ type: 'success', text: result.message });
      } else {
        setBtStatusMsg({ type: 'error', text: result.message });
      }
    } catch (err: any) {
      setBtStatusMsg({ type: 'error', text: err?.message || 'Gagal menyambung ke printer Bluetooth.' });
    } finally {
      setIsBluetoothPrinting(false);
    }
  };

  const generateWhatsAppText = () => {
    const lines = [
      `*🧾 STRUK PEMBELIAN - ${shopInfo.name.toUpperCase()}*`,
      `Owner: ${shopInfo.ownerName}`,
      `${shopInfo.address}, ${shopInfo.city}`,
      `Telp: ${shopInfo.phone} | IG: ${shopInfo.instagram}`,
      `--------------------------------`,
      `No. Struk: ${transaction.receiptNumber}`,
      `Waktu: ${formatDateTimeIndo(transaction.timestamp)}`,
      `Kasir: ${transaction.cashierName}`,
      `Pesanan: ${transaction.orderType === 'DINE_IN' ? 'Dine In' : 'Take Away'}${transaction.tableNumber ? ` (Meja ${transaction.tableNumber})` : ''}`,
      transaction.customerName ? `Pelanggan: ${transaction.customerName}` : '',
      `--------------------------------`,
      ...transaction.items.map(item =>
        `${item.name} (${item.quantity}x @${formatRupiah(item.price)}) = ${formatRupiah(item.subtotal)}${item.notes ? `\n  - Catatan: ${item.notes}` : ''}`
      ),
      `--------------------------------`,
      `Subtotal: ${formatRupiah(transaction.subtotal)}`,
      transaction.discountAmount > 0 ? `Diskon: -${formatRupiah(transaction.discountAmount)}` : '',
      transaction.taxAmount > 0 ? `PB1 (10%): +${formatRupiah(transaction.taxAmount)}` : '',
      `*TOTAL: ${formatRupiah(transaction.grandTotal)}*`,
      `Metode: ${transaction.paymentMethod}`,
      `Bayar: ${formatRupiah(transaction.amountPaid)}`,
      `Kembalian: ${formatRupiah(transaction.change)}`,
      `--------------------------------`,
      `Terima kasih sudah menikmati sajian Teh Tarik Jodi Kartosuro!`
    ].filter(Boolean).join('\n');

    return lines;
  };

  const handleCopyText = () => {
    const text = generateWhatsAppText();
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNewTransaction = () => {
    onClose();
    setActiveTab('pos');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-[#E8DFD8] overflow-hidden my-auto flex flex-col max-h-[95vh]">
        {/* Header Controls */}
        <div className="p-4 bg-[#2D1B14] text-[#FAF7F2] flex items-center justify-between border-b border-[#4A2E22]">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">
                Transaksi Berhasil!
              </h3>
              <p className="text-[11px] text-[#D4A373]">
                Struk Siap Dicetak & Disimpan
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* 58mm vs 80mm Switcher */}
            <div className="flex items-center bg-[#1F130D] rounded-lg p-0.5 border border-[#3E2419]">
              <button
                type="button"
                onClick={() => setPaperWidth('58mm')}
                className={`px-2 py-1 rounded text-[10px] font-bold transition-all ${
                  paperWidth === '58mm'
                    ? 'bg-[#D4A373] text-[#2D1B14]'
                    : 'text-[#E6CCB2] hover:text-white'
                }`}
              >
                58mm
              </button>
              <button
                type="button"
                onClick={() => setPaperWidth('80mm')}
                className={`px-2 py-1 rounded text-[10px] font-bold transition-all ${
                  paperWidth === '80mm'
                    ? 'bg-[#D4A373] text-[#2D1B14]'
                    : 'text-[#E6CCB2] hover:text-white'
                }`}
              >
                80mm
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1 rounded-lg text-[#FAF7F2]/70 hover:text-white hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Receipt Visual Paper (Screen Preview & Print Target) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#EFE9E2] flex justify-center">
          <div
            id="thermal-receipt-print-area"
            style={{ width: paperWidth === '58mm' ? '280px' : '360px' }}
            className="bg-white p-4 sm:p-5 rounded-lg shadow-md border border-neutral-300 font-receipt text-xs leading-relaxed text-neutral-900 transition-all duration-150"
          >
            {/* Kopitiam Header */}
            <div className="text-center space-y-1 pb-3 border-b border-dashed border-neutral-400">
              <h2 className="font-bold text-sm tracking-wider uppercase text-black">
                {shopInfo.name}
              </h2>
              <p className="text-[10px] text-neutral-600 font-sans">
                {shopInfo.tagline}
              </p>
              <p className="text-[10px] text-neutral-600">
                {shopInfo.address}, {shopInfo.city}
              </p>
              <p className="text-[10px] text-neutral-600">
                Telp: {shopInfo.phone} • IG: {shopInfo.instagram}
              </p>
              <div className="text-[10px] font-semibold text-neutral-800 pt-0.5">
                Owner: {shopInfo.ownerName}
              </div>
            </div>

            {/* Metadata Info */}
            <div className="py-2.5 border-b border-dashed border-neutral-400 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span>No. Struk:</span>
                <span className="font-bold">{transaction.receiptNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>Waktu:</span>
                <span>{formatDateTimeIndo(transaction.timestamp)}</span>
              </div>
              <div className="flex justify-between">
                <span>Kasir:</span>
                <span>{transaction.cashierName}</span>
              </div>
              <div className="flex justify-between">
                <span>Tipe:</span>
                <span className="font-bold">
                  {transaction.orderType === 'DINE_IN' ? 'DINE IN' : 'TAKE AWAY'}
                </span>
              </div>
              {(transaction.customerName || transaction.tableNumber) && (
                <div className="flex justify-between">
                  <span>Pelanggan/Meja:</span>
                  <span className="font-bold">
                    {transaction.customerName || '-'} / {transaction.tableNumber ? `Meja ${transaction.tableNumber}` : '-'}
                  </span>
                </div>
              )}
            </div>

            {/* Item List */}
            <div className="py-2.5 border-b border-dashed border-neutral-400 space-y-2">
              <div className="flex justify-between font-bold text-[11px] pb-1 border-b border-neutral-200">
                <span>ITEM</span>
                <span>TOTAL</span>
              </div>

              {transaction.items.map((item, idx) => (
                <div key={idx} className="space-y-0.5">
                  <div className="flex justify-between items-start">
                    <span className="font-medium pr-2">{item.name}</span>
                    <span className="font-bold shrink-0">{formatRupiah(item.subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-neutral-600">
                    <span>
                      {item.quantity} x {formatRupiah(item.price)}
                    </span>
                  </div>
                  {item.notes && (
                    <div className="text-[10px] italic text-neutral-500 pl-1">
                      * Catatan: {item.notes}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Totals & Payments */}
            <div className="py-2.5 border-b border-dashed border-neutral-400 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>{formatRupiah(transaction.subtotal)}</span>
              </div>

              {transaction.discountAmount > 0 && (
                <div className="flex justify-between text-neutral-700">
                  <span>Diskon:</span>
                  <span>-{formatRupiah(transaction.discountAmount)}</span>
                </div>
              )}

              {transaction.taxAmount > 0 && (
                <div className="flex justify-between text-neutral-700">
                  <span>PB1 Resto (10%):</span>
                  <span>+{formatRupiah(transaction.taxAmount)}</span>
                </div>
              )}

              <div className="flex justify-between font-bold text-sm pt-1 border-t border-neutral-300">
                <span>TOTAL BAYAR:</span>
                <span>{formatRupiah(transaction.grandTotal)}</span>
              </div>

              <div className="flex justify-between pt-1">
                <span>Metode Bayar:</span>
                <span className="font-bold">{transaction.paymentMethod}</span>
              </div>

              <div className="flex justify-between">
                <span>Diterima:</span>
                <span>{formatRupiah(transaction.amountPaid)}</span>
              </div>

              <div className="flex justify-between font-bold">
                <span>Kembalian:</span>
                <span>{formatRupiah(transaction.change)}</span>
              </div>
            </div>

            {/* Footer */}
            <div className="pt-3 text-center space-y-1">
              <p className="font-medium text-[11px]">
                Terima Kasih atas Kunjungan Anda!
              </p>
              <p className="text-[10px] text-neutral-600">
                Nikmatnya Teh Tarik Asli Racikan Tradisional Kartosuro
              </p>
              <p className="text-[9px] text-neutral-400">
                *** Struk Sah Pembayaran ***
              </p>
            </div>
          </div>
        </div>

        {/* Bluetooth Print Feedback Notification */}
        {btStatusMsg && (
          <div
            className={`mx-4 mt-2 px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-between gap-2 border ${
              btStatusMsg.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                : 'bg-red-50 text-red-800 border-red-300'
            }`}
          >
            <span>{btStatusMsg.text}</span>
            <button
              onClick={() => setBtStatusMsg(null)}
              className="text-xs opacity-75 hover:opacity-100 font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {/* Modal Bottom Actions */}
        <div className="p-4 bg-white border-t border-[#E8DFD8] flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex flex-wrap items-center gap-2">
            {/* Copy / WhatsApp Button */}
            <button
              type="button"
              onClick={handleCopyText}
              className="px-3 py-2 rounded-xl border border-[#D7CCC8] hover:bg-[#FAF8F5] text-xs font-semibold text-[#58311F] flex items-center gap-1.5 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700">Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Salin WA</span>
                </>
              )}
            </button>

            {/* Bluetooth Thermal Print Button */}
            <button
              type="button"
              disabled={isBluetoothPrinting}
              onClick={handleBluetoothPrint}
              className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all disabled:opacity-50"
              title="Koneksikan & cetak langsung ke printer Bluetooth ESC/POS 58mm/80mm"
            >
              {isBluetoothPrinting ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Bluetooth className="w-3.5 h-3.5 text-blue-200" />
              )}
              <span>{isBluetoothPrinting ? 'Mencetak...' : 'Cetak Bluetooth'}</span>
            </button>

            {/* Direct Browser Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              className="px-3.5 py-2 rounded-xl bg-[#58311F] hover:bg-[#432314] text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all"
            >
              <Printer className="w-3.5 h-3.5 text-[#D4A373]" />
              <span>Cetak ({paperWidth})</span>
            </button>
          </div>

          <button
            type="button"
            onClick={handleNewTransaction}
            className="px-4 py-2 rounded-xl bg-[#D4A373] hover:bg-[#BC6C25] text-[#2D1B14] hover:text-white text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-sm"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Transaksi Baru</span>
          </button>
        </div>
      </div>
    </div>
  );
};
