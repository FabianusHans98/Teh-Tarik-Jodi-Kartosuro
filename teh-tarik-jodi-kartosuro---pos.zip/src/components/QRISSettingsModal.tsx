export { PaymentSettingsModal as QRISSettingsModal, PaymentSettingsModal } from './PaymentSettingsModal';
export default './PaymentSettingsModal';
