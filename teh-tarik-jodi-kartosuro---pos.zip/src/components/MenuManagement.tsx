import React, { useState } from 'react';
import {
  Plus,
  Edit2,
  Trash2,
  RotateCcw,
  Search,
  Check,
  X,
  Coffee,
  AlertCircle,
  Tag,
  DollarSign,
  Boxes,
  Image as ImageIcon,
  Upload,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { Product } from '../types';
import { formatRupiah } from '../utils/formatters';
import { PRESET_DRINK_IMAGES } from '../data/initialData';

export const MenuManagement: React.FC = () => {
  const {
    products,
    categories,
    addProduct,
    updateProduct,
    deleteProduct,
    resetToDefaultMenu,
    shopInfo,
  } = usePOS();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Semua');

  // Form modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('Teh Spesial');
  const [newCategoryInput, setNewCategoryInput] = useState('');
  const [stock, setStock] = useState('50');
  const [minStockAlert, setMinStockAlert] = useState('10');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Delete confirmation
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const openAddModal = () => {
    setEditingProduct(null);
    setName('');
    setPrice('');
    setCategory(categories[1] || 'Teh Spesial');
    setNewCategoryInput('');
    setStock('50');
    setMinStockAlert('10');
    setDescription('');
    setImage(PRESET_DRINK_IMAGES[0]?.url || '');
    setErrorMessage('');
    setIsModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setName(p.name);
    setPrice(p.price.toString());
    setCategory(p.category);
    setNewCategoryInput('');
    setStock(p.stock.toString());
    setMinStockAlert(p.minStockAlert.toString());
    setDescription(p.description || '');
    setImage(p.image || '');
    setErrorMessage('');
    setIsModalOpen(true);
  };

  const handleImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMessage('Harap unggah file gambar (JPG, PNG, WEBP).');
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      setErrorMessage('Ukuran file gambar maksimal 3MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const res = e.target?.result as string;
      if (res) setImage(res);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMessage('Nama menu wajib diisi.');
      return;
    }

    const parsedPrice = parseInt(price, 10);
    if (isNaN(parsedPrice) || parsedPrice <= 0) {
      setErrorMessage('Harga menu harus lebih besar dari 0.');
      return;
    }

    const parsedStock = parseInt(stock, 10);
    const parsedMinStock = parseInt(minStockAlert, 10);

    const finalCategory = newCategoryInput.trim() ? newCategoryInput.trim() : category;

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name: name.trim(),
        price: parsedPrice,
        category: finalCategory,
        stock: isNaN(parsedStock) ? 0 : Math.max(0, parsedStock),
        minStockAlert: isNaN(parsedMinStock) ? 5 : Math.max(0, parsedMinStock),
        description: description.trim(),
        image: image.trim() || undefined,
      });
    } else {
      addProduct({
        name: name.trim(),
        price: parsedPrice,
        category: finalCategory,
        stock: isNaN(parsedStock) ? 50 : Math.max(0, parsedStock),
        minStockAlert: isNaN(parsedMinStock) ? 10 : Math.max(0, parsedMinStock),
        description: description.trim(),
        image: image.trim() || undefined,
        isAvailable: true,
      });
    }

    setIsModalOpen(false);
  };

  const filtered = products.filter((item) => {
    const matchCat = selectedCategory === 'Semua' || item.category === selectedCategory;
    const matchSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="flex-1 p-4 sm:p-6 bg-[#FDFBF7] overflow-y-auto space-y-5">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-[#E8DFD8] shadow-xs">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-[#2D1B14] flex items-center gap-2">
            <Coffee className="w-5 h-5 text-[#58311F]" />
            <span>Manajemen Menu & Harga (Katalog CRUD)</span>
          </h2>
          <p className="text-xs text-[#8C7A70] mt-0.5">
            Kelola daftar menu kedai milik {shopInfo.ownerName}. Ubah harga, perbarui nama, atau tambah menu baru.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={openAddModal}
            className="px-4 py-2 rounded-xl bg-[#58311F] hover:bg-[#432314] text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
          >
            <Plus className="w-4 h-4 text-[#D4A373]" />
            <span>Tambah Menu Baru</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (confirm('Kembalikan ke 6 menu awal bawaan Teh Tarik Jodi Kartosuro?')) {
                resetToDefaultMenu();
              }
            }}
            className="px-3 py-2 rounded-xl border border-[#D7CCC8] hover:bg-[#FAF8F5] text-xs font-semibold text-[#6B4F3E] flex items-center gap-1.5 transition-colors"
            title="Reset ke 6 menu awal"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset Default (6 Menu)</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-[#E8DFD8]">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-[#8C7A70] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari menu untuk diedit..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] focus:outline-none focus:ring-1 focus:ring-[#D4A373]"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-[#58311F] text-white'
                  : 'bg-[#FAF8F5] text-[#6B4F3E] hover:bg-[#EFE9E2]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Products Table / Cards */}
      <div className="bg-white rounded-2xl border border-[#E8DFD8] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#FAF8F5] text-[#58311F] border-b border-[#E8DFD8] uppercase tracking-wider font-bold">
              <tr>
                <th className="py-3 px-4">Nama Menu</th>
                <th className="py-3 px-4">Kategori</th>
                <th className="py-3 px-4">Harga Jual</th>
                <th className="py-3 px-4">Stok Saat Ini</th>
                <th className="py-3 px-4">Batas Peringatan</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F2ECE4]">
              {filtered.map((item) => (
                <tr key={item.id} className="hover:bg-[#FAF8F5]/80 transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      {/* Product Thumbnail */}
                      <div className="w-12 h-12 rounded-xl overflow-hidden bg-[#F4EBE1] border border-[#E8DFD8] shrink-0 shadow-2xs">
                        {item.image ? (
                          <img
                            src={item.image}
                            alt={item.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                            }}
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-[#7A4B2A]">
                            <Coffee className="w-5 h-5 opacity-70" />
                          </div>
                        )}
                      </div>

                      <div>
                        <div className="font-bold text-sm text-[#2D1B14]">{item.name}</div>
                        {item.description && (
                          <div className="text-[11px] text-[#8C7A70] line-clamp-1 max-w-sm">
                            {item.description}
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-[#F4EBE1] text-[#7A4B2A] font-semibold text-[11px]">
                      {item.category}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-extrabold text-sm text-[#58311F]">
                    {formatRupiah(item.price)}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`font-bold px-2 py-0.5 rounded ${
                        item.stock === 0
                          ? 'bg-red-100 text-red-700'
                          : item.stock <= item.minStockAlert
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {item.stock} unit
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#8C7A70]">
                    &le; {item.minStockAlert} unit
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        type="button"
                        onClick={() => openEditModal(item)}
                        className="p-1.5 rounded-lg text-[#58311F] hover:bg-[#F4EBE1] transition-colors"
                        title="Edit Menu"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>

                      {deleteConfirmId === item.id ? (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              deleteProduct(item.id);
                              setDeleteConfirmId(null);
                            }}
                            className="px-2 py-1 rounded bg-red-600 text-white font-bold text-[10px]"
                          >
                            Ya, Hapus
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteConfirmId(null)}
                            className="px-1.5 py-1 rounded border text-[10px]"
                          >
                            Batal
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setDeleteConfirmId(item.id)}
                          className="p-1.5 rounded-lg text-neutral-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                          title="Hapus Menu"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Product */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-[#E8DFD8] overflow-hidden my-auto">
            <div className="p-4 bg-[#2D1B14] text-[#FAF7F2] flex items-center justify-between">
              <h3 className="font-bold text-sm sm:text-base text-white">
                {editingProduct ? 'Edit Menu Kedai' : 'Tambah Menu Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-[#FAF7F2]/70 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-3.5 text-xs text-[#2D1B14]">
              {errorMessage && (
                <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Product Name */}
              <div>
                <label className="block font-semibold text-[#58311F] mb-1">
                  Nama Menu Minuman / Makanan *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Teh Tarik, Kopitiam Susu, dll"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-[#D7CCC8] text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                />
              </div>

              {/* Price */}
              <div>
                <label className="block font-semibold text-[#58311F] mb-1">
                  Harga Jual (Rp) *
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  step="500"
                  placeholder="12000"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-[#D7CCC8] text-sm focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block font-semibold text-[#58311F] mb-1">
                  Kategori
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-[#D7CCC8] text-xs focus:outline-none focus:ring-2 focus:ring-[#D4A373] bg-white mb-1.5"
                >
                  {categories.filter(c => c !== 'Semua').map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                  <option value="CUSTOM">+ Tambah Kategori Baru...</option>
                </select>

                {category === 'CUSTOM' && (
                  <input
                    type="text"
                    placeholder="Ketik nama kategori baru..."
                    value={newCategoryInput}
                    onChange={(e) => setNewCategoryInput(e.target.value)}
                    className="w-full p-2 rounded-lg border border-[#D7CCC8] text-xs bg-[#FAF8F5]"
                  />
                )}
              </div>

              {/* Stock & Min Stock Alert */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-[#58311F] mb-1">
                    Stok Awal
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={stock}
                    onChange={(e) => setStock(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-[#D7CCC8] text-xs focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#58311F] mb-1">
                    Peringatan Stok &le;
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={minStockAlert}
                    onChange={(e) => setMinStockAlert(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-[#D7CCC8] text-xs focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                  />
                </div>
              </div>

              {/* Image Selection & Preview */}
              <div>
                <label className="block font-semibold text-[#58311F] mb-1">
                  Foto Visual Menu (Kualitas Tinggi)
                </label>

                <div className="flex gap-3 items-start mb-2">
                  {/* Live Preview */}
                  <div className="w-20 h-20 rounded-2xl overflow-hidden bg-[#F4EBE1] border border-[#D7CCC8] shrink-0 shadow-2xs relative">
                    {image ? (
                      <img
                        src={image}
                        alt="Preview"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-[#7A4B2A] p-1 text-center">
                        <ImageIcon className="w-6 h-6 opacity-60 mb-0.5" />
                        <span className="text-[9px] leading-tight text-[#8C7A70]">Tanpa Foto</span>
                      </div>
                    )}
                  </div>

                  {/* Input URL & File Upload */}
                  <div className="flex-1 space-y-1.5 min-w-0">
                    <input
                      type="url"
                      placeholder="Masukkan URL Foto (Unsplash / Web)..."
                      value={image}
                      onChange={(e) => setImage(e.target.value)}
                      className="w-full p-2 rounded-xl border border-[#D7CCC8] text-xs focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                    />

                    <div className="flex items-center gap-2">
                      <label className="cursor-pointer inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-[#D7CCC8] bg-[#FAF8F5] hover:bg-[#EFE9E2] text-[#58311F] text-[11px] font-semibold transition-colors">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Unggah dari Perangkat</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            if (e.target.files?.[0]) {
                              handleImageFile(e.target.files[0]);
                            }
                          }}
                        />
                      </label>

                      {image && (
                        <button
                          type="button"
                          onClick={() => setImage('')}
                          className="text-[11px] text-red-600 hover:underline"
                        >
                          Hapus Foto
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Preset Drink Photos Selection */}
                <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E8DFD8]">
                  <div className="text-[10px] font-bold text-[#8C7A70] uppercase tracking-wider mb-1.5">
                    Pilihan Cepat Foto Kopitiam:
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {PRESET_DRINK_IMAGES.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setImage(preset.url)}
                        className={`text-[10px] font-medium px-2 py-1 rounded-md border transition-all ${
                          image === preset.url
                            ? 'bg-[#58311F] text-white border-[#58311F] shadow-xs'
                            : 'bg-white text-[#58311F] border-[#E8DFD8] hover:bg-[#F4EBE1]'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block font-semibold text-[#58311F] mb-1">
                  Deskripsi Menu (Opsional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Keterangan racikan menu..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-2 rounded-xl border border-[#D7CCC8] text-xs focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-[#D7CCC8] text-xs font-semibold text-[#58311F] hover:bg-[#FAF8F5]"
                >
                  Batal
                </button>

                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#58311F] hover:bg-[#432314] text-white font-bold text-xs shadow-sm flex items-center justify-center gap-1"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingProduct ? 'Simpan Perubahan' : 'Tambah Menu'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
