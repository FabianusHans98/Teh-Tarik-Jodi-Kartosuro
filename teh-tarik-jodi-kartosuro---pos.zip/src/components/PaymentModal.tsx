import React, { useState, useEffect } from 'react';
import {
  X,
  Banknote,
  QrCode,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Receipt,
  Store,
  ArrowRight,
  Settings,
  Maximize2,
  Sparkles,
} from 'lucide-react';
import { usePOS } from '../context/POSContext';
import { PaymentMethod } from '../types';
import { formatRupiah } from '../utils/formatters';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenPaymentSettings?: (tab?: 'qris' | 'bank' | 'profile') => void;
  onOpenQRISSettings?: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  onOpenPaymentSettings,
  onOpenQRISSettings,
}) => {
  const {
    cartGrandTotal,
    cartSubtotal,
    discountAmount,
    taxAmount,
    totalCartItemsCount,
    orderType,
    customerName,
    tableNumber,
    shopInfo,
    completePayment,
  } = usePOS();

  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('CASH');
  const [cashGiven, setCashGiven] = useState<number>(cartGrandTotal);
  const [copiedBank, setCopiedBank] = useState<string | null>(null);
  const [qrZoomed, setQrZoomed] = useState<boolean>(false);

  // Sync cash given whenever total changes or modal opens
  useEffect(() => {
    if (isOpen) {
      setCashGiven(cartGrandTotal);
      setQrZoomed(false);
    }
  }, [isOpen, cartGrandTotal]);

  if (!isOpen) return null;

  // Preset cash quick buttons
  const cashPresets = [
    { label: 'Uang Pas', value: cartGrandTotal },
    { label: 'Rp 20.000', value: 20000 },
    { label: 'Rp 50.000', value: 50000 },
    { label: 'Rp 100.000', value: 100000 },
    { label: 'Rp 150.000', value: 150000 },
    { label: 'Rp 200.000', value: 200000 },
  ].filter(p => p.value >= cartGrandTotal || p.label === 'Uang Pas');

  const change = Math.max(0, cashGiven - cartGrandTotal);
  const isCashInsufficient = selectedMethod === 'CASH' && cashGiven < cartGrandTotal;

  const handleCopyAccount = (accNumber: string, bank: string) => {
    navigator.clipboard.writeText(accNumber);
    setCopiedBank(bank);
    setTimeout(() => setCopiedBank(null), 2000);
  };

  const handleFinishTransaction = () => {
    if (isCashInsufficient) return;
    const finalAmountPaid = selectedMethod === 'CASH' ? cashGiven : cartGrandTotal;
    completePayment(selectedMethod, finalAmountPaid);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-[#E8DFD8] overflow-hidden my-auto">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#2D1B14] to-[#4A2E22] text-[#FAF7F2] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#D4A373] text-[#2D1B14] flex items-center justify-center font-extrabold shadow-inner">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#FAF7F2] leading-tight">
                Pembayaran Kasir
              </h3>
              <p className="text-xs text-[#D4A373]">
                {shopInfo.name} • Owner: {shopInfo.ownerName}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#FAF7F2]/70 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Order Summary Pill */}
          <div className="p-3 rounded-2xl bg-[#FAF8F5] border border-[#E8DFD8] flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="space-y-0.5">
              <span className="font-bold text-[#58311F] text-sm block">
                {orderType === 'DINE_IN' ? 'Dine In (Makan di Kedai)' : 'Take Away (Bungkus)'}
              </span>
              <span className="text-[#8C7A70]">
                {customerName ? `Pelanggan: ${customerName}` : 'Pelanggan Umum'}
                {tableNumber && ` • Meja: ${tableNumber}`}
              </span>
            </div>

            <div className="text-right">
              <span className="text-[11px] text-[#8C7A70] block">Total Tagihan ({totalCartItemsCount} menu)</span>
              <span className="font-extrabold text-lg text-[#58311F]">
                {formatRupiah(cartGrandTotal)}
              </span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-[#58311F] uppercase tracking-wider">
                Pilih Metode Pembayaran
              </label>
              <span className="text-[10px] text-[#8C7A70]">
                Metode Utama: Tunai & QRIS
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedMethod('CASH')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all relative ${
                  selectedMethod === 'CASH'
                    ? 'bg-[#58311F] text-white border-[#58311F] shadow-sm ring-2 ring-[#D4A373]/50'
                    : 'bg-[#FAF8F5] text-[#6B4F3E] border-[#E8DFD8] hover:bg-[#F2ECE4]'
                }`}
              >
                <Banknote className="w-5 h-5" />
                <span className="text-xs font-bold">Tunai (Cash)</span>
                <span className="text-[9px] opacity-80">Hitung Kembalian</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedMethod('QRIS')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all relative ${
                  selectedMethod === 'QRIS'
                    ? 'bg-[#58311F] text-white border-[#58311F] shadow-sm ring-2 ring-[#D4A373]/50'
                    : 'bg-[#FAF8F5] text-[#6B4F3E] border-[#E8DFD8] hover:bg-[#F2ECE4]'
                }`}
              >
                <QrCode className="w-5 h-5" />
                <span className="text-xs font-bold">QRIS Dinamis</span>
                <span className="text-[9px] opacity-80">
                  {shopInfo.qrisImageUrl ? 'Foto Barcode Aktif' : 'Semua E-Wallet'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedMethod('BANK_TRANSFER')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all ${
                  selectedMethod === 'BANK_TRANSFER'
                    ? 'bg-[#58311F] text-white border-[#58311F] shadow-sm ring-2 ring-[#D4A373]/50'
                    : 'bg-[#FAF8F5] text-[#6B4F3E] border-[#E8DFD8] hover:bg-[#F2ECE4]'
                }`}
              >
                <CreditCard className="w-5 h-5" />
                <span className="text-xs font-bold">Transfer Bank</span>
                <span className="text-[9px] opacity-80">BCA / Mandiri</span>
              </button>
            </div>
          </div>

          {/* Conditional Method Content */}
          {selectedMethod === 'CASH' && (
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E8DFD8] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#58311F]">Nominal Uang Diterima:</span>
                <span className="text-xs text-[#8C7A70]">Ketik manual atau klik pilihan cepat</span>
              </div>

              {/* Cash Input */}
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-sm text-[#58311F]">
                  Rp
                </span>
                <input
                  type="number"
                  min="0"
                  step="1000"
                  value={cashGiven || ''}
                  onChange={(e) => setCashGiven(Math.max(0, parseInt(e.target.value, 10) || 0))}
                  className="w-full pl-11 pr-4 py-2.5 rounded-xl border border-[#D7CCC8] bg-white font-extrabold text-base text-[#2D1B14] focus:outline-none focus:ring-2 focus:ring-[#D4A373]"
                  placeholder="0"
                />
              </div>

              {/* Quick Cash Presets */}
              <div className="flex flex-wrap gap-1.5">
                {cashPresets.map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => setCashGiven(preset.value)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                      cashGiven === preset.value
                        ? 'bg-[#D4A373] text-[#2D1B14] border-[#BC6C25]'
                        : 'bg-white text-[#58311F] border-[#D7CCC8] hover:bg-[#EFE9E2]'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              {/* Change Calculator Display */}
              <div className="pt-2 border-t border-[#E8DFD8]">
                {isCashInsufficient ? (
                  <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 flex items-center gap-2 text-xs font-medium">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>
                      Uang tunai kurang <strong>{formatRupiah(cartGrandTotal - cashGiven)}</strong>
                    </span>
                  </div>
                ) : (
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold text-emerald-800 block">
                        Uang Kembalian Pelanggan:
                      </span>
                      <span className="text-[11px] text-emerald-600">
                        {change === 0 ? 'Uang Pas, tidak ada kembalian' : 'Siapkan uang kembalian'}
                      </span>
                    </div>
                    <span className="font-extrabold text-lg text-emerald-700 font-receipt">
                      {formatRupiah(change)}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {selectedMethod === 'QRIS' && (
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E8DFD8] flex flex-col items-center text-center space-y-3">
              {/* Header Badges & Owner Action */}
              <div className="w-full flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600 text-white font-bold text-[10px] tracking-wider uppercase">
                  <span>QRIS RESMI</span>
                  <span>•</span>
                  <span>{shopInfo.qrisName || shopInfo.name}</span>
                </div>

                {(onOpenPaymentSettings || onOpenQRISSettings) && (
                  <button
                    type="button"
                    onClick={() => {
                      if (onOpenPaymentSettings) onOpenPaymentSettings('qris');
                      else if (onOpenQRISSettings) onOpenQRISSettings();
                    }}
                    className="text-[11px] font-semibold text-[#58311F] hover:text-[#2D1B14] bg-white hover:bg-[#FAF8F5] px-2.5 py-1 rounded-lg border border-[#D7CCC8] flex items-center gap-1 transition-colors shadow-2xs"
                    title="Buka Pengaturan QRIS & Barcode Toko"
                  >
                    <Settings className="w-3.5 h-3.5 text-[#8C7A70]" />
                    <span>Upload / Atur QRIS</span>
                  </button>
                )}
              </div>

              {/* QR Display Card */}
              <div className="relative p-3.5 bg-white rounded-2xl shadow-sm border border-[#D7CCC8] flex flex-col items-center max-w-[240px] w-full group">
                {/* Enlarge zoom button */}
                <button
                  type="button"
                  onClick={() => setQrZoomed(!qrZoomed)}
                  className="absolute top-2 right-2 p-1 rounded-md bg-neutral-100 hover:bg-neutral-200 text-neutral-600 transition-colors"
                  title="Perbesar / Perkecil QRIS"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>

                {shopInfo.qrisImageUrl ? (
                  <div className="py-1">
                    <img
                      src={shopInfo.qrisImageUrl}
                      alt="QRIS Merchant"
                      className={`object-contain rounded-lg transition-all ${
                        qrZoomed ? 'w-56 h-56' : 'w-40 h-40'
                      }`}
                    />
                    <div className="text-[9px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-semibold mt-1 inline-block">
                      ✓ Foto QRIS Resmi Rayvando
                    </div>
                  </div>
                ) : (
                  <div className="py-1">
                    <svg
                      viewBox="0 0 160 160"
                      className={`text-[#2D1B14] transition-all ${
                        qrZoomed ? 'w-56 h-56' : 'w-40 h-40'
                      }`}
                    >
                      <rect x="0" y="0" width="160" height="160" fill="#ffffff" rx="12" />
                      {/* Top-Left Finder */}
                      <rect x="14" y="14" width="36" height="36" rx="4" fill="#2D1B14" />
                      <rect x="20" y="20" width="24" height="24" rx="2" fill="#ffffff" />
                      <rect x="26" y="26" width="12" height="12" rx="1" fill="#2D1B14" />

                      {/* Top-Right Finder */}
                      <rect x="110" y="14" width="36" height="36" rx="4" fill="#2D1B14" />
                      <rect x="116" y="20" width="24" height="24" rx="2" fill="#ffffff" />
                      <rect x="122" y="26" width="12" height="12" rx="1" fill="#2D1B14" />

                      {/* Bottom-Left Finder */}
                      <rect x="14" y="110" width="36" height="36" rx="4" fill="#2D1B14" />
                      <rect x="20" y="116" width="24" height="24" rx="2" fill="#ffffff" />
                      <rect x="26" y="122" width="12" height="12" rx="1" fill="#2D1B14" />

                      {/* QR pattern simulation dots */}
                      <rect x="58" y="14" width="10" height="10" fill="#2D1B14" />
                      <rect x="76" y="14" width="8" height="8" fill="#2D1B14" />
                      <rect x="92" y="14" width="10" height="10" fill="#2D1B14" />
                      <rect x="58" y="32" width="16" height="8" fill="#2D1B14" />
                      <rect x="82" y="32" width="14" height="8" fill="#2D1B14" />
                      
                      {/* Middle decorative center */}
                      <rect x="14" y="58" width="12" height="12" fill="#2D1B14" />
                      <rect x="34" y="58" width="16" height="10" fill="#2D1B14" />
                      <rect x="58" y="58" width="44" height="44" rx="8" fill="#58311F" />
                      <circle cx="80" cy="80" r="14" fill="#D4A373" />
                      <text x="80" y="85" textAnchor="middle" fill="#2D1B14" fontSize="12" fontWeight="bold">TTJ</text>
                      
                      {/* Bottom pattern */}
                      <rect x="110" y="58" width="12" height="12" fill="#2D1B14" />
                      <rect x="130" y="58" width="16" height="12" fill="#2D1B14" />
                      <rect x="58" y="110" width="20" height="14" fill="#2D1B14" />
                      <rect x="86" y="110" width="14" height="20" fill="#2D1B14" />
                      <rect x="110" y="110" width="18" height="14" fill="#2D1B14" />
                      <rect x="134" y="110" width="12" height="24" fill="#2D1B14" />
                    </svg>
                  </div>
                )}

                <p className="font-bold text-xs text-[#2D1B14] mt-1.5 uppercase tracking-tight">
                  {shopInfo.qrisName || shopInfo.name}
                </p>
                <p className="text-[10px] text-[#8C7A70] font-mono">
                  NMID: {shopInfo.qrisNmid || 'ID1020083920192'} • Kartosuro
                </p>
              </div>

              {/* QRIS Guidance */}
              <div className="text-xs text-[#6B4F3E] max-w-sm space-y-1">
                <p>{shopInfo.qrisNotes || 'Arahkan kamera smartphone pelanggan ke QR Code di atas.'}</p>
                <p className="text-[11px] text-[#8C7A70]">
                  Mendukung: BCA, Livin, BRImo, BNI, GoPay, OVO, ShopeePay, DANA & LinkAja.
                </p>
              </div>
            </div>
          )}

          {selectedMethod === 'BANK_TRANSFER' && (
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E8DFD8] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#58311F] flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-[#8C7A70]" />
                  <span>Daftar Rekening Transfer Kedai:</span>
                </span>

                {(onOpenPaymentSettings || onOpenQRISSettings) && (
                  <button
                    type="button"
                    onClick={() => {
                      if (onOpenPaymentSettings) onOpenPaymentSettings('bank');
                      else if (onOpenQRISSettings) onOpenQRISSettings();
                    }}
                    className="text-[11px] font-semibold text-[#58311F] hover:text-[#2D1B14] bg-white hover:bg-[#FAF8F5] px-2.5 py-1 rounded-lg border border-[#D7CCC8] flex items-center gap-1 transition-colors shadow-2xs"
                    title="Tambah atau Edit Rekening Bank Kedai"
                  >
                    <Settings className="w-3.5 h-3.5 text-[#8C7A70]" />
                    <span>Kelola Rekening</span>
                  </button>
                )}
              </div>

              {shopInfo.bankAccounts && shopInfo.bankAccounts.length > 0 ? (
                shopInfo.bankAccounts.map((acc, index) => (
                  <div
                    key={`${acc.bankName}-${index}`}
                    className="p-3 rounded-xl bg-white border border-[#D7CCC8] flex items-center justify-between gap-3 shadow-2xs"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded bg-[#58311F] text-white text-[10px] font-bold">
                          {acc.bankName}
                        </span>
                        <span className="font-mono font-bold text-sm text-[#2D1B14]">
                          {acc.accountNumber}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#8C7A70]">a.n <strong>{acc.holderName}</strong></p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleCopyAccount(acc.accountNumber, acc.bankName)}
                      className="px-2.5 py-1.5 rounded-lg border border-[#D7CCC8] hover:bg-[#FAF8F5] text-xs font-semibold text-[#58311F] flex items-center gap-1"
                    >
                      {copiedBank === acc.bankName ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-700 font-bold">Tersalin</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Salin No. Rek</span>
                        </>
                      )}
                    </button>
                  </div>
                ))
              ) : (
                <div className="p-3 text-center text-xs text-[#8C7A70] bg-white rounded-xl border border-dashed border-[#D7CCC8]">
                  Belum ada rekening bank yang tersimpan. Klik tombol "Kelola Rekening" di atas untuk menambahkan rekening bank kedai.
                </div>
              )}

              <p className="text-[11px] text-[#8C7A70] text-center">
                Kasir harap memastikan mutasi atau struk transfer masuk sebelum menyelesaikan pesanan.
              </p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-4 rounded-xl border border-[#D7CCC8] text-xs font-semibold text-[#58311F] hover:bg-[#FAF8F5]"
            >
              Kembali
            </button>

            <button
              type="button"
              disabled={isCashInsufficient}
              onClick={handleFinishTransaction}
              className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition-all ${
                isCashInsufficient
                  ? 'bg-neutral-200 text-neutral-400 cursor-not-allowed'
                  : 'bg-[#58311F] hover:bg-[#432314] text-white active:scale-[0.99]'
              }`}
            >
              <CheckCircle2 className="w-4 h-4 text-[#D4A373]" />
              <span>Selesaikan & Terbitkan Struk</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
