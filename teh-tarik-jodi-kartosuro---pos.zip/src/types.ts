export type Category = 'Semua' | 'Teh Spesial' | 'Kopitiam' | 'Kotjok Series' | 'Camilan' | string;

export type IceLevel = 'Normal Ice' | 'Less Ice' | 'No Ice' | 'Hangat (Panas)';
export type SugarLevel = 'Normal Sugar' | 'Less Sugar' | 'No Sugar' | 'Extra Sweet';

export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  stock: number;
  minStockAlert: number;
  description?: string;
  image?: string;
  isAvailable: boolean;
  colorScheme?: string;
}

export interface CartItem {
  id: string; // unique cart item id (e.g. productId + iceLevel + sugarLevel + notes hash)
  productId: string;
  name: string;
  price: number;
  quantity: number;
  notes: string;
  iceLevel?: IceLevel;
  sugarLevel?: SugarLevel;
  maxStock: number;
  category: string;
  image?: string;
}

export type PaymentMethod = 'CASH' | 'QRIS' | 'BANK_TRANSFER';

export type OrderType = 'DINE_IN' | 'TAKE_AWAY';

export interface DiscountInfo {
  type: 'PERCENTAGE' | 'NOMINAL';
  value: number; // e.g. 10 for 10%, or 5000 for Rp 5.000
  code?: string;
}

export interface TransactionItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  subtotal: number;
  notes?: string;
  iceLevel?: IceLevel;
  sugarLevel?: SugarLevel;
  category?: string;
}

export interface Transaction {
  id: string; // e.g. TTJ-20260916-0001
  receiptNumber: string;
  timestamp: string; // ISO string
  items: TransactionItem[];
  subtotal: number;
  discountAmount: number;
  discountInfo?: DiscountInfo;
  taxAmount: number; // PB1 or service charge
  serviceFee: number;
  grandTotal: number;
  paymentMethod: PaymentMethod;
  amountPaid: number;
  change: number;
  orderType: OrderType;
  customerName?: string;
  tableNumber?: string;
  cashierName: string;
  ownerName: string;
  notes?: string;
}

export interface BankAccount {
  bankName: string;
  accountNumber: string;
  holderName: string;
}

export interface CashierShift {
  id: string;
  cashierName: string;
  startTime: string; // ISO string
  endTime?: string; // ISO string if closed
  startingCash: number; // Modal uang awal di laci kasir
  status: 'OPEN' | 'CLOSED';
  expectedCash: number; // startingCash + totalCashSales
  actualCash?: number; // Total uang fisik di laci saat tutup shift
  cashDifference?: number; // actualCash - expectedCash
  totalCashSales: number;
  totalQrisSales: number;
  totalBankSales: number;
  totalSales: number;
  transactionCount: number;
  notes?: string;
}

export interface ShopInfo {
  name: string;
  tagline: string;
  address: string;
  city: string;
  phone: string;
  instagram: string;
  ownerName: string;
  cashierName: string;
  taxRatePercent: number; // default 0% or configurable
  serviceFeePercent: number; // default 0%
  bankAccounts: BankAccount[];
  qrisName: string;
  qrisNmid: string;
  qrisImageUrl?: string; // base64 or URL uploaded by Rayvando (Owner)
  qrisNotes?: string;
}
