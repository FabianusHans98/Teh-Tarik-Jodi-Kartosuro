import { Product, ShopInfo } from '../types';
import imgTehO from '../assets/images/teh_o_kopitiam_1789613833535.jpg';
import imgTehTarik from '../assets/images/teh_tarik_frothy_1789613848377.jpg';
import imgKopiO from '../assets/images/kopi_o_medan_1789613859883.jpg';
import imgKopitiamSusu from '../assets/images/kopitiam_susu_layer_1789613871942.jpg';
import imgCoklatKotjok from '../assets/images/coklat_kotjok_ice_1789613884472.jpg';
import imgMatchaKotjok from '../assets/images/matcha_kotjok_latte_1789613895905.jpg';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-teh-o',
    name: 'Teh - O',
    price: 6000,
    category: 'Teh Spesial',
    stock: 50,
    minStockAlert: 10,
    description: 'Racikan teh murni Nusantara',
    isAvailable: true,
    image: imgTehO,
    colorScheme: 'from-amber-700 to-red-800'
  },
  {
    id: 'prod-teh-tarik',
    name: 'Teh Tarik',
    price: 10000,
    category: 'Teh Spesial',
    stock: 50,
    minStockAlert: 10,
    description: 'Racikan teh murni Nusantara dipadukan dengan susu dan krimer',
    isAvailable: true,
    image: imgTehTarik,
    colorScheme: 'from-amber-600 to-orange-700'
  },
  {
    id: 'prod-kopi-o',
    name: 'Kopi - O',
    price: 12000,
    category: 'Kopitiam',
    stock: 50,
    minStockAlert: 10,
    description: 'Kopi hitam murni asli Medan',
    isAvailable: true,
    image: imgKopiO,
    colorScheme: 'from-stone-800 to-stone-950'
  },
  {
    id: 'prod-kopitiam-susu',
    name: 'Kopitiam Susu',
    price: 12000,
    category: 'Kopitiam',
    stock: 50,
    minStockAlert: 10,
    description: 'Kopi hitam murni asli Medan dipadukan dengan susu dan krimer',
    isAvailable: true,
    image: imgKopitiamSusu,
    colorScheme: 'from-amber-800 to-stone-900'
  },
  {
    id: 'prod-coklat-kotjok',
    name: 'Coklat Kotjok',
    price: 12000,
    category: 'Kotjok Series',
    stock: 50,
    minStockAlert: 10,
    description: 'Dark coklat dipadukan dengan susu dan krimer',
    isAvailable: true,
    image: imgCoklatKotjok,
    colorScheme: 'from-amber-900 to-yellow-950'
  },
  {
    id: 'prod-matcha-kotjok',
    name: 'Matcha Kotjok',
    price: 12000,
    category: 'Kotjok Series',
    stock: 50,
    minStockAlert: 10,
    description: 'Matcha premium dipadukan dengan susu dan krimer',
    isAvailable: true,
    image: imgMatchaKotjok,
    colorScheme: 'from-emerald-700 to-lime-900'
  }
];

export const PRESET_DRINK_IMAGES = [
  {
    label: 'Teh Tarik Berbusa (Kopitiam)',
    url: imgTehTarik
  },
  {
    label: 'Kopi Susu Layer (Kopitiam)',
    url: imgKopitiamSusu
  },
  {
    label: 'Teh - O Panas Klasik',
    url: imgTehO
  },
  {
    label: 'Kopi - O Medan Pekat',
    url: imgKopiO
  },
  {
    label: 'Coklat Kotjok Dingin Indulgent',
    url: imgCoklatKotjok
  },
  {
    label: 'Matcha Kotjok Segar',
    url: imgMatchaKotjok
  },
  {
    label: 'Roti Panggang / Toast',
    url: 'https://images.unsplash.com/photo-1484723091739-30a097e8f929?auto=format&fit=crop&w=800&q=80'
  },
  {
    label: 'Camilan / Pastry',
    url: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80'
  }
];

export const INITIAL_CATEGORIES = [
  'Semua',
  'Teh Spesial',
  'Kopitiam',
  'Kotjok Series',
  'Camilan'
];

export const DEFAULT_SHOP_INFO: ShopInfo = {
  name: 'Teh Tarik Jodi Kartosuro',
  tagline: 'Cita Rasa Kopitiam Klasik & Kotjok Modern',
  address: 'Jl. Slamet Riyadi No. 48, Kartasuro',
  city: 'Kartasura, Sukoharjo, Jawa Tengah',
  phone: '0812-3456-7890',
  instagram: '@tehtarikjodi.kartosuro',
  ownerName: 'Rayvando',
  cashierName: 'Rayvando (Owner)',
  taxRatePercent: 0, // default 0% (opsional, bisa diaktifkan oleh owner)
  serviceFeePercent: 0,
  bankAccounts: [
    {
      bankName: 'BCA',
      accountNumber: '0158829910',
      holderName: 'RAYVANDO - TEH TARIK JODI'
    },
    {
      bankName: 'Mandiri',
      accountNumber: '1380029384910',
      holderName: 'RAYVANDO'
    }
  ],
  qrisName: 'TEH TARIK JODI KARTOSURO',
  qrisNmid: 'ID1020083920192',
  qrisNotes: 'Mendukung pembayaran scan QRIS: BCA, Livin, BRImo, GoPay, OVO, DANA, ShopeePay & LinkAja',
};
