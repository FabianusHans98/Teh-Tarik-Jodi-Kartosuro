import React, { useState } from 'react';
import { POSProvider, usePOS } from './context/POSContext';
import { Header } from './components/Header';
import { POSTerminal } from './components/POSTerminal';
import { CartSidebar } from './components/CartSidebar';
import { PaymentModal } from './components/PaymentModal';
import { ReceiptModal } from './components/ReceiptModal';
import { MenuManagement } from './components/MenuManagement';
import { InventoryManagement } from './components/InventoryManagement';
import { SalesReport } from './components/SalesReport';
import { TransactionHistory } from './components/TransactionHistory';
import { PaymentSettingsModal } from './components/PaymentSettingsModal';
import { ShoppingBag, X } from 'lucide-react';
import { formatRupiah } from './utils/formatters';

const POSAppContent: React.FC = () => {
  const {
    activeTab,
    currentReceipt,
    setCurrentReceipt,
    totalCartItemsCount,
    cartGrandTotal,
  } = usePOS();

  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [isMobileCartOpen, setIsMobileCartOpen] = useState(false);
  const [isPaymentSettingsOpen, setIsPaymentSettingsOpen] = useState(false);
  const [paymentSettingsTab, setPaymentSettingsTab] = useState<'qris' | 'bank' | 'profile'>('qris');

  const handleOpenPaymentSettings = (tab: 'qris' | 'bank' | 'profile' = 'qris') => {
    setPaymentSettingsTab(tab);
    setIsPaymentSettingsOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#F8F5F0] text-[#2C1810] flex flex-col font-sans">
      {/* Header with Kedai Branding, Owner greeting, real-time clock, QRIS & Bank settings button & navigation */}
      <Header
        onOpenPaymentSettings={handleOpenPaymentSettings}
        onOpenQRISSettings={() => handleOpenPaymentSettings('qris')}
      />

      {/* Main App Body */}
      <main className="flex-1 flex overflow-hidden relative">
        {activeTab === 'pos' && (
          <div className="flex-1 flex flex-col lg:flex-row h-[calc(100vh-105px)] overflow-hidden">
            {/* POS Catalog Terminal */}
            <POSTerminal />

            {/* Desktop Cart Sidebar */}
            <div className="hidden lg:flex">
              <CartSidebar onOpenPayment={() => setIsPaymentOpen(true)} />
            </div>

            {/* Mobile Bottom Floating Cart Bar */}
            <div className="lg:hidden p-3 bg-white border-t border-[#E8DFD8] flex items-center justify-between shadow-lg sticky bottom-0 z-30">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-[#58311F] text-[#D4A373] flex items-center justify-center font-bold">
                  <ShoppingBag className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs text-[#8C7A70] block">
                    {totalCartItemsCount} Item di Keranjang
                  </span>
                  <span className="font-extrabold text-sm text-[#58311F]">
                    {formatRupiah(cartGrandTotal)}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsMobileCartOpen(true)}
                  className="px-3.5 py-2 rounded-xl border border-[#D7CCC8] text-xs font-semibold text-[#58311F] hover:bg-[#FAF8F5]"
                >
                  Lihat Keranjang
                </button>
                <button
                  type="button"
                  disabled={totalCartItemsCount === 0}
                  onClick={() => setIsPaymentOpen(true)}
                  className="px-4 py-2 rounded-xl bg-[#58311F] text-white text-xs font-bold shadow-sm disabled:opacity-40"
                >
                  Bayar
                </button>
              </div>
            </div>

            {/* Mobile Cart Drawer Modal */}
            {isMobileCartOpen && (
              <div className="lg:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
                <div className="w-full max-w-sm bg-white h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
                  <div className="p-3 bg-[#FAF8F5] border-b border-[#E8DFD8] flex items-center justify-between">
                    <span className="font-bold text-sm text-[#2D1B14]">Keranjang Pesanan</span>
                    <button
                      onClick={() => setIsMobileCartOpen(false)}
                      className="p-1 rounded-lg text-[#8C7A70] hover:bg-neutral-200"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <CartSidebar
                      onOpenPayment={() => {
                        setIsMobileCartOpen(false);
                        setIsPaymentOpen(true);
                      }}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'menu' && <MenuManagement />}
        {activeTab === 'inventory' && <InventoryManagement />}
        {activeTab === 'reports' && <SalesReport />}
        {activeTab === 'history' && (
          <TransactionHistory onViewReceipt={(tx) => setCurrentReceipt(tx)} />
        )}
      </main>

      {/* Payment Processing Modal */}
      <PaymentModal
        isOpen={isPaymentOpen}
        onClose={() => setIsPaymentOpen(false)}
        onOpenPaymentSettings={handleOpenPaymentSettings}
        onOpenQRISSettings={() => handleOpenPaymentSettings('qris')}
      />

      {/* Digital Thermal Receipt Preview Modal */}
      <ReceiptModal
        transaction={currentReceipt}
        onClose={() => setCurrentReceipt(null)}
      />

      {/* Dynamic Payment (QRIS & Bank Transfer) & Shop Profile Settings Modal for Owner Rayvando */}
      <PaymentSettingsModal
        isOpen={isPaymentSettingsOpen}
        onClose={() => setIsPaymentSettingsOpen(false)}
        initialTab={paymentSettingsTab}
      />
    </div>
  );
};

export default function App() {
  return (
    <POSProvider>
      <POSAppContent />
    </POSProvider>
  );
}
